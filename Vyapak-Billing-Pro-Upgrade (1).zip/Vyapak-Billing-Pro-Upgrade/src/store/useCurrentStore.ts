import { useAuthStore } from './useAuthStore';
import { useDataStore } from './useDataStore';
import { useAccessStore, isRestricted } from './useAccessStore';
import { toast } from 'sonner';
import { Party, Item, Invoice, ShopInfo, GstFirm, BillTemplate, makeDefaultTemplate } from '@/types';

const LOCK_MESSAGE =
  'Your plan is inactive. Renew your plan to continue creating invoices and using billing features.';

export function useCurrentStore() {
  const currentUserId = useAuthStore(s => s.currentUserId) || '';
  const allData = useDataStore(s => s.allData);
  const store = useDataStore();
  const account = useAccessStore(s => s.account);
  const restricted = isRestricted(account);

  // Inactive accounts are read-only: every write goes through this guard, so
  // restrictions hold even if a UI control or URL is reached directly.
  function guard<A extends unknown[], R>(fn: (...args: A) => R) {
    return (...args: A): R | undefined => {
      if (restricted) {
        toast.error(LOCK_MESSAGE);
        return undefined;
      }
      return fn(...args);
    };
  }

  const userData = allData[currentUserId] || {
    parties: [],
    items: [],
    invoices: [],
    deletedInvoices: [] as Invoice[],
    shopInfo: { name: 'My Business', address: '', phone: '', gst: '', email: '' },
    gstFirms: [] as GstFirm[],
    templates: [makeDefaultTemplate()] as BillTemplate[],
  };

  return {
    restricted,
    parties: userData.parties,
    items: userData.items,
    invoices: userData.invoices,
    deletedInvoices: userData.deletedInvoices || [],
    shopInfo: userData.shopInfo,
    gstFirms: userData.gstFirms || [],
    templates: userData.templates && userData.templates.length ? userData.templates : [makeDefaultTemplate()],

    addParty: guard((party: Party) => store.addParty(currentUserId, party)),
    updateParty: guard((id: string, data: Partial<Party>) => store.updateParty(currentUserId, id, data)),
    deleteParty: guard((id: string) => store.deleteParty(currentUserId, id)),

    addItem: guard((item: Item) => store.addItem(currentUserId, item)),
    updateItem: guard((id: string, data: Partial<Item>) => store.updateItem(currentUserId, id, data)),
    deleteItem: guard((id: string) => store.deleteItem(currentUserId, id)),

    addInvoice: guard((invoice: Invoice) => store.addInvoice(currentUserId, invoice)),
    updateInvoice: guard((id: string, updates: Partial<Invoice>) => store.updateInvoice(currentUserId, id, updates)),
    deleteInvoice: guard((id: string) => store.deleteInvoice(currentUserId, id)),
    restoreInvoice: guard((id: string) => store.restoreInvoice(currentUserId, id)),
    purgeInvoice: guard((id: string) => store.purgeInvoice(currentUserId, id)),
    updateShopInfo: guard((info: Partial<ShopInfo>) => store.updateShopInfo(currentUserId, info)),

    addGstFirm: guard((firm: GstFirm) => store.addGstFirm(currentUserId, firm)),
    updateGstFirm: guard((id: string, data: Partial<GstFirm>) => store.updateGstFirm(currentUserId, id, data)),
    deleteGstFirm: guard((id: string) => store.deleteGstFirm(currentUserId, id)),

    ensureTemplates: () => store.ensureTemplates(currentUserId),
    saveTemplate: guard((template: BillTemplate) => store.saveTemplate(currentUserId, template)),
    renameTemplate: guard((id: string, name: string) => store.renameTemplate(currentUserId, id, name)),
    deleteTemplate: guard((id: string) => store.deleteTemplate(currentUserId, id)),
    setActiveTemplate: guard((id: string) => store.setActiveTemplate(currentUserId, id)),
  };
}
