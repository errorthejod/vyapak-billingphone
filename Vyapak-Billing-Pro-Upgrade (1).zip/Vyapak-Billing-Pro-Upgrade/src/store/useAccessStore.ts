import { create } from "zustand";
import { api, AccountInfo, PaymentRequest, Plan } from "@/lib/api";

interface AccessState {
  account: AccountInfo | null;
  payments: PaymentRequest[];
  plans: Plan[];
  checked: boolean;
  loading: boolean;
  notFound: boolean;
  refresh: (userId: string) => Promise<AccountInfo | null>;
  reset: () => void;
}

export const useAccessStore = create<AccessState>()((set) => ({
  account: null,
  payments: [],
  plans: [],
  checked: false,
  loading: false,
  notFound: false,

  refresh: async (userId) => {
    set({ loading: true });
    try {
      const { account, payments, plans } = await api.getAccount(userId);
      set({ account, payments, plans, checked: true, loading: false, notFound: false });
      return account;
    } catch (e) {
      const message = e instanceof Error ? e.message : "";
      set({
        checked: true,
        loading: false,
        notFound: message.toLowerCase().includes("not found"),
      });
      return null;
    }
  },

  reset: () =>
    set({ account: null, payments: [], plans: [], checked: false, loading: false, notFound: false }),
}));

export function isRestricted(account: AccountInfo | null) {
  return !account || account.status !== "active";
}
