import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { Party, Item, Invoice, ShopInfo, GstFirm, BillTemplate, makeDefaultTemplate, DEFAULT_TEMPLATE_ID } from '@/types';
import { api, type UserLedgerPayload } from '@/lib/api';

/**
 * Settings (business profile + GST info + bill design + logo/signature/stamp +
 * GST firms) live in the backend, keyed per user account. localStorage is only
 * a fast offline cache — every change is pushed to the backend so nothing is
 * lost on refresh, logout, browser close or device restart.
 */
const syncTimers: Record<string, ReturnType<typeof setTimeout>> = {};
const pendingSettings: Record<string, Record<string, unknown>> = {};

function sendSettings(userId: string) {
  const payload = pendingSettings[userId];
  if (!payload) return;
  api.saveSettings(userId, payload).then(
    () => {
      if (pendingSettings[userId] === payload) delete pendingSettings[userId];
    },
    () => {
      // Offline or backend hiccup: retry shortly, the payload stays pending.
      if (syncTimers[userId]) clearTimeout(syncTimers[userId]);
      syncTimers[userId] = setTimeout(() => sendSettings(userId), 4000);
    },
  );
}

function pushSettings(userId: string, shopInfo: ShopInfo, gstFirms: GstFirm[], templates: BillTemplate[] = []) {
  if (!userId) return;
  pendingSettings[userId] = { shopInfo, gstFirms, templates } as Record<string, unknown>;
  if (syncTimers[userId]) clearTimeout(syncTimers[userId]);
  syncTimers[userId] = setTimeout(() => sendSettings(userId), 200);
}

/** Make sure nothing pending is lost when the tab is closed or hidden. */
if (typeof window !== 'undefined') {
  const flush = () => {
    Object.keys(pendingSettings).forEach(id => {
      if (syncTimers[id]) clearTimeout(syncTimers[id]);
      sendSettings(id);
    });
  };
  window.addEventListener('pagehide', flush);
  window.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') flush();
  });
}

/**
 * localStorage is small: logo / signature / stamp images can push it over the
 * quota, and a failed write used to silently wipe the whole cache. When the
 * write fails we retry with the images stripped out (they are safely stored in
 * the backend and restored on the next load).
 */
const safeLocalStorage: Storage | undefined =
  typeof window === 'undefined'
    ? undefined
    : ({
        getItem: (k: string) => window.localStorage.getItem(k),
        removeItem: (k: string) => window.localStorage.removeItem(k),
        setItem: (k: string, v: string) => {
          try {
            window.localStorage.setItem(k, v);
          } catch {
            try {
              const slim = JSON.parse(v);
              const all = slim?.state?.allData || {};
              Object.keys(all).forEach(id => {
                const shop = all[id]?.shopInfo;
                if (shop) {
                  delete shop.logoImage;
                  delete shop.signatureImage;
                  delete shop.stampImage;
                }
              });
              window.localStorage.setItem(k, JSON.stringify(slim));
            } catch {
              // Give up on caching this write; the backend still has the data.
            }
          }
        },
        get length() {
          return window.localStorage.length;
        },
        clear: () => window.localStorage.clear(),
        key: (i: number) => window.localStorage.key(i),
      } as Storage);

/** Every account always keeps its own copy of the protected default template. */
function withDefaultTemplate(templates?: BillTemplate[]): BillTemplate[] {
  const list = Array.isArray(templates) ? [...templates] : [];
  if (!list.some(t => t.id === DEFAULT_TEMPLATE_ID)) list.unshift(makeDefaultTemplate());
  return list;
}

export interface UserData {
  parties: Party[];
  items: Item[];
  invoices: Invoice[];
  shopInfo: ShopInfo;
  gstFirms?: GstFirm[];
  /** This account's own bill templates (never shared between accounts) */
  templates?: BillTemplate[];
  /** Bills removed by the user, kept so they can be viewed or restored */
  deletedInvoices?: Invoice[];
}


const defaultShopInfo: ShopInfo = {
  name: 'My Business',
  address: '',
  phone: '',
  gst: '',
  email: '',
  pan: '',
  bankName: '',
  bankAccount: '',
  bankIfsc: '',
  bankBranch: '',
  jurisdiction: '',
};

const sampleData: UserData = {
  parties: [
    { id: '1', name: 'Rajesh Kumar', phone: '9876543210', address: '45 MG Road, Delhi', gst: '07AABCU9603R1ZM', type: 'customer', balance: 15000, createdAt: '2024-01-15' },
    { id: '2', name: 'Priya Electronics', phone: '9123456789', address: '12 Nehru Place, Delhi', gst: '07AADCS0472N1Z6', type: 'customer', balance: 28500, createdAt: '2024-02-10' },
    { id: '3', name: 'Amit Telecom', phone: '9988776655', address: '78 Lajpat Nagar, Delhi', type: 'customer', balance: 5200, createdAt: '2024-03-05' },
  ],
  items: [
    { id: '1', name: 'Samsung Galaxy M14', price: 12999, gstPercent: 18, stock: 25, unit: 'Pcs', hsn: '8517' },
    { id: '2', name: 'Realme C55', price: 10999, gstPercent: 18, stock: 40, unit: 'Pcs', hsn: '8517' },
    { id: '3', name: 'Boat Airdopes 141', price: 1299, gstPercent: 18, stock: 100, unit: 'Pcs', hsn: '8518' },
    { id: '4', name: 'USB-C Cable 1m', price: 199, gstPercent: 18, stock: 200, unit: 'Pcs', hsn: '8544' },
    { id: '5', name: 'Tempered Glass (Universal)', price: 99, gstPercent: 18, stock: 500, unit: 'Pcs', hsn: '7007' },
  ],
  invoices: [
    {
      id: '1', invoiceNumber: 'INV-001', date: '2024-01-20', partyId: '1', partyName: 'Rajesh Kumar',
      partyAddress: '45 MG Road, Delhi', partyGst: '07AABCU9603R1ZM',
      items: [
        { itemId: '1', name: 'Samsung Galaxy M14', qty: 2, rate: 12999, gstPercent: 18, amount: 25998, cgst: 2339.82, sgst: 2339.82 },
        { itemId: '4', name: 'USB-C Cable 1m', qty: 2, rate: 199, gstPercent: 18, amount: 398, cgst: 35.82, sgst: 35.82 },
      ],
      subtotal: 26396, totalCgst: 2375.64, totalSgst: 2375.64, totalAmount: 31147.28, type: 'sale', createdAt: '2024-01-20',
    },
  ],
  shopInfo: {
    name: 'Shuvidha Telecom Mobile and Electronics',
    address: 'GROUND FLOOR, SHOP NO-5 PLOT NO 1 KH NO-19/20, RAMA VIHAR BLOCK-D, VILLAGE MOHAMMAD PUR MAGRI DELHI-110081',
    phone: '8851711152',
    gst: '',
    email: 'shuvidhatelecom@gmail.com',
    state: '07-Delhi',
    termsAndConditions: '1. All phones will be under warranty from the service center and not from the dealer.\n2. The customer has to visit the service center.\n3. Sold goods will not be returned.\n4. All phone are repaired here.\n5. Damage item is not exchange.',
  },
};

const emptyUserData = (): UserData => ({
  parties: [],
  items: [],
  invoices: [],
  shopInfo: { ...defaultShopInfo },
  gstFirms: [],
  templates: [makeDefaultTemplate()],
  deletedInvoices: [],
});

interface DataStore {
  allData: Record<string, UserData>;
  settingsLoaded: Record<string, boolean>;
  loadSettings: (userId: string) => Promise<void>;
  initUser: (userId: string, isDemo?: boolean, businessName?: string) => void;
  addParty: (userId: string, party: Party) => void;
  updateParty: (userId: string, id: string, data: Partial<Party>) => void;
  deleteParty: (userId: string, id: string) => void;
  addItem: (userId: string, item: Item) => void;
  updateItem: (userId: string, id: string, data: Partial<Item>) => void;
  deleteItem: (userId: string, id: string) => void;
  addInvoice: (userId: string, invoice: Invoice) => void;
  updateInvoice: (userId: string, invoiceId: string, updates: Partial<Invoice>) => void;
  deleteInvoice: (userId: string, invoiceId: string) => void;
  restoreInvoice: (userId: string, invoiceId: string) => void;
  purgeInvoice: (userId: string, invoiceId: string) => void;
  updateShopInfo: (userId: string, info: Partial<ShopInfo>) => void;
  addGstFirm: (userId: string, firm: GstFirm) => void;
  updateGstFirm: (userId: string, id: string, data: Partial<GstFirm>) => void;
  deleteGstFirm: (userId: string, id: string) => void;
  ensureTemplates: (userId: string) => void;
  saveTemplate: (userId: string, template: BillTemplate) => void;
  renameTemplate: (userId: string, id: string, name: string) => void;
  deleteTemplate: (userId: string, id: string) => void;
  setActiveTemplate: (userId: string, id: string) => void;
}

const ledgerSyncTimers: Record<string, ReturnType<typeof setTimeout>> = {};
function ledgerPayload(data: UserData): UserLedgerPayload {
  return {
    parties: data.parties || [], items: data.items || [], invoices: data.invoices || [],
    deletedInvoices: data.deletedInvoices || [],
  };
}

export const useDataStore = create<DataStore>()(
  persist(
    (set, get) => ({
      allData: { BB001: sampleData },
      settingsLoaded: {},

      loadSettings: async (userId) => {
        if (!userId) return;
        let remote: { shopInfo?: Partial<ShopInfo>; gstFirms?: GstFirm[]; templates?: BillTemplate[] } | null = null;
        let ledgerReadSucceeded = false;
        let remoteLedger: UserLedgerPayload | null = null;
        try {
          remote = (await api.getSettings(userId)) as
            | { shopInfo?: Partial<ShopInfo>; gstFirms?: GstFirm[]; templates?: BillTemplate[] }
            | null;
        } catch {
          // Keep the local settings cache available while the backend is offline.
        }
        try {
          remoteLedger = await api.getUserLedger(userId);
          ledgerReadSucceeded = true;
        } catch {
          // Do not seed remote data when the ledger request failed; it may be a network/auth issue.
        }

        const remoteShop = remote?.shopInfo;
        set(s => {
          const existing = s.allData[userId] || emptyUserData();
          const ledgerFields = remoteLedger ? {
            parties: remoteLedger.parties as Party[],
            items: remoteLedger.items as Item[],
            invoices: remoteLedger.invoices as Invoice[],
            deletedInvoices: remoteLedger.deletedInvoices as Invoice[],
          } : {};
          return {
            allData: {
              ...s.allData,
              [userId]: {
                ...existing,
                ...ledgerFields,
                shopInfo: remoteShop && Object.keys(remoteShop).length > 0
                  ? { ...defaultShopInfo, ...existing.shopInfo, ...remoteShop }
                  : { ...defaultShopInfo, ...existing.shopInfo },
                gstFirms: Array.isArray(remote?.gstFirms) ? remote!.gstFirms! : existing.gstFirms || [],
                templates: withDefaultTemplate(
                  Array.isArray(remote?.templates) ? remote!.templates! : existing.templates,
                ),
              },
            },
            settingsLoaded: { ...s.settingsLoaded, [userId]: true },
          };
        });

        const current = get().allData[userId];
        if (current?.shopInfo && (!remoteShop || Object.keys(remoteShop).length === 0)) {
          // First run for this account — seed business settings from the local cache.
          pushSettings(userId, current.shopInfo, current.gstFirms || [], withDefaultTemplate(current.templates));
        }
        if (ledgerReadSucceeded && !remoteLedger && current) {
          // One-time migration: push the existing local ledger only when the server confirmed no row exists.
          const payload: UserLedgerPayload = {
            parties: current.parties || [], items: current.items || [],
            invoices: current.invoices || [], deletedInvoices: current.deletedInvoices || [],
          };
          try { await api.saveUserLedger(userId, payload); } catch { /* local cache remains available offline */ }
        }
      },


      initUser: (userId, isDemo = false, businessName) => {
        if (!get().allData[userId]) {
          const userData = isDemo ? sampleData : emptyUserData();
          if (!isDemo && businessName) {
            userData.shopInfo.name = businessName;
          }
          set(s => ({
            allData: {
              ...s.allData,
              [userId]: userData,
            },
          }));
        } else if (businessName && get().allData[userId]?.shopInfo?.name === 'My Business') {
          set(s => ({
            allData: {
              ...s.allData,
              [userId]: {
                ...s.allData[userId],
                shopInfo: { ...s.allData[userId].shopInfo, name: businessName },
              },
            },
          }));
        }
      },

      addParty: (userId, party) =>
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: { ...s.allData[userId], parties: [...(s.allData[userId]?.parties || []), party] },
          },
        })),

      updateParty: (userId, id, data) =>
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: {
              ...s.allData[userId],
              parties: s.allData[userId]?.parties.map(p => p.id === id ? { ...p, ...data } : p) || [],
            },
          },
        })),

      deleteParty: (userId, id) =>
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: {
              ...s.allData[userId],
              parties: s.allData[userId]?.parties.filter(p => p.id !== id) || [],
            },
          },
        })),

      addItem: (userId, item) =>
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: { ...s.allData[userId], items: [...(s.allData[userId]?.items || []), item] },
          },
        })),

      updateItem: (userId, id, data) =>
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: {
              ...s.allData[userId],
              items: s.allData[userId]?.items.map(i => i.id === id ? { ...i, ...data } : i) || [],
            },
          },
        })),

      deleteItem: (userId, id) =>
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: {
              ...s.allData[userId],
              items: s.allData[userId]?.items.filter(i => i.id !== id) || [],
            },
          },
        })),

      addInvoice: (userId, invoice) =>
        set(s => {
          const userData = s.allData[userId] || { parties: [], items: [], invoices: [], shopInfo: { ...defaultShopInfo } };
          const updatedItems = userData.items.map(item => {
            const invoiceItem = invoice.items.find(ii => ii.itemId === item.id || ii.name.trim().toLowerCase() === item.name.trim().toLowerCase());
            if (!invoiceItem) return item;
            if (invoice.type === 'purchase') return { ...item, stock: item.stock + invoiceItem.qty };
            if (invoice.type === 'sale') return { ...item, stock: Math.max(0, item.stock - invoiceItem.qty) };
            return item;
          });
          return {
            allData: {
              ...s.allData,
              [userId]: {
                ...userData,
                items: updatedItems,
                invoices: [...userData.invoices, invoice],
              },
            },
          };
        }),

      updateInvoice: (userId: string, invoiceId: string, updates: Partial<Invoice>) =>
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: {
              ...s.allData[userId],
              invoices: (s.allData[userId]?.invoices || []).map(inv =>
                inv.id === invoiceId ? { ...inv, ...updates } : inv
              ),
            },
          },
        })),

      deleteInvoice: (userId: string, invoiceId: string) =>
        set(s => {
          const userData = s.allData[userId] || emptyUserData();
          const removed = (userData.invoices || []).find(inv => inv.id === invoiceId);
          if (!removed) return s;
          return {
            allData: {
              ...s.allData,
              [userId]: {
                ...userData,
                invoices: (userData.invoices || []).filter(inv => inv.id !== invoiceId),
                deletedInvoices: [
                  { ...removed, deletedAt: new Date().toISOString() },
                  ...(userData.deletedInvoices || []),
                ],
              },
            },
          };
        }),

      restoreInvoice: (userId: string, invoiceId: string) =>
        set(s => {
          const userData = s.allData[userId] || emptyUserData();
          const bill = (userData.deletedInvoices || []).find(inv => inv.id === invoiceId);
          if (!bill) return s;
          const { deletedAt: _ignored, ...restored } = bill;
          return {
            allData: {
              ...s.allData,
              [userId]: {
                ...userData,
                invoices: [...(userData.invoices || []), restored],
                deletedInvoices: (userData.deletedInvoices || []).filter(inv => inv.id !== invoiceId),
              },
            },
          };
        }),

      purgeInvoice: (userId: string, invoiceId: string) =>
        set(s => {
          const userData = s.allData[userId] || emptyUserData();
          return {
            allData: {
              ...s.allData,
              [userId]: {
                ...userData,
                deletedInvoices: (userData.deletedInvoices || []).filter(inv => inv.id !== invoiceId),
              },
            },
          };
        }),

      updateShopInfo: (userId, info) => {
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: {
              ...s.allData[userId],
              shopInfo: { ...s.allData[userId]?.shopInfo, ...info },
            },
          },
        }));
        const data = get().allData[userId];
        if (data?.shopInfo) pushSettings(userId, data.shopInfo, data.gstFirms || [], withDefaultTemplate(data.templates));
      },

      addGstFirm: (userId, firm) => {
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: {
              ...(s.allData[userId] || emptyUserData()),
              gstFirms: [...(s.allData[userId]?.gstFirms || []), firm],
            },
          },
        }));
        const data = get().allData[userId];
        if (data?.shopInfo) pushSettings(userId, data.shopInfo, data.gstFirms || [], withDefaultTemplate(data.templates));
      },

      updateGstFirm: (userId, id, patch) => {
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: {
              ...s.allData[userId],
              gstFirms: (s.allData[userId]?.gstFirms || []).map(f => (f.id === id ? { ...f, ...patch } : f)),
            },
          },
        }));
        const data = get().allData[userId];
        if (data?.shopInfo) pushSettings(userId, data.shopInfo, data.gstFirms || [], withDefaultTemplate(data.templates));
      },

      deleteGstFirm: (userId, id) => {
        set(s => ({
          allData: {
            ...s.allData,
            [userId]: {
              ...s.allData[userId],
              gstFirms: (s.allData[userId]?.gstFirms || []).filter(f => f.id !== id),
            },
          },
        }));
        const data = get().allData[userId];
        if (data?.shopInfo) pushSettings(userId, data.shopInfo, data.gstFirms || [], withDefaultTemplate(data.templates));
      },

      ensureTemplates: (userId) => {
        if (!userId) return;
        const existing = get().allData[userId];
        if (existing?.templates?.some(t => t.id === DEFAULT_TEMPLATE_ID)) return;
        set(s => {
          const data = s.allData[userId] || emptyUserData();
          return {
            allData: { ...s.allData, [userId]: { ...data, templates: withDefaultTemplate(data.templates) } },
          };
        });
        const data = get().allData[userId];
        if (data?.shopInfo) pushSettings(userId, data.shopInfo, data.gstFirms || [], withDefaultTemplate(data.templates));
      },

      saveTemplate: (userId, template) => {
        set(s => {
          const data = s.allData[userId] || emptyUserData();
          const list = withDefaultTemplate(data.templates);
          const idx = list.findIndex(t => t.id === template.id);
          const next = { ...template, updatedAt: new Date().toISOString() };
          if (idx >= 0) list[idx] = { ...list[idx], ...next };
          else list.push(next);
          return { allData: { ...s.allData, [userId]: { ...data, templates: list } } };
        });
        const data = get().allData[userId];
        if (data?.shopInfo) pushSettings(userId, data.shopInfo, data.gstFirms || [], withDefaultTemplate(data.templates));
      },

      renameTemplate: (userId, id, name) => {
        set(s => {
          const data = s.allData[userId] || emptyUserData();
          return {
            allData: {
              ...s.allData,
              [userId]: {
                ...data,
                templates: withDefaultTemplate(data.templates).map(t =>
                  t.id === id ? { ...t, name, updatedAt: new Date().toISOString() } : t,
                ),
              },
            },
          };
        });
        const data = get().allData[userId];
        if (data?.shopInfo) pushSettings(userId, data.shopInfo, data.gstFirms || [], withDefaultTemplate(data.templates));
      },

      deleteTemplate: (userId, id) => {
        if (id === DEFAULT_TEMPLATE_ID) return;
        set(s => {
          const data = s.allData[userId] || emptyUserData();
          const templates = withDefaultTemplate(data.templates).filter(t => t.id !== id);
          const shopInfo =
            data.shopInfo?.activeTemplateId === id
              ? { ...data.shopInfo, activeTemplateId: DEFAULT_TEMPLATE_ID }
              : data.shopInfo;
          return { allData: { ...s.allData, [userId]: { ...data, templates, shopInfo } } };
        });
        const data = get().allData[userId];
        if (data?.shopInfo) pushSettings(userId, data.shopInfo, data.gstFirms || [], withDefaultTemplate(data.templates));
      },

      setActiveTemplate: (userId, id) => {
        set(s => {
          const data = s.allData[userId] || emptyUserData();
          const tpl = withDefaultTemplate(data.templates).find(t => t.id === id);
          return {
            allData: {
              ...s.allData,
              [userId]: {
                ...data,
                shopInfo: {
                  ...data.shopInfo,
                  activeTemplateId: id,
                  billStyle: tpl ? { ...tpl.style } : data.shopInfo?.billStyle,
                },
              },
            },
          };
        });
        const data = get().allData[userId];
        if (data?.shopInfo) pushSettings(userId, data.shopInfo, data.gstFirms || [], withDefaultTemplate(data.templates));
      },

    }),
    {
      name: 'bb-data-store',
      partialize: (state) => ({ allData: state.allData }),
      storage: safeLocalStorage ? createJSONStorage(() => safeLocalStorage) : undefined,

      onRehydrateStorage: () => (state) => {
        if (!state) return;

        // --- One-time migration from old 'vyapar-store' ---
        try {
          const oldRaw = localStorage.getItem('vyapar-store');
          if (oldRaw) {
            const old = JSON.parse(oldRaw);
            const oldState = old?.state;
            const hasOldParties = Array.isArray(oldState?.parties) && oldState.parties.length > 0;
            const hasOldItems = Array.isArray(oldState?.items) && oldState.items.length > 0;
            const hasOldInvoices = Array.isArray(oldState?.invoices) && oldState.invoices.length > 0;

            if (hasOldParties || hasOldItems || hasOldInvoices) {
              const currentBB001 = state.allData?.['BB001'];
              // Only migrate if BB001 has no real data yet (empty or only sample placeholder)
              const isSampleOrEmpty =
                !currentBB001 ||
                currentBB001.parties.length === 0 ||
                (currentBB001.parties.length <= 3 &&
                  currentBB001.parties.every(p => ['Rajesh Kumar', 'Priya Electronics', 'Amit Telecom'].includes(p.name)));

              if (isSampleOrEmpty) {
                const migratedShopInfo = {
                  name: oldState?.shopInfo?.name || 'Shuvidha Telecom Mobile and Electronics',
                  address: oldState?.shopInfo?.address || 'GROUND FLOOR, SHOP NO-5 PLOT NO 1 KH NO-19/20, RAMA VIHAR BLOCK-D, VILLAGE MOHAMMAD PUR MAGRI DELHI-110081',
                  phone: oldState?.shopInfo?.phone || '8851711152',
                  gst: oldState?.shopInfo?.gst || '',
                  email: oldState?.shopInfo?.email || 'shuvidhatelecom@gmail.com',
                  state: oldState?.shopInfo?.state || '07-Delhi',
                  termsAndConditions: oldState?.shopInfo?.termsAndConditions || '1. All phones will be under warranty from the service center and not from the dealer.\n2. The customer has to visit the service center.\n3. Sold goods will not be returned.\n4. All phone are repaired here.\n5. Damage item is not exchange.',
                };
                state.allData = {
                  ...state.allData,
                  BB001: {
                    parties: oldState.parties || [],
                    items: oldState.items || [],
                    invoices: oldState.invoices || [],
                    shopInfo: migratedShopInfo,
                  },
                };
                // Remove old store so migration doesn't repeat
                localStorage.removeItem('vyapar-store');
              }
            }
          }
        } catch {
          // Migration failure is non-fatal
        }

        // --- Ensure shop info is always correct for BB001 ---
        if (state.allData['BB001']) {
          if (!state.allData['BB001'].shopInfo.state) {
            state.allData['BB001'].shopInfo.state = '07-Delhi';
          }
          if (!state.allData['BB001'].shopInfo.termsAndConditions) {
            state.allData['BB001'].shopInfo.termsAndConditions = '1. All phones will be under warranty from the service center and not from the dealer.\n2. The customer has to visit the service center.\n3. Sold goods will not be returned.\n4. All phone are repaired here.\n5. Damage item is not exchange.';
          }
        }
      },
    }
  )
);


// Sync invoices, parties, stock and removed bills to the server after initial hydration.
// The first load is excluded so cloud data never gets overwritten by an old local cache.
useDataStore.subscribe((state, previous) => {
  for (const [userId, data] of Object.entries(state.allData)) {
    if (!previous.settingsLoaded[userId] || previous.allData[userId] === data) continue;
    if (ledgerSyncTimers[userId]) clearTimeout(ledgerSyncTimers[userId]);
    ledgerSyncTimers[userId] = setTimeout(() => {
      void api.saveUserLedger(userId, ledgerPayload(data)).catch(() => {
        // Keep offline-first behavior; the latest changes remain in localStorage.
      });
    }, 500);
  }
});
