/**
 * Local, persistent JSON database adapter implementing the small subset of the
 * Supabase query API used by the app. This allows laptop/VPS self-hosting without
 * requiring a Supabase project or manually applying SQL migrations.
 *
 * Intended for a single-instance self-hosted install. For multi-instance production,
 * use PostgreSQL/Supabase instead of this local JSON adapter.
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync, renameSync } from "node:fs";
import { dirname, extname, join, resolve } from "node:path";
import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";

export type LocalDbRow = Record<string, any>;
type LocalDbState = Record<string, LocalDbRow[]>;
type Filter = { column: string; op: string; value: any };

const baseDir = () => resolve(process.cwd(), process.env.LOCAL_DB_DIR || "data");
const databasePath = () => join(baseDir(), "vyapak-local.json");
const storageDir = () => join(baseDir(), "storage");
const emptyLedger = { parties: [], items: [], invoices: [], deletedInvoices: [] };

function defaultsFor(table: string, row: LocalDbRow): LocalDbRow {
  const now = new Date().toISOString();
  switch (table) {
    case "bb_users":
      return { pin: "", email: "", mobile: null, password_hash: null, is_active: true, created_at: now,
        is_trial: false, trial_start: null, trial_end: null, trial_used: false, plan_id: null,
        plan_name: null, plan_price: null, plan_start: null, plan_expiry: null,
        account_type: "business", ca_status: null, ca_firm: null, ca_registration_no: null, ...row };
    case "bb_admin_config":
      return { id: 1, admin_password: process.env.ADMIN_PASSWORD || "delhi5932", next_user_num: 2,
        next_ca_num: 1, payment_qr_url: null, upi_id: null, bill_templates: [],
        bill_templates_initialized: false, ...row };
    case "bb_user_settings": return { settings: {}, created_at: now, updated_at: now, ...row };
    case "bb_plans": return { id: randomUUID(), price: 0, duration_months: 12, features: [], is_active: true,
      sort_order: 0, created_at: now, updated_at: now, ...row };
    case "bb_payment_requests": return { id: randomUUID(), user_name: "", user_email: "", plan_id: null,
      plan_name: "", amount: 0, duration_months: 12, utr: "", proof_path: null, proof_name: null,
      status: "pending", admin_note: null, created_at: now, updated_at: now, ...row };
    case "bb_ca_access_requests": return { id: randomUUID(), status: "pending",
      permissions: ["sales", "purchases", "expenses", "gst_reports", "invoice_history", "financial_reports"],
      created_at: now, updated_at: now, ...row };
    case "bb_user_ledger": return { ledger: emptyLedger, updated_at: now, ...row };
    case "bb_ca_access_audit": return { id: randomUUID(), request_id: null, created_at: now, details: {}, ...row };
    default: return { ...row };
  }
}

function initialState(): LocalDbState {
  const now = new Date().toISOString();
  return {
    bb_users: [],
    bb_admin_config: [defaultsFor("bb_admin_config", { id: 1 })],
    bb_user_settings: [],
    bb_plans: [
      defaultsFor("bb_plans", { name: "1 Year", price: 1600, duration_months: 12,
        features: ["Unlimited GST invoices", "Parties, stock & credit tracking", "Purchase & expense records", "Reports & backups", "Email support"], is_active: true, sort_order: 1 }),
      defaultsFor("bb_plans", { name: "2 Years", price: 3000, duration_months: 24,
        features: ["Everything in 1 Year plan", "Save ₹200 vs yearly", "Priority support", "Free bill template updates"], is_active: true, sort_order: 2 }),
    ],
    bb_payment_requests: [], bb_ca_access_requests: [], bb_user_ledger: [], bb_ca_access_audit: [],
  };
}

function normalizeState(input: unknown): LocalDbState {
  const initial = initialState();
  if (!input || typeof input !== "object") return initial;
  const inputObj = input as Record<string, unknown>;
  for (const key of Object.keys(initial)) {
    if (!Array.isArray(inputObj[key])) inputObj[key] = initial[key];
  }
  const state = inputObj as LocalDbState;
  if (!state.bb_admin_config.some((r) => Number(r.id) === 1)) state.bb_admin_config.push(defaultsFor("bb_admin_config", { id: 1 }));
  return state;
}

function readState(): LocalDbState {
  mkdirSync(baseDir(), { recursive: true });
  const file = databasePath();
  if (!existsSync(file)) {
    const state = initialState();
    writeState(state);
    return state;
  }
  try { return normalizeState(JSON.parse(readFileSync(file, "utf8"))); }
  catch (error) {
    throw new Error(`Local database file is unreadable (${file}). Back it up and check JSON validity. ${error instanceof Error ? error.message : String(error)}`);
  }
}

function writeState(state: LocalDbState) {
  mkdirSync(baseDir(), { recursive: true });
  const file = databasePath();
  const temp = `${file}.tmp`;
  writeFileSync(temp, JSON.stringify(state, null, 2), "utf8");
  renameSync(temp, file);
}

function compareValue(a: any, b: any): boolean {
  if (a == null || b == null) return a == null && b == null;
  if (typeof a === "number" || typeof b === "number") return Number(a) === Number(b);
  return String(a) === String(b);
}

function parseOrFilter(expression: string): Filter[] {
  return expression.split(/,(?=[a-zA-Z_][\w]*\.)/).map((piece) => {
    const match = /^([\w]+)\.(eq|neq|ilike|like)\.(.*)$/i.exec(piece.trim());
    return match ? { column: match[1], op: match[2].toLowerCase(), value: match[3] } : null;
  }).filter((f): f is Filter => Boolean(f));
}

function isMatch(row: LocalDbRow, filters: Filter[], orFilters: Filter[][]): boolean {
  const test = (f: Filter) => {
    const value = row[f.column];
    if (f.op === "eq") return compareValue(value, f.value);
    if (f.op === "neq") return !compareValue(value, f.value);
    if (f.op === "is") return f.value === "null" ? value == null : compareValue(value, f.value);
    if (f.op === "ilike" || f.op === "like") {
      const pattern = String(f.value).replace(/^%|%$/g, "").replace(/%/g, "").toLowerCase();
      const source = String(value ?? "").toLowerCase();
      return pattern ? (String(f.value).startsWith("%") && String(f.value).endsWith("%") ? source.includes(pattern) : String(f.value).startsWith("%") ? source.endsWith(pattern) : String(f.value).endsWith("%") ? source.startsWith(pattern) : source === pattern) : true;
    }
    return false;
  };
  return filters.every(test) && (orFilters.length === 0 || orFilters.some((group) => group.some(test)));
}

function project(row: LocalDbRow, selection: string): LocalDbRow {
  if (!selection || selection.trim() === "*" || selection.includes("(")) return { ...row };
  const columns = selection.split(",").map((c) => c.trim()).filter(Boolean);
  const result: LocalDbRow = {};
  for (const column of columns) if (column in row) result[column] = row[column];
  return result;
}

function uniqueError(message: string) { return { message, code: "23505", details: null, hint: null }; }

class LocalQuery implements PromiseLike<{ data: any; error: any; count?: number }> {
  private action = "select";
  private selection = "*";
  private payload: LocalDbRow | LocalDbRow[] = {};
  private filters: Filter[] = [];
  private orFilters: Filter[][] = [];
  private orderings: { column: string; ascending: boolean }[] = [];
  private maxRows: number | undefined;
  private oneMode: "none" | "single" | "maybeSingle" = "none";
  private returning = false;
  private options: Record<string, any> = {};
  constructor(private table: string) {}
  select(columns = "*", _options?: unknown) { this.selection = columns || "*"; if (this.action !== "select") this.returning = true; return this; }
  insert(values: LocalDbRow | LocalDbRow[], options?: Record<string, any>) { this.action = "insert"; this.payload = values; this.options = options || {}; return this; }
  upsert(values: LocalDbRow | LocalDbRow[], options?: Record<string, any>) { this.action = "upsert"; this.payload = values; this.options = options || {}; return this; }
  update(values: LocalDbRow) { this.action = "update"; this.payload = values; return this; }
  delete() { this.action = "delete"; return this; }
  eq(column: string, value: any) { this.filters.push({ column, op: "eq", value }); return this; }
  neq(column: string, value: any) { this.filters.push({ column, op: "neq", value }); return this; }
  is(column: string, value: any) { this.filters.push({ column, op: "is", value: value === null ? "null" : value }); return this; }
  ilike(column: string, value: string) { this.filters.push({ column, op: "ilike", value }); return this; }
  like(column: string, value: string) { this.filters.push({ column, op: "like", value }); return this; }
  or(expression: string) { this.orFilters.push(parseOrFilter(expression)); return this; }
  order(column: string, options?: { ascending?: boolean }) { this.orderings.push({ column, ascending: options?.ascending ?? true }); return this; }
  limit(value: number) { this.maxRows = value; return this; }
  single() { this.oneMode = "single"; return this; }
  maybeSingle() { this.oneMode = "maybeSingle"; return this; }

  private execute(): { data: any; error: any; count?: number } {
    try {
      const state = readState();
      if (!state[this.table]) state[this.table] = [];
      const rows = state[this.table];
      let changed = false;
      let result: LocalDbRow[] = [];
      const values = Array.isArray(this.payload) ? this.payload : [this.payload];
      const matched = () => rows.filter((row) => isMatch(row, this.filters, this.orFilters));
      if (this.action === "select") result = matched();
      else if (this.action === "insert" || this.action === "upsert") {
        const conflicts = String(this.options.onConflict || (this.table === "bb_users" ? "id" : this.table === "bb_user_settings" || this.table === "bb_user_ledger" ? (this.table === "bb_user_settings" ? "user_id" : "user_id") : "id"))
          .split(",").map((s) => s.trim()).filter(Boolean);
        for (const raw of values) {
          const newRow = defaultsFor(this.table, { ...raw });
          let conflict = rows.find((old) => conflicts.every((c) => old[c] != null && compareValue(old[c], newRow[c])));
          if (this.action === "upsert" && conflict) {
            if (this.options.ignoreDuplicates) continue;
            Object.assign(conflict, raw, { updated_at: raw.updated_at || new Date().toISOString() });
            result.push(conflict); changed = true; continue;
          }
          if (this.action === "insert" && this.table === "bb_users") {
            const duplicateId = rows.some((r) => r.id === newRow.id);
            const email = String(newRow.email || "").trim().toLowerCase();
            const mobile = String(newRow.mobile || "").trim();
            const duplicateEmail = email && rows.some((r) => String(r.email || "").trim().toLowerCase() === email);
            const duplicateMobile = mobile && rows.some((r) => String(r.mobile || "").trim() === mobile);
            if (duplicateId || duplicateEmail || duplicateMobile) return { data: null, error: uniqueError("A user with the same ID, email, or mobile already exists") };
          }
          if (this.action === "insert" && rows.some((r) => conflicts.every((c) => r[c] != null && compareValue(r[c], newRow[c])))) {
            return { data: null, error: uniqueError(`Duplicate key value violates unique constraint on ${this.table}`) };
          }
          rows.push(newRow); result.push(newRow); changed = true;
        }
      } else if (this.action === "update") {
        result = matched();
        for (const row of result) Object.assign(row, this.payload, { updated_at: (this.payload as LocalDbRow).updated_at || new Date().toISOString() });
        changed = result.length > 0;
      } else if (this.action === "delete") {
        result = matched();
        const removed = new Set(result);
        state[this.table] = rows.filter((row) => !removed.has(row));
        changed = removed.size > 0;
        if (this.table === "bb_users" && removed.size) {
          const removedIds = new Set([...removed].map((row) => String(row.id)));
          for (const row of removed) {
            const userId = String(row.id);
            if (state.bb_user_settings) state.bb_user_settings = state.bb_user_settings.filter((r) => r.user_id !== userId);
            if (state.bb_user_ledger) state.bb_user_ledger = state.bb_user_ledger.filter((r) => r.user_id !== userId);
          }
          if (state.bb_payment_requests) state.bb_payment_requests = state.bb_payment_requests.filter((r) => !removedIds.has(String(r.user_id)));
          if (state.bb_ca_access_requests) state.bb_ca_access_requests = state.bb_ca_access_requests.filter((r) => !removedIds.has(String(r.ca_id)) && !removedIds.has(String(r.business_id)));
          if (state.bb_ca_access_audit) state.bb_ca_access_audit = state.bb_ca_access_audit.filter((r) => !removedIds.has(String(r.ca_id)) && !removedIds.has(String(r.business_id)) && !removedIds.has(String(r.actor_id)));
        }
        result = [];
      }
      if (changed) writeState(state);
      for (const order of [...this.orderings].reverse()) result.sort((a, b) => {
        const av = a[order.column], bv = b[order.column];
        const cmp = av == null ? (bv == null ? 0 : -1) : bv == null ? 1 : typeof av === "number" && typeof bv === "number" ? av - bv : String(av).localeCompare(String(bv));
        return order.ascending ? cmp : -cmp;
      });
      if (this.maxRows !== undefined) result = result.slice(0, this.maxRows);
      const projected = result.map((row) => project(row, this.selection));
      if (this.action !== "select" && !this.returning) return { data: null, error: null, count: result.length };
      if (this.oneMode === "single") {
        if (projected.length !== 1) return { data: null, error: { message: `Expected one row from ${this.table}, got ${projected.length}`, code: "PGRST116", details: null, hint: null } };
        return { data: projected[0], error: null, count: 1 };
      }
      if (this.oneMode === "maybeSingle") {
        if (projected.length > 1) return { data: null, error: { message: `Expected at most one row from ${this.table}, got ${projected.length}`, code: "PGRST116", details: null, hint: null } };
        return { data: projected[0] ?? null, error: null, count: projected.length };
      }
      return { data: projected, error: null, count: projected.length };
    } catch (error) {
      return { data: null, error: { message: error instanceof Error ? error.message : String(error), code: "LOCALDB", details: null, hint: null } };
    }
  }
  then<TResult1 = { data: any; error: any; count?: number }, TResult2 = never>(
    onfulfilled?: ((value: { data: any; error: any; count?: number }) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null,
  ): PromiseLike<TResult1 | TResult2> {
    return Promise.resolve(this.execute()).then(onfulfilled, onrejected);
  }
}

function safePath(input: string) {
  const normalized = input.replace(/\\/g, "/").replace(/^\/+/, "");
  if (!normalized || normalized.split("/").some((part) => part === ".." || part === ".")) throw new Error("Invalid storage path");
  return normalized;
}

function createLocalStorage() {
  return { from: (bucket: string) => ({
    upload: async (path: string, body: Uint8Array, options: { contentType?: string; upsert?: boolean } = {}) => {
      try {
        const clean = safePath(path);
        const root = resolve(storageDir(), bucket);
        const target = resolve(root, clean);
        if (!target.startsWith(root + (process.platform === "win32" ? "\\" : "/"))) throw new Error("Invalid storage path");
        mkdirSync(dirname(target), { recursive: true });
        if (existsSync(target) && !options.upsert) return { data: null, error: { message: "The file already exists", code: "Duplicate" } };
        writeFileSync(target, Buffer.from(body));
        return { data: { path: clean, fullPath: `${bucket}/${clean}`, id: clean }, error: null };
      } catch (error) { return { data: null, error: { message: error instanceof Error ? error.message : String(error) } }; }
    },
    createSignedUrl: async (path: string, expiresIn: number) => {
      try {
        const clean = safePath(path);
        const expires = Math.floor(Date.now() / 1000) + expiresIn;
        const secret = process.env.APP_SESSION_SECRET || "local-dev-only-change-me";
        const sig = createHmac("sha256", secret).update(`${bucket}:${clean}:${expires}`).digest("hex");
        const query = new URLSearchParams({ bucket, path: clean, exp: String(expires), sig });
        return { data: { signedUrl: `/api/local-storage?${query.toString()}` }, error: null };
      } catch (error) { return { data: null, error: { message: error instanceof Error ? error.message : String(error) } }; }
    },
  }) };
}

export function verifyLocalStorageSignature(bucket: string, path: string, expires: number, signature: string) {
  if (!Number.isFinite(expires) || expires < Math.floor(Date.now() / 1000)) return false;
  try {
    const clean = safePath(path);
    const secret = process.env.APP_SESSION_SECRET || "local-dev-only-change-me";
    const expected = createHmac("sha256", secret).update(`${bucket}:${clean}:${expires}`).digest();
    const provided = Buffer.from(signature, "hex");
    return provided.length === expected.length && timingSafeEqual(provided, expected);
  } catch { return false; }
}

export function readLocalStorageFile(bucket: string, path: string): { bytes: Buffer; contentType: string } | null {
  try {
    const clean = safePath(path);
    const root = resolve(storageDir(), bucket);
    const target = resolve(root, clean);
    if (!target.startsWith(root + (process.platform === "win32" ? "\\" : "/"))) return null;
    if (!existsSync(target)) return null;
    const ext = extname(target).toLowerCase();
    const contentType = ext === ".pdf" ? "application/pdf" : ext === ".png" ? "image/png" : ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : "application/octet-stream";
    return { bytes: readFileSync(target), contentType };
  } catch { return null; }
}

export function createLocalSupabaseAdapter() {
  // Ensure the persistent database exists before the first route needs it.
  readState();
  const db: any = { from: (table: string) => new LocalQuery(table), storage: createLocalStorage() };
  return db;
}

export function checkLocalDatabase() {
  const state = readState();
  return { file: databasePath(), tables: Object.keys(state), users: state.bb_users.length };
}
