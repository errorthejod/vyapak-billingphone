// In local-database mode the app uses its own server-side session cookie and does
// not need a Supabase Auth bearer token. Skip the browser Supabase client entirely.
import { createMiddleware } from '@tanstack/react-start';
import { supabase } from './client';

export const attachSupabaseAuth = createMiddleware({ type: 'function' }).client(
  async ({ next }) => {
    if (import.meta.env.VITE_LOCAL_DB_MODE === 'true') return next();
    const { data } = await supabase.auth.getSession();
    const token = data.session?.access_token;
    return next({ headers: token ? { Authorization: `Bearer ${token}` } : {} });
  },
);
