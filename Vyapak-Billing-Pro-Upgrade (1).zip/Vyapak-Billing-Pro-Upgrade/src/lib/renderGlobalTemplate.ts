import type { Invoice, InvoiceItem, ShopInfo } from "@/types";
import type { GlobalBillTemplate } from "@/lib/api";

const esc = (value: unknown) => String(value ?? "").replace(/[&<>"']/g, (c) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
}[c] || c));
const money = (n: number) => Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const formatDate = (s: string) => { const d = new Date(s); return Number.isNaN(d.getTime()) ? s : d.toLocaleDateString("en-IN"); };

function valueForHeader(header: string, item: InvoiceItem, index: number) {
  const h = header.toLowerCase().replace(/\s+/g, " ").trim();
  if (h === "#" || h.includes("s.n") || h.includes("serial")) return String(index + 1);
  if (h.includes("description") || h.includes("item name") || h === "item" || h.includes("goods")) return item.name;
  if (h.includes("hsn") || h.includes("sac")) return item.hsn || "-";
  if (h.includes("qty") || h.includes("quantity")) return String(item.qty);
  if (h.includes("unit")) return item.unit || "Pcs";
  if (h.includes("cgst") && h.includes("rate")) return `${(item.gstPercent || 0) / 2}%`;
  if (h.includes("sgst") && h.includes("rate")) return `${(item.gstPercent || 0) / 2}%`;
  if (h.includes("igst") && h.includes("rate")) return `${item.gstPercent || 0}%`;
  if (h.includes("cgst") && (h.includes("amount") || h.includes("amt"))) return money(item.cgst);
  if (h.includes("sgst") && (h.includes("amount") || h.includes("amt"))) return money(item.sgst);
  if (h.includes("igst") && (h.includes("amount") || h.includes("amt"))) return money(item.cgst + item.sgst);
  if (h.includes("gst") || h.includes("tax")) return money(item.cgst + item.sgst);
  if (h.includes("price") || h.includes("rate") || h.includes("unit price")) return money(item.rate);
  if (h.includes("amount") || h.includes("total")) return money(item.amount);
  return "";
}

function itemRow(item: InvoiceItem, index: number, templateRow?: string) {
  if (templateRow) {
    return templateRow
      .replace(/\{\{\s*(?:item\.)?index\s*\}\}/gi, String(index + 1))
      .replace(/\{\{\s*(?:item\.)?name\s*\}\}/gi, esc(item.name))
      .replace(/\{\{\s*(?:item\.)?hsn\s*\}\}/gi, esc(item.hsn || "-"))
      .replace(/\{\{\s*(?:item\.)?quantity\s*\}\}/gi, esc(item.qty))
      .replace(/\{\{\s*(?:item\.)?qty\s*\}\}/gi, esc(item.qty))
      .replace(/\{\{\s*(?:item\.)?unit\s*\}\}/gi, esc(item.unit || "Pcs"))
      .replace(/\{\{\s*(?:item\.)?price\s*\}\}/gi, money(item.rate))
      .replace(/\{\{\s*(?:item\.)?rate\s*\}\}/gi, money(item.rate))
      .replace(/\{\{\s*(?:item\.)?cgst_rate\s*\}\}/gi, String((item.gstPercent || 0) / 2))
      .replace(/\{\{\s*(?:item\.)?sgst_rate\s*\}\}/gi, String((item.gstPercent || 0) / 2))
      .replace(/\{\{\s*(?:item\.)?igst_rate\s*\}\}/gi, String(item.gstPercent || 0))
      .replace(/\{\{\s*(?:item\.)?cgst_amount\s*\}\}/gi, money(item.cgst))
      .replace(/\{\{\s*(?:item\.)?sgst_amount\s*\}\}/gi, money(item.sgst))
      .replace(/\{\{\s*(?:item\.)?igst_amount\s*\}\}/gi, money(item.cgst + item.sgst))
      .replace(/\{\{\s*(?:item\.)?cgst\s*\}\}/gi, money(item.cgst))
      .replace(/\{\{\s*(?:item\.)?sgst\s*\}\}/gi, money(item.sgst))
      .replace(/\{\{\s*(?:item\.)?(?:gst_percent|gstPercent|tax_rate)\s*\}\}/gi, String(item.gstPercent || 0))
      .replace(/\{\{\s*(?:item\.)?(?:total|line_total)\s*\}\}/gi, money(item.amount))
      .replace(/\{\{\s*(?:item\.)?amount\s*\}\}/gi, money(item.amount));
  }
  return `<tr><td>${index + 1}</td><td>${esc(item.name)}</td><td>${esc(item.hsn || "-")}</td><td>${esc(item.qty)}</td><td>${esc(item.unit || "Pcs")}</td><td>${money(item.rate)}</td><td>${(item.gstPercent || 0) / 2}%</td><td>${money(item.cgst)}</td><td>${(item.gstPercent || 0) / 2}%</td><td>${money(item.sgst)}</td><td>${money(item.amount)}</td></tr>`;
}

function scopeCss(css: string) {
  return css.replace(/(^|[{}])\s*([^@{}][^{}]+)\{/g, (full, prefix: string, selectorText: string) => {
    const selector = selectorText.trim();
    if (!selector || selector.startsWith("@")) return full;
    const scoped = selector.split(",").map((part: string) => {
      const trimmed = part.trim().replace(/^(html|body|:root)(?=\b|[.#:\[])/g, ".global-invoice-content");
      return trimmed.startsWith(".global-invoice-content") ? trimmed : `.global-invoice-content ${trimmed}`;
    }).join(", ");
    return `${prefix}${scoped}{`;
  });
}

export function renderGlobalTemplateHtml(template: GlobalBillTemplate, invoice: Invoice, shop: ShopInfo): string {
  if (template.fileType !== "text/html" && !/\.html?$/i.test(template.fileName)) {
    if (template.fileType.startsWith("image/")) return `<div class="global-invoice-content"><img style="max-width:100%;width:100%;height:auto" src="${esc(template.content)}" alt="Bill template reference"></div>`;
    if (template.fileType === "application/pdf") return `<div class="global-invoice-content"><p style="padding:12px;border:1px solid #ddd">This is a PDF reference template. Upload the editable HTML version to automatically populate invoice fields.</p></div>`;
    return "<div>Unsupported template file type.</div>";
  }

  let raw = template.content || "";
  const styleBlocks = Array.from(raw.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi)).map((m) => scopeCss(m[1]));
  let body = raw.match(/<body\b[^>]*>([\s\S]*?)<\/body>/i)?.[1] ?? raw;
  body = body.replace(/<!doctype[^>]*>/gi, "").replace(/<\/?(?:html|head|body)\b[^>]*>/gi, "");
  body = body.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "").replace(/<iframe\b[^>]*>[\s\S]*?<\/iframe>/gi, "");
  body = body.replace(/\s+on[a-z]+\s*=\s*(["']).*?\1/gi, "").replace(/javascript:/gi, "");

  // Identify item tables in plain externally-designed HTML, even when no CSS class was supplied.
  body = body.replace(/<table\b([^>]*)>([\s\S]*?)<\/table>/gi, (whole, attrs: string, inner: string) => {
    const header = inner.match(/<thead\b[^>]*>([\s\S]*?)<\/thead>/i)?.[1] || inner.match(/<tr\b[^>]*>([\s\S]*?)<\/tr>/i)?.[1] || "";
    const text = header.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").toLowerCase();
    const looksLikeItems = (text.includes("description") || text.includes("item name") || text.includes("goods")) &&
      (text.includes("qty") || text.includes("quantity")) && (text.includes("amount") || text.includes("price"));
    if (!looksLikeItems || /class\s*=\s*["'][^"']*\bitems?\b/i.test(attrs)) return whole;
    const classMatch = attrs.match(/class\s*=\s*(["'])(.*?)\1/i);
    const nextAttrs = classMatch
      ? attrs.replace(classMatch[0], `class=${classMatch[1]}${classMatch[2]} items${classMatch[1]}`)
      : `${attrs} class="items"`;
    return `<table${nextAttrs}>${inner}</table>`;
  });

  const defaultRows = invoice.items.map((item, i) => itemRow(item, i)).join("");
  // Match both {{#each items}}...{{/each}} and {{#items}}...{{/items}}.
  const itemLoop = /\{\{\s*#(?:each\s+)?items\s*\}\}([\s\S]*?)\{\{\s*\/(?:each|items)\s*\}\}/i;
  const loopMatch = body.match(itemLoop);
  if (loopMatch) {
    const rowTemplate = loopMatch[1];
    body = body.replace(itemLoop, invoice.items.map((item, i) => itemRow(item, i, rowTemplate)).join(""));
  } else {
    // Some uploaded HTML templates put a repeat-row template directly in tbody without loop tags.
    // Expand the first row containing item placeholders so the bill still renders real items.
    const tbodyMatch = body.match(/<tbody\b[^>]*>([\s\S]*?)<\/tbody>/i);
    if (tbodyMatch && /\{\{\s*item\./i.test(tbodyMatch[1])) {
      let expanded = false;
      const tbody = tbodyMatch[1].replace(/<tr\b[^>]*>[\s\S]*?<\/tr>/gi, (row) => {
        if (!expanded && /\{\{\s*item\./i.test(row)) {
          expanded = true;
          return invoice.items.map((item, i) => itemRow(item, i, row)).join("");
        }
        return row;
      });
      body = body.replace(tbodyMatch[0], tbodyMatch[0].replace(tbodyMatch[1], tbody));
    }
  }
  // Render {{items.rows}} using the actual column headers when possible; this avoids
  // inserting an 11-column generic row into a custom 6- or 8-column template.
  const headCells = Array.from(body.match(/<thead\b[^>]*>([\s\S]*?)<\/thead>/i)?.[1]?.matchAll(/<th\b[^>]*>([\s\S]*?)<\/th>/gi) || [])
    .map((m) => m[1].replace(/<[^>]*>/g, " ").replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/\s+/g, " ").trim());
  const headerRows = headCells.length ? invoice.items.map((item, index) => `<tr>${headCells.map((header) => `<td>${esc(valueForHeader(header, item, index))}</td>`).join("")}</tr>`).join("") : defaultRows;
  body = body.replace(/\{\{\s*items\.rows\s*\}\}/gi, headerRows);
  body = body.replace(/\{\{\s*items\.blankRows\s*:\s*(\d+)\s*:\s*(\d+)\s*\}\}/gi, (_whole, target: string, colCount: string) => {
    const count = Math.max(0, Math.min(20, Number(target) - invoice.items.length));
    const columns = Math.max(1, Math.min(20, Number(colCount)));
    const blankCells = Array.from({ length: columns }, () => '<td>&nbsp;</td>').join("");
    return Array.from({ length: count }, () => `<tr class="blank" style="height:6mm">${blankCells}</tr>`).join("");
  });

  const taxGroups = new Map<string, { hsn: string; rate: number; taxable: number; cgst: number; sgst: number; totalTax: number }>();
  for (const item of invoice.items) {
    const key = `${item.hsn || "-"}|${item.gstPercent || 0}`;
    const current = taxGroups.get(key) || { hsn: item.hsn || "-", rate: item.gstPercent || 0, taxable: 0, cgst: 0, sgst: 0, totalTax: 0 };
    const base = item.amount - item.cgst - item.sgst;
    current.taxable += base; current.cgst += item.cgst; current.sgst += item.sgst; current.totalTax += item.cgst + item.sgst;
    taxGroups.set(key, current);
  }
  const taxRows = Array.from(taxGroups.values()).map((t) => `<tr><td>${esc(t.hsn)}</td><td>${t.rate}%</td><td>${money(t.taxable)}</td><td>${money(t.cgst)}</td><td>${money(t.sgst)}</td><td>${money(t.totalTax)}</td></tr>`).join("");
  body = body.replace(/\{\{\s*#(?:each\s+)?tax_summary\s*\}\}[\s\S]*?\{\{\s*\/(?:each|tax_summary)\s*\}\}/gi, taxRows);
  body = body.replace(/\{\{\s*tax_summary\.rows\s*\}\}/gi, taxRows);

  const totalQty = invoice.items.reduce((sum, item) => sum + item.qty, 0);
  const totalTax = invoice.igst ?? (invoice.totalCgst + invoice.totalSgst);
  const amountWords = amountInWords(invoice.totalAmount);
  const partyName = invoice.partyName || "";
  const partyAddress = invoice.partyAddress || "";
  const shippingName = invoice.shipToName || partyName;
  const shippingAddress = invoice.shipToAddress || partyAddress;
  const values: Record<string, string> = {
    "business.name": shop.name, "business.businessName": shop.name, "business.address": shop.address,
    "business.phone": shop.phone, "business.email": shop.email || "", "business.gstin": shop.gst,
    "business.gst": shop.gst, "business.pan": shop.pan || "", "business.state": shop.state || "",
    "business.logo": shop.logoImage ? `<img src="${esc(shop.logoImage)}" alt="Logo" style="max-width:120px;max-height:60px;object-fit:contain">` : "",
    "business.bankName": shop.bankName || "", "business.bank_name": shop.bankName || "", "business.bankBranch": shop.bankBranch || "", "business.bank_branch": shop.bankBranch || "",
    "business.accountNo": shop.bankAccount || "", "business.bank_account": shop.bankAccount || "", "business.ifsc": shop.bankIfsc || "", "business.bank_ifsc": shop.bankIfsc || "",
    "business.terms": shop.termsAndConditions || "", "business.jurisdiction": shop.state || "local",
    "business.authorisedSignature": shop.signatureImage ? `<img src="${esc(shop.signatureImage)}" alt="Signature" style="max-width:150px;max-height:55px;object-fit:contain">` : "",
    "invoice.number": invoice.invoiceNumber, "invoice.invoiceNumber": invoice.invoiceNumber, "invoice.date": formatDate(invoice.date), "invoice.dateISO": invoice.date,
    "invoice.placeOfSupply": invoice.placeOfSupply || shop.state || "", "invoice.place_of_supply": invoice.placeOfSupply || shop.state || "",
    "invoice.reverseCharge": "No", "invoice.reverse_charge": "No", "invoice.transport": invoice.transport || "", "invoice.vehicleNo": invoice.vehicleNo || "", "invoice.vehicle_no": invoice.vehicleNo || "",
    "invoice.station": invoice.station || "", "invoice.ewayBill": invoice.ewayBill || "", "invoice.eway_bill_no": invoice.ewayBill || "", "invoice.grrrNo": "", "invoice.gr_rr_no": "",
    "invoice.description": invoice.description || "", "invoice.notes": invoice.description || "", "invoice.amountInWords": amountWords, "invoice.amount_in_words": amountWords,
    "invoice.total_quantity": String(totalQty), "invoice.totalQuantity": String(totalQty), "invoice.subtotal": money(invoice.subtotal), "invoice.taxable_total": money(invoice.subtotal),
    "invoice.grand_total": money(invoice.totalAmount), "invoice.grandTotal": money(invoice.totalAmount), "invoice.cgst_total": money(invoice.totalCgst), "invoice.sgst_total": money(invoice.totalSgst), "invoice.total_tax": money(totalTax),
    "invoice.qrCode": "", "invoice.eInvoiceQr": "", "invoice.qr_code": "",
    "customer.name": partyName, "party.name": partyName, "shipping.name": shippingName,
    "customer.address": partyAddress, "party.billingAddress": partyAddress, "customer.billingAddress": partyAddress,
    "shipping.address": shippingAddress, "customer.phone": invoice.partyPhone || "", "party.phone": invoice.partyPhone || "", "shipping.phone": invoice.partyPhone || "",
    "customer.gstin": invoice.partyGst || "", "party.gstin": invoice.partyGst || "", "shipping.gstin": invoice.partyGst || "",
    "customer.state": invoice.partyState || "", "party.state": invoice.partyState || "", "shipping.state": invoice.partyState || "",
    "customer.city_state_pincode": [partyAddress, invoice.partyState, invoice.partyPincode].filter(Boolean).join(", "),
    "shipping.city_state_pincode": [shippingAddress, invoice.partyState, invoice.partyPincode].filter(Boolean).join(", "),
    "gst.hsn": invoice.items[0]?.hsn || "", "gst.rate": `${invoice.items[0]?.gstPercent ?? 0}%`, "gst.taxable": money(invoice.subtotal), "gst.cgst": money(invoice.totalCgst), "gst.sgst": money(invoice.totalSgst), "gst.totalTax": money(totalTax),
    "totals.quantity": String(totalQty), "totals.unit": invoice.items[0]?.unit || "Pcs", "totals.subtotal": money(invoice.subtotal), "totals.taxable": money(invoice.subtotal), "totals.cgst": money(invoice.totalCgst), "totals.sgst": money(invoice.totalSgst), "totals.discount": "0.00", "totals.grandTotal": money(invoice.totalAmount), "totals.received": money(invoice.receivedAmount ?? invoice.totalAmount), "totals.balance": money(invoice.totalAmount - (invoice.receivedAmount ?? invoice.totalAmount)),
  };
  const normalizedValues = Object.fromEntries(Object.entries(values).map(([key, value]) => [key.toLowerCase(), value]));
  body = body.replace(/\{\{\s*([a-zA-Z0-9_.]+)\s*\}\}/gi, (_whole, key: string) => normalizedValues[key.toLowerCase()] ?? "");
  // Never ship broken moustache syntax (e.g. an unrecognized item.index) to preview/print.
  body = body.replace(/\{\{[\s\S]*?\}\}/g, "");

  const styles = styleBlocks.map((css) => `<style>${css}</style>`).join("");
  // The uploaded HTML/CSS owns its own page and table sizing. A fixed min-height or
  // flex column here stretches the first item row and creates a large blank gap.
  return `<div class="global-invoice-content" style="font-family:Arial,sans-serif;color:#111;width:100%;max-width:100%;box-sizing:border-box">${styles}${body}</div>`;
}

function amountInWords(amount: number) {
  const n = Math.floor(Math.abs(amount));
  if (!n) return "Zero";
  const ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
  const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
  const under1000 = (x: number): string => {
    if (x < 20) return ones[x];
    if (x < 100) return tens[Math.floor(x / 10)] + (x % 10 ? " " + ones[x % 10] : "");
    return ones[Math.floor(x / 100)] + " Hundred" + (x % 100 ? " " + under1000(x % 100) : "");
  };
  let rest = n; const parts: string[] = [];
  for (const [value, label] of [[10000000, "Crore"], [100000, "Lakh"], [1000, "Thousand"], [1, ""]] as [number, string][]) {
    const count = Math.floor(rest / value); rest %= value;
    if (count) parts.push((value === 1 ? under1000(count) : under1000(count)) + (label ? ` ${label}` : ""));
  }
  return parts.join(" ");
}
