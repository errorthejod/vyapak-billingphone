import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { hashPassword, normalizeMobile } from "@/lib/bb-users.server";
import { notifyCaAccessRequest } from "@/lib/bb-notify.server";

export interface CaAccountRecord {
  id: string;
  name: string;
  businessName: string;
  email: string;
  mobile: string;
  isActive: boolean;
  createdAt: string;
  accountType: "ca";
  caStatus: "pending" | "approved" | "rejected";
  caFirm: string;
  caRegistrationNo: string;
}

export interface CaAccessRecord {
  id: string;
  caId: string;
  caName: string;
  caFirm: string;
  caEmail: string;
  businessId: string;
  businessName: string;
  status: "pending" | "approved" | "rejected" | "revoked";
  createdAt: string;
  permissions: string[];
}

type UserRow = {
  id: string; name: string; business_name: string; email?: string | null; mobile?: string | null;
  is_active: boolean; created_at: string; account_type?: string | null; ca_status?: string | null;
  ca_firm?: string | null; ca_registration_no?: string | null; password_hash?: string | null; pin?: string;
};
type RequestRow = {
  id: string; ca_id: string; business_id: string; status: CaAccessRecord["status"];
  created_at: string; permissions: unknown;
};

function toCa(row: UserRow): CaAccountRecord {
  return {
    id: row.id, name: row.name, businessName: row.business_name, email: row.email || "",
    mobile: row.mobile || "", isActive: !!row.is_active, createdAt: row.created_at,
    accountType: "ca", caStatus: (row.ca_status as CaAccountRecord["caStatus"]) || "pending",
    caFirm: row.ca_firm || row.business_name, caRegistrationNo: row.ca_registration_no || "",
  };
}

async function getUser(id: string) {
  const { data, error } = await supabaseAdmin.from("bb_users").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return data as UserRow | null;
}

export async function signupCa(input: { name: string; firmName: string; email: string; mobile: string; password: string; registrationNo?: string }) {
  const email = input.email.trim().toLowerCase();
  const mobile = normalizeMobile(input.mobile);
  if (!input.name.trim() || !input.firmName.trim() || !email || mobile.length !== 10 || input.password.length < 6) {
    throw new Error("Complete all required fields and use a valid mobile number and password of at least 6 characters.");
  }
  const { data: found, error: duplicateError } = await supabaseAdmin.from("bb_users").select("id,email,mobile").or(`email.eq.${email},mobile.eq.${mobile}`);
  if (duplicateError) throw duplicateError;
  if ((found || []).length) throw new Error("An account with this email or mobile number already exists");

  const { data: config, error: configError } = await supabaseAdmin.from("bb_admin_config").select("next_ca_num").eq("id", 1).single();
  if (configError) throw configError;
  const number = Number((config as { next_ca_num?: number }).next_ca_num || 1);
  const id = `CA${String(number).padStart(3, "0")}`;
  const { data, error } = await supabaseAdmin.from("bb_users").insert({
    id, name: input.name.trim(), business_name: input.firmName.trim(), ca_firm: input.firmName.trim(),
    email, mobile, password_hash: await hashPassword(input.password), pin: "", is_active: false,
    account_type: "ca", ca_status: "pending", ca_registration_no: input.registrationNo?.trim() || "",
    is_trial: false, trial_used: false,
  }).select("*").single();
  if (error) throw error;
  const { error: incrementError } = await supabaseAdmin.from("bb_admin_config").update({ next_ca_num: number + 1 }).eq("id", 1);
  if (incrementError) throw incrementError;
  return toCa(data as UserRow);
}

export async function listCaAccounts(): Promise<CaAccountRecord[]> {
  const { data, error } = await supabaseAdmin.from("bb_users").select("*").eq("account_type", "ca").order("created_at", { ascending: false });
  if (error) throw error;
  return ((data || []) as UserRow[]).map(toCa);
}

export async function decideCaAccount(id: string, status: "approved" | "rejected") {
  const { data, error } = await supabaseAdmin.from("bb_users")
    .update({ ca_status: status, is_active: status === "approved" })
    .eq("id", id).eq("account_type", "ca").select("*").maybeSingle();
  if (error) throw error;
  if (!data) throw new Error("CA account not found");
  return toCa(data as UserRow);
}

export async function searchBusinessesForCa(caId: string, search: string) {
  const ca = await getUser(caId);
  if (!ca || ca.account_type !== "ca" || ca.ca_status !== "approved" || !ca.is_active) throw new Error("CA account is not approved");
  const query = search.trim();
  if (query.length < 2) return [] as { id: string; name: string; businessName: string }[];
  const safe = query.replace(/[,%()]/g, " ").trim();
  const { data, error } = await supabaseAdmin.from("bb_users").select("id,name,business_name,account_type")
    .eq("account_type", "business").or(`name.ilike.%${safe}%,business_name.ilike.%${safe}%,id.ilike.%${safe}%`).limit(20);
  if (error) throw error;
  return ((data || []) as { id: string; name: string; business_name: string }[]).map(row => ({ id: row.id, name: row.name, businessName: row.business_name }));
}

async function formatRequest(row: RequestRow): Promise<CaAccessRecord> {
  const [ca, business] = await Promise.all([getUser(row.ca_id), getUser(row.business_id)]);
  return {
    id: row.id, caId: row.ca_id, caName: ca?.name || row.ca_id, caFirm: ca?.ca_firm || ca?.business_name || "",
    caEmail: ca?.email || "", businessId: row.business_id, businessName: business?.business_name || business?.name || row.business_id,
    status: row.status, createdAt: row.created_at,
    permissions: Array.isArray(row.permissions) ? row.permissions as string[] : [],
  };
}

export async function listCaAccessRequests(params: { caId?: string; businessId?: string }) {
  if (!params.caId && !params.businessId) throw new Error("CA ID or business ID is required");
  let q = supabaseAdmin.from("bb_ca_access_requests").select("*").order("created_at", { ascending: false });
  if (params.caId) q = q.eq("ca_id", params.caId);
  if (params.businessId) q = q.eq("business_id", params.businessId);
  const { data, error } = await q;
  if (error) throw error;
  return Promise.all(((data || []) as RequestRow[]).map(formatRequest));
}

async function writeCaAudit(input: { requestId: string; caId: string; businessId: string; actorId: string; action: "requested" | "approved" | "rejected" | "revoked"; details?: Record<string, unknown> }) {
  const { error } = await supabaseAdmin.from("bb_ca_access_audit").insert({
    request_id: input.requestId, ca_id: input.caId, business_id: input.businessId,
    actor_id: input.actorId, action: input.action, details: input.details || {},
  } as never);
  if (error) throw error;
}

export async function sendCaAccessRequest(caId: string, businessId: string) {
  const [ca, business] = await Promise.all([getUser(caId), getUser(businessId)]);
  if (!ca || ca.account_type !== "ca" || ca.ca_status !== "approved" || !ca.is_active) throw new Error("CA must be approved before requesting access");
  if (!business || (business.account_type ?? "business") !== "business") throw new Error("Business account not found");
  const { data: previous, error: previousError } = await supabaseAdmin.from("bb_ca_access_requests").select("*").eq("ca_id", caId).eq("business_id", businessId).maybeSingle();
  if (previousError) throw previousError;
  if (previous && (previous as RequestRow).status === "approved") throw new Error("This business has already approved your access request");
  const { data, error } = await supabaseAdmin.from("bb_ca_access_requests").upsert({
    ca_id: caId, business_id: businessId, status: "pending",
    permissions: ["sales", "purchases", "expenses", "gst_reports", "invoice_history", "financial_reports"],
    created_at: new Date().toISOString(), updated_at: new Date().toISOString(),
  }, { onConflict: "ca_id,business_id" }).select("*").single();
  if (error) throw error;
  const formatted = await formatRequest(data as RequestRow);
  await writeCaAudit({ requestId: formatted.id, caId, businessId, actorId: caId, action: "requested" });
  await notifyCaAccessRequest({
    businessEmail: business.email || "", businessName: business.business_name,
    caName: ca.name, caFirm: ca.ca_firm || ca.business_name, caEmail: ca.email || "", requestId: formatted.id,
  });
  return formatted;
}

export async function decideCaAccessRequest(id: string, businessId: string, action: "approved" | "rejected" | "revoked") {
  const business = await getUser(businessId);
  if (!business || (business.account_type ?? "business") !== "business") throw new Error("Business account not found");
  const { data, error } = await supabaseAdmin.from("bb_ca_access_requests").update({ status: action, updated_at: new Date().toISOString() })
    .eq("id", id).eq("business_id", businessId).select("*").maybeSingle();
  if (error) throw error;
  if (!data) throw new Error("Access request not found for this business");
  const row = data as RequestRow;
  await writeCaAudit({
    requestId: row.id, caId: row.ca_id, businessId, actorId: businessId,
    action,
  });
  return formatRequest(row);
}
