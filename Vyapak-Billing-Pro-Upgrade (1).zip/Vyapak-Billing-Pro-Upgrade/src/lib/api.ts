const API_BASE = "/api";

function currentSessionToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem("bb-auth-store");
    const parsed = raw ? (JSON.parse(raw) as { state?: { sessionToken?: string | null } }) : null;
    return parsed?.state?.sessionToken || null;
  } catch {
    return null;
  }
}

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const headers = new Headers(options?.headers || {});
  if (!headers.has("Content-Type") && options?.body)
    headers.set("Content-Type", "application/json");
  const token = currentSessionToken();
  if (token && !headers.has("Authorization")) headers.set("Authorization", `Bearer ${token}`);
  if (typeof window !== "undefined") {
    const adminToken = window.sessionStorage.getItem("bb-admin-session-token");
    if (adminToken && !headers.has("x-admin-session")) headers.set("x-admin-session", adminToken);
  }
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data as T;
}

export interface GlobalBillTemplate {
  id: string;
  name: string;
  fileName: string;
  fileType: string;
  content: string;
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface CaAccessRequest {
  id: string;
  caId: string;
  caName: string;
  caFirm: string;
  caEmail: string;
  businessId: string;
  businessName: string;
  status: "pending" | "approved" | "rejected" | "revoked";
  createdAt: string;
  permissions: string[];
}

export interface CaAccount extends ApiUser {
  accountType: "ca";
  caStatus: "pending" | "approved" | "rejected" | null;
  caFirm: string;
  caRegistrationNo?: string;
}

export interface ApiUser {
  id: string;
  name: string;
  businessName: string;
  pin: string;
  email?: string;
  mobile?: string;
  isActive: boolean;
  createdAt: string;
  isTrial?: boolean;
  trialStart?: string | null;
  trialEnd?: string | null;
  trialUsed?: boolean;
  planName?: string | null;
  planExpiry?: string | null;
  accountType?: "business" | "ca";
  caStatus?: "pending" | "approved" | "rejected" | null;
  caFirm?: string | null;
  caRegistrationNo?: string | null;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  durationMonths: number;
  features: string[];
  isActive: boolean;
  sortOrder: number;
}

export type AccountStatus = "active" | "inactive" | "expired";

export interface AccountInfo {
  id: string;
  name: string;
  businessName: string;
  email: string;
  isActive: boolean;
  planId: string | null;
  planName: string | null;
  planPrice: number | null;
  planStart: string | null;
  planExpiry: string | null;
  status: AccountStatus;
  isTrial: boolean;
  trialStart: string | null;
  trialEnd: string | null;
  trialUsed: boolean;
  trialDaysLeft: number;
  trialExpired: boolean;
}

export interface PaymentRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  planId: string | null;
  planName: string;
  amount: number;
  durationMonths: number;
  utr: string;
  proofPath: string | null;
  proofName: string | null;
  status: "pending" | "approved" | "rejected";
  adminNote: string | null;
  createdAt: string;
}

export interface UserLedgerPayload {
  parties: unknown[];
  items: unknown[];
  invoices: unknown[];
  deletedInvoices: unknown[];
}

export interface CaBusinessData {
  business: { id: string; name: string; businessName: string };
  ledger: UserLedgerPayload;
  updatedAt: string | null;
}

export const api = {
  authenticateAdmin: (password: string) =>
    request<{ token: string; expiresIn: number }>("/admin/config", {
      method: "POST",
      body: JSON.stringify({ password }),
    }).then((r) => r.token),

  getUsers: () => request<{ users: ApiUser[] }>("/users").then((r) => r.users),

  login: (identifier: string, password: string) =>
    request<{ user: ApiUser; sessionToken: string }>("/users/login", {
      method: "POST",
      body: JSON.stringify({ identifier, password }),
    }),

  signup: (body: {
    name: string;
    businessName: string;
    email: string;
    mobile: string;
    password: string;
  }) =>
    request<{ user: ApiUser; sessionToken: string }>("/users/signup", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  createUser: (name: string, businessName: string, pin: string) =>
    request<{ user: ApiUser }>("/users", {
      method: "POST",
      body: JSON.stringify({ name, businessName, pin }),
    }).then((r) => r.user),

  updateUser: (
    id: string,
    updates: Partial<{ pin: string; isActive: boolean; name: string; businessName: string }>,
  ) =>
    request<{ user: ApiUser }>(`/users/${id}`, {
      method: "PUT",
      body: JSON.stringify(updates),
    }).then((r) => r.user),

  deleteUser: (id: string) => request<{ ok: boolean }>(`/users/${id}`, { method: "DELETE" }),

  getAdminConfig: () => request<{ paymentQrUrl: string; upiId: string }>("/admin/config"),

  getBillTemplates: (all = false) =>
    request<{ templates: GlobalBillTemplate[] }>(`/bill-templates${all ? "?all=1" : ""}`).then(
      (r) => r.templates,
    ),

  saveBillTemplates: (templates: GlobalBillTemplate[]) =>
    request<{ templates: GlobalBillTemplate[] }>("/bill-templates", {
      method: "PUT",
      body: JSON.stringify({ templates }),
    }).then((r) => r.templates),

  updateAdminConfig: (currentPassword: string, newPassword: string) =>
    request<{ ok: boolean }>("/admin/config", {
      method: "PUT",
      body: JSON.stringify({ currentPassword, newPassword }),
    }),

  updatePaymentDetails: (paymentQrUrl: string, upiId: string) =>
    request<{ ok: boolean }>("/admin/config", {
      method: "PUT",
      body: JSON.stringify({ paymentQrUrl, upiId }),
    }),

  getPlans: (all = false) =>
    request<{ plans: Plan[] }>(`/plans${all ? "?all=1" : ""}`).then((r) => r.plans),

  createPlan: (plan: Partial<Plan>) =>
    request<{ plan: Plan }>("/plans", { method: "POST", body: JSON.stringify(plan) }).then(
      (r) => r.plan,
    ),

  updatePlan: (id: string, plan: Partial<Plan>) =>
    request<{ plan: Plan }>(`/plans/${id}`, { method: "PUT", body: JSON.stringify(plan) }).then(
      (r) => r.plan,
    ),

  deletePlan: (id: string) => request<{ ok: boolean }>(`/plans/${id}`, { method: "DELETE" }),

  getAccount: (userId: string) =>
    request<{ account: AccountInfo; payments: PaymentRequest[]; plans: Plan[] }>(
      `/account/${encodeURIComponent(userId)}`,
    ),

  updateAccountEmail: (userId: string, email: string) =>
    request<{ account: AccountInfo }>(`/account/${encodeURIComponent(userId)}`, {
      method: "PUT",
      body: JSON.stringify({ email }),
    }).then((r) => r.account),

  getPayments: (userId?: string) =>
    request<{ payments: PaymentRequest[] }>(
      `/payments${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`,
    ).then((r) => r.payments),

  submitPayment: (body: {
    userId: string;
    planId: string;
    utr: string;
    fileName?: string;
    fileType?: string;
    fileBase64?: string;
  }) =>
    request<{
      payment: PaymentRequest;
      notifications?: {
        adminSent: boolean;
        buyerSent: boolean;
        emailConfigured?: boolean;
        adminReason?: string;
        buyerReason?: string;
      };
    }>("/payments", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  decidePayment: (id: string, status: "approved" | "rejected", adminNote?: string) =>
    request<{ payment: PaymentRequest }>(`/payments/${id}`, {
      method: "PUT",
      body: JSON.stringify({ status, adminNote }),
    }).then((r) => r.payment),

  getProofUrl: (id: string) => request<{ url: string }>(`/payments/${id}/proof`).then((r) => r.url),

  caSignup: (body: {
    name: string;
    firmName: string;
    email: string;
    mobile: string;
    password: string;
    registrationNo?: string;
  }) =>
    request<{ user: CaAccount }>("/ca-auth/signup", {
      method: "POST",
      body: JSON.stringify(body),
    }).then((r) => r.user),

  getCaAccounts: () => request<{ accounts: CaAccount[] }>("/ca-accounts").then((r) => r.accounts),

  decideCaAccount: (id: string, status: "approved" | "rejected") =>
    request<{ account: CaAccount }>(`/ca-accounts/${encodeURIComponent(id)}`, {
      method: "PATCH",
      body: JSON.stringify({ status }),
    }).then((r) => r.account),

  searchBusinessesForCa: (caId: string, query: string) =>
    request<{ businesses: { id: string; name: string; businessName: string }[] }>(
      `/ca-businesses?caId=${encodeURIComponent(caId)}&q=${encodeURIComponent(query)}`,
    ).then((r) => r.businesses),

  getCaAccessRequests: (params: { caId?: string; businessId?: string }) => {
    const q = new URLSearchParams();
    if (params.caId) q.set("caId", params.caId);
    if (params.businessId) q.set("businessId", params.businessId);
    return request<{ requests: CaAccessRequest[] }>(`/ca-requests?${q.toString()}`).then(
      (r) => r.requests,
    );
  },

  sendCaAccessRequest: (caId: string, businessId: string) =>
    request<{ request: CaAccessRequest }>("/ca-requests", {
      method: "POST",
      body: JSON.stringify({ caId, businessId }),
    }).then((r) => r.request),

  decideCaAccessRequest: (
    id: string,
    businessId: string,
    action: "approved" | "rejected" | "revoked",
  ) =>
    request<{ request: CaAccessRequest }>(`/ca-requests/${encodeURIComponent(id)}`, {
      method: "PATCH",
      body: JSON.stringify({ businessId, action }),
    }).then((r) => r.request),

  getSettings: (userId: string) =>
    request<{ settings: Record<string, unknown> | null }>(
      `/settings/${encodeURIComponent(userId)}`,
    ).then((r) => r.settings),

  getUserLedger: (userId: string) =>
    request<{ ledger: UserLedgerPayload | null }>(`/ledger/${encodeURIComponent(userId)}`).then(
      (r) => r.ledger,
    ),

  saveUserLedger: (userId: string, ledger: UserLedgerPayload) =>
    request<{ ok: boolean }>(`/ledger/${encodeURIComponent(userId)}`, {
      method: "PUT",
      body: JSON.stringify({ ledger }),
    }),

  getCaBusinessData: (businessId: string) =>
    request<CaBusinessData>(`/ca-business-data/${encodeURIComponent(businessId)}`),

  saveSettings: (userId: string, settings: Record<string, unknown>) =>
    request<{ ok: boolean }>(`/settings/${encodeURIComponent(userId)}`, {
      method: "PUT",
      body: JSON.stringify({ settings }),
    }),
};
