import "dotenv/config";

export const ADMIN_EMAIL = "vyapakbilling2026@gmail.com";

type EmailAttachment = {
  filename: string;
  content: string; // Base64-encoded file content
  content_type?: string;
};

type SendResult = { sent: boolean; reason?: string };

function isPlaceholderSender(value: string) {
  return !value || /verified-sender@your-domain\.com|onboarding@resend\.dev/i.test(value);
}

async function send(to: string, subject: string, html: string, attachments: EmailAttachment[] = []): Promise<SendResult> {
  const key = process.env["RESEND_API_KEY"]?.trim();
  const from = process.env["RESEND_FROM"]?.trim() || "";
  // Replies to all notification emails should go to the business owner's Gmail by default.
  const replyTo = process.env["RESEND_REPLY_TO"]?.trim() || ADMIN_EMAIL;
  if (!key || isPlaceholderSender(from) || !to) {
    const reason = !to ? "recipient-missing" : !key ? "resend-api-key-missing" : "verified-sender-missing";
    console.warn(`[notify:skipped] reason=${reason} subject=${subject}`);
    return { sent: false, reason };
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: [to],
        reply_to: [replyTo],
        subject,
        html,
        ...(attachments.length ? { attachments } : {}),
      }),
    });
    if (!res.ok) {
      const providerError = await res.text();
      console.error("[notify] provider rejected email", res.status, providerError.slice(0, 1200));
      return { sent: false, reason: `provider-error-${res.status}` };
    }
    return { sent: true };
  } catch (error) {
    console.error("[notify] send error", error instanceof Error ? error.message : String(error));
    return { sent: false, reason: "network-error" };
  }
}

function htmlEscape(value: unknown): string {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[char] || char));
}

function indianDateTime(value?: string) {
  const date = value ? new Date(value) : new Date();
  if (Number.isNaN(date.getTime())) return htmlEscape(value || "Not available");
  return date.toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "medium" });
}

function makeAttachment(file?: { fileName?: string; fileType?: string; fileBase64?: string }): EmailAttachment[] {
  if (!file?.fileBase64 || !file.fileType) return [];
  const allowedTypes = new Set(["image/png", "image/jpeg", "image/jpg", "application/pdf"]);
  if (!allowedTypes.has(file.fileType)) return [];
  // The client sends base64 without the data URL prefix, but tolerate it as well.
  const content = file.fileBase64.includes(",") ? file.fileBase64.slice(file.fileBase64.indexOf(",") + 1) : file.fileBase64;
  if (!content || content.length > 12 * 1024 * 1024) return [];
  const originalName = (file.fileName || (file.fileType === "application/pdf" ? "payment-proof.pdf" : "payment-proof.jpg"));
  const filename = originalName.replace(/[\r\n"\\/]/g, "_").slice(0, 120) || "payment-proof";
  return [{ filename, content, content_type: file.fileType }];
}

export async function notifyCaAccessRequest(p: { businessEmail?: string | null; businessName: string; caName: string; caFirm: string; caEmail: string; requestId: string }) {
  if (!p.businessEmail) return;
  await send(
    p.businessEmail,
    `CA access request for ${p.businessName} — Vyapak Billing`,
    `<h2>Chartered Accountant access request</h2>
     <p><b>${htmlEscape(p.caName)}</b> from <b>${htmlEscape(p.caFirm)}</b> (${htmlEscape(p.caEmail)}) has requested access to <b>${htmlEscape(p.businessName)}</b>.</p>
     <p>No business data has been shared. Review the request in Vyapak Billing → Settings → CA Access, then accept or reject it.</p>
     <p>Request reference: ${htmlEscape(p.requestId)}</p>`,
  );
}

export async function notifyProofSubmitted(p: {
  paymentId?: string;
  userId: string;
  userName: string;
  userEmail: string;
  planName: string;
  amount: number;
  utr: string;
  businessName?: string;
  mobile?: string;
  submittedAt?: string;
  proofStatus?: string;
  proofFile?: { fileName?: string; fileType?: string; fileBase64?: string };
}) {
  const when = indianDateTime(p.submittedAt);
  const attachments = makeAttachment(p.proofFile);
  const proofDescription = attachments.length
    ? `<p><b>Payment proof:</b> Attached (${htmlEscape(attachments[0].filename)}).</p>`
    : `<p><b>Payment proof:</b> ${p.proofFile?.fileName ? "File was uploaded but could not be attached to this email; review it in Admin Panel → Payments." : "No image/PDF attached; use the UTR/reference ID below to verify."}</p>`;
  const rows = `
    <p><b>Purchase request ID:</b> ${htmlEscape(p.paymentId || "Not available")}</p>
    <p><b>Account ID:</b> ${htmlEscape(p.userId)}</p>
    <p><b>Buyer name:</b> ${htmlEscape(p.userName)}</p>
    <p><b>Business/shop:</b> ${htmlEscape(p.businessName || "Not provided")}</p>
    <p><b>Buyer email:</b> ${htmlEscape(p.userEmail || "Not provided")}</p>
    <p><b>Mobile:</b> ${htmlEscape(p.mobile || "Not provided")}</p>
    <p><b>Plan/rank:</b> ${htmlEscape(p.planName)}</p>
    <p><b>Purchase amount:</b> ₹${htmlEscape(p.amount)}</p>
    <p><b>UTR / transaction reference:</b> ${htmlEscape(p.utr)}</p>
    <p><b>Purchase submitted (IST):</b> ${htmlEscape(when)}</p>
    <p><b>Payment status:</b> ${htmlEscape(p.proofStatus || "Pending verification")}</p>
    ${proofDescription}`;

  const adminResult = await send(
    ADMIN_EMAIL,
    `New purchase request — ${p.planName} — ${p.userName}`,
    `<h2>New Vyapak Billing purchase request</h2>
     <p>A customer has submitted a plan/rank purchase for verification.</p>${rows}
     <p><b>Next step:</b> Open Admin Panel → Payments to review the payment request and approve or reject it. The plan must not be activated until verified.</p>`,
    attachments,
  );

  let buyerResult: SendResult = { sent: false, reason: "buyer-email-missing" };
  if (p.userEmail) {
    buyerResult = await send(
      p.userEmail,
      `Purchase request received — ${p.planName} — Vyapak Billing`,
      `<h2>We've received your purchase request</h2>
       <p>Hi ${htmlEscape(p.userName)}, your purchase/payment details have been received and are pending verification. This email is a receipt of your request, not confirmation that payment has been approved.</p>${rows}
       <p>We will email you again after the payment is approved or rejected.</p>`,
      attachments,
    );
  }
  return {
    adminSent: adminResult.sent,
    buyerSent: buyerResult.sent,
    emailConfigured: adminResult.reason !== "resend-api-key-missing" && adminResult.reason !== "verified-sender-missing",
    adminReason: adminResult.reason,
    buyerReason: buyerResult.reason,
  };
}

export async function notifyDecision(p: {
  userEmail: string;
  userName: string;
  planName: string;
  approved: boolean;
  note?: string | null;
  expiry?: string | null;
}) {
  const decision = p.approved ? "approved" : "rejected";
  const expiryText = p.expiry ? new Date(p.expiry).toLocaleDateString("en-IN", { timeZone: "Asia/Kolkata" }) : "Not available";
  const adminHtml = `<h2>Purchase ${decision}</h2><p><b>Buyer:</b> ${htmlEscape(p.userName)} (${htmlEscape(p.userEmail)})</p><p><b>Plan/rank:</b> ${htmlEscape(p.planName)}</p><p><b>Decision:</b> ${decision}</p>${p.approved ? `<p><b>Plan expiry:</b> ${htmlEscape(expiryText)}</p>` : `<p><b>Reason:</b> ${htmlEscape(p.note || "No reason provided")}</p>`}`;
  await send(ADMIN_EMAIL, `Purchase ${decision} — ${p.planName} — ${p.userName}`, adminHtml);
  if (!p.userEmail) return;
  await send(
    p.userEmail,
    p.approved ? "Your Vyapak Billing plan is active" : "Your Vyapak Billing payment could not be verified",
    p.approved
      ? `<h2>Plan activated 🎉</h2><p>Hi ${htmlEscape(p.userName)}, your <b>${htmlEscape(p.planName)}</b> plan is now active${p.expiry ? ` until <b>${htmlEscape(expiryText)}</b>` : ""}.</p>`
      : `<h2>Payment not verified</h2><p>Hi ${htmlEscape(p.userName)}, we couldn't verify your payment for <b>${htmlEscape(p.planName)}</b>.</p>${p.note ? `<p>Reason: ${htmlEscape(p.note)}</p>` : ""}<p>Please re-submit your payment proof.</p>`,
  );
}
