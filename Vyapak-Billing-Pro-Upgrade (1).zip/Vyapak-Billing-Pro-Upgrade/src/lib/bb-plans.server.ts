import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { TRIAL_DAYS } from "@/lib/bb-users.server";

export interface Plan {
  id: string;
  name: string;
  price: number;
  durationMonths: number;
  features: string[];
  isActive: boolean;
  sortOrder: number;
}

export interface PaymentRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  planId: string | null;
  planName: string;
  amount: number;
  durationMonths: number;
  utr: string;
  proofPath: string | null;
  proofName: string | null;
  status: "pending" | "approved" | "rejected";
  adminNote: string | null;
  createdAt: string;
}

export const PROOF_BUCKET = "payment-proofs";

/* ------------------------------------------------------------------ plans */

type PlanRow = {
  id: string;
  name: string;
  price: number;
  duration_months: number;
  features: unknown;
  is_active: boolean;
  sort_order: number;
};

function toPlan(r: PlanRow): Plan {
  return {
    id: r.id,
    name: r.name,
    price: Number(r.price),
    durationMonths: r.duration_months,
    features: Array.isArray(r.features) ? (r.features as string[]) : [],
    isActive: r.is_active,
    sortOrder: r.sort_order,
  };
}

export async function listPlans(includeInactive = false): Promise<Plan[]> {
  let q = supabaseAdmin.from("bb_plans").select("*").order("sort_order");
  if (!includeInactive) q = q.eq("is_active", true);
  const { data, error } = await q;
  if (error) throw error;
  return (data as PlanRow[]).map(toPlan);
}

export async function createPlan(input: Partial<Plan>): Promise<Plan> {
  const { data, error } = await supabaseAdmin
    .from("bb_plans")
    .insert({
      name: input.name || "New Plan",
      price: input.price ?? 0,
      duration_months: input.durationMonths ?? 12,
      features: input.features ?? [],
      is_active: input.isActive ?? true,
      sort_order: input.sortOrder ?? 99,
    })
    .select()
    .single();
  if (error) throw error;
  return toPlan(data as PlanRow);
}

export async function updatePlan(id: string, input: Partial<Plan>): Promise<Plan | undefined> {
  const patch: {
    name?: string; price?: number; duration_months?: number;
    features?: string[]; is_active?: boolean; sort_order?: number;
  } = {};
  if (input.name !== undefined) patch['name'] = input.name;
  if (input.price !== undefined) patch['price'] = input.price;
  if (input.durationMonths !== undefined) patch['duration_months'] = input.durationMonths;
  if (input.features !== undefined) patch['features'] = input.features;
  if (input.isActive !== undefined) patch['is_active'] = input.isActive;
  if (input.sortOrder !== undefined) patch['sort_order'] = input.sortOrder;
  const { data, error } = await supabaseAdmin
    .from("bb_plans")
    .update(patch)
    .eq("id", id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data ? toPlan(data as PlanRow) : undefined;
}

export async function deletePlan(id: string) {
  const { error } = await supabaseAdmin.from("bb_plans").delete().eq("id", id);
  if (error) throw error;
}

/* -------------------------------------------------------------- payments */

type PaymentRow = {
  id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  plan_id: string | null;
  plan_name: string;
  amount: number;
  duration_months: number;
  utr: string;
  proof_path: string | null;
  proof_name: string | null;
  status: string;
  admin_note: string | null;
  created_at: string;
};

function toPayment(r: PaymentRow): PaymentRequest {
  return {
    id: r.id,
    userId: r.user_id,
    userName: r.user_name,
    userEmail: r.user_email,
    planId: r.plan_id,
    planName: r.plan_name,
    amount: Number(r.amount),
    durationMonths: r.duration_months,
    utr: r.utr,
    proofPath: r.proof_path,
    proofName: r.proof_name,
    status: (r.status as PaymentRequest["status"]) || "pending",
    adminNote: r.admin_note,
    createdAt: r.created_at,
  };
}

export async function listPayments(userId?: string): Promise<PaymentRequest[]> {
  let q = supabaseAdmin
    .from("bb_payment_requests")
    .select("*")
    .order("created_at", { ascending: false });
  if (userId) q = q.eq("user_id", userId);
  const { data, error } = await q;
  if (error) throw error;
  return (data as PaymentRow[]).map(toPayment);
}

const ALLOWED_PROOF = /^(image\/(png|jpe?g)|application\/pdf)$/;

export async function submitPayment(input: {
  userId: string;
  planId: string;
  utr: string;
  fileName?: string;
  fileType?: string;
  fileBase64?: string;
}): Promise<PaymentRequest> {
  const { data: userRow, error: userErr } = await supabaseAdmin
    .from("bb_users")
    .select("*")
    .eq("id", input.userId)
    .maybeSingle();
  if (userErr) throw userErr;
  if (!userRow) throw new Error("Account not found");

  const plans = await listPlans(true);
  const plan = plans.find((p) => p.id === input.planId);
  if (!plan) throw new Error("Plan not found");

  let proofPath: string | null = null;
  let proofName: string | null = null;
  if (input.fileBase64 && input.fileType) {
    if (!ALLOWED_PROOF.test(input.fileType)) throw new Error("Only JPG, PNG or PDF files are allowed");
    const bytes = Uint8Array.from(atob(input.fileBase64), (c) => c.charCodeAt(0));
    if (bytes.byteLength > 8 * 1024 * 1024) throw new Error("File must be under 8 MB");
    const ext = input.fileType === "application/pdf" ? "pdf" : input.fileType === "image/png" ? "png" : "jpg";
    proofPath = `${input.userId}/${Date.now()}-${crypto.randomUUID()}.${ext}`;
    proofName = input.fileName || `proof.${ext}`;
    const { error: upErr } = await supabaseAdmin.storage
      .from(PROOF_BUCKET)
      .upload(proofPath, bytes, { contentType: input.fileType, upsert: false });
    if (upErr) throw upErr;
  }

  const { data, error } = await supabaseAdmin
    .from("bb_payment_requests")
    .insert({
      user_id: input.userId,
      user_name: (userRow as { name: string }).name,
      user_email: (userRow as { email?: string }).email || "",
      plan_id: plan.id,
      plan_name: plan.name,
      amount: plan.price,
      duration_months: plan.durationMonths,
      utr: input.utr.trim(),
      proof_path: proofPath,
      proof_name: proofName,
      status: "pending",
    })
    .select()
    .single();
  if (error) throw error;
  return toPayment(data as PaymentRow);
}

export async function proofUrl(id: string): Promise<string | null> {
  const { data, error } = await supabaseAdmin
    .from("bb_payment_requests")
    .select("proof_path")
    .eq("id", id)
    .maybeSingle();
  if (error) throw error;
  const path = (data as { proof_path: string | null } | null)?.proof_path;
  if (!path) return null;
  const signed = await supabaseAdmin.storage.from(PROOF_BUCKET).createSignedUrl(path, 60 * 10);
  return signed.data?.signedUrl ?? null;
}

function addMonths(from: Date, months: number) {
  const d = new Date(from.getTime());
  d.setMonth(d.getMonth() + months);
  return d;
}

export async function decidePayment(
  id: string,
  status: "approved" | "rejected",
  adminNote?: string,
): Promise<PaymentRequest | undefined> {
  const { data: row, error } = await supabaseAdmin
    .from("bb_payment_requests")
    .update({ status, admin_note: adminNote ?? null })
    .eq("id", id)
    .select()
    .maybeSingle();
  if (error) throw error;
  if (!row) return undefined;
  const payment = toPayment(row as PaymentRow);

  if (status === "approved") {
    const { data: userRow } = await supabaseAdmin
      .from("bb_users")
      .select("plan_expiry")
      .eq("id", payment.userId)
      .maybeSingle();
    const currentExpiry = (userRow as { plan_expiry?: string | null } | null)?.plan_expiry;
    const now = new Date();
    const base = currentExpiry && new Date(currentExpiry) > now ? new Date(currentExpiry) : now;
    await supabaseAdmin
      .from("bb_users")
      .update({
        is_active: true,
        // Paid plan takes over; the free trial is finished for good.
        is_trial: false,
        trial_used: true,
        plan_id: payment.planId,
        plan_name: payment.planName,
        plan_price: payment.amount,
        plan_start: now.toISOString(),
        plan_expiry: addMonths(base, payment.durationMonths).toISOString(),
      })
      .eq("id", payment.userId);
  }
  return payment;
}

/* ------------------------------------------------------------ user plans */

export type AccountStatus = "active" | "inactive" | "expired";

export interface AccountInfo {
  id: string;
  name: string;
  businessName: string;
  email: string;
  isActive: boolean;
  planId: string | null;
  planName: string | null;
  planPrice: number | null;
  planStart: string | null;
  planExpiry: string | null;
  status: AccountStatus;
  isTrial: boolean;
  trialStart: string | null;
  trialEnd: string | null;
  trialUsed: boolean;
  trialDaysLeft: number;
  trialExpired: boolean;
}

export function trialActive(row: { is_trial?: boolean | null; trial_end?: string | null }) {
  return !!row.is_trial && !!row.trial_end && new Date(row.trial_end).getTime() > Date.now();
}

export function statusOf(row: {
  is_active: boolean;
  plan_expiry?: string | null;
  is_trial?: boolean | null;
  trial_end?: string | null;
}): AccountStatus {
  // A running free trial has the same access as a paid active plan.
  if (trialActive(row)) return "active";
  if (!row.is_active) return "inactive";
  if (row.plan_expiry && new Date(row.plan_expiry).getTime() < Date.now()) return "expired";
  // Trial finished with no paid plan -> expired.
  if (!row.plan_expiry && row.trial_end && new Date(row.trial_end).getTime() <= Date.now())
    return "expired";
  return "active";
}

export async function getAccount(userId: string): Promise<AccountInfo | undefined> {
  const { data, error } = await supabaseAdmin
    .from("bb_users")
    .select("*")
    .eq("id", userId)
    .maybeSingle();
  if (error) throw error;
  if (!data) return undefined;
  let r = data as {
    id: string; name: string; business_name: string; email?: string; is_active: boolean;
    plan_id?: string | null; plan_name?: string | null; plan_price?: number | null;
    plan_start?: string | null; plan_expiry?: string | null;
    is_trial?: boolean | null; trial_start?: string | null; trial_end?: string | null;
    trial_used?: boolean | null;
    account_type?: string | null;
  };

  // Server-side expiry: the trial ends on the server clock, so a tampered
  // browser date or local state cannot extend access.
  const paidActive = !!r.plan_expiry && new Date(r.plan_expiry).getTime() > Date.now();

  // One-time backfill: accounts created before the trial fields existed never
  // got their single 7-day trial. Grant it once (trial_used locks it forever),
  // never for accounts that already have trial dates or a paid plan.
  if ((r.account_type ?? "business") !== "ca" && !r.trial_used && !r.trial_start && !r.trial_end && !r.plan_expiry) {
    const start = new Date();
    const end = new Date(start.getTime() + TRIAL_DAYS * 86400000);
    const patch = {
      is_trial: true,
      trial_used: true,
      trial_start: start.toISOString(),
      trial_end: end.toISOString(),
      is_active: true,
    };
    await supabaseAdmin.from("bb_users").update(patch).eq("id", userId);
    r = { ...r, ...patch };
  }

  // Enforce the seven-day limit for trials created when the app used a longer
  // duration. This is server-side and also caps already-existing trial records
  // the first time the account is checked after this update.
  if (
    (r.account_type ?? "business") !== "ca" &&
    r.is_trial &&
    r.trial_start &&
    r.trial_end &&
    !r.plan_expiry
  ) {
    const maxTrialEnd = new Date(new Date(r.trial_start).getTime() + TRIAL_DAYS * 86400000);
    const currentTrialEnd = new Date(r.trial_end);
    if (Number.isFinite(currentTrialEnd.getTime()) && currentTrialEnd.getTime() > maxTrialEnd.getTime()) {
      const cappedEnd = maxTrialEnd.toISOString();
      const { error: capError } = await supabaseAdmin
        .from("bb_users")
        .update({ trial_end: cappedEnd })
        .eq("id", userId);
      if (capError) throw capError;
      r = { ...r, trial_end: cappedEnd };
    }
  }

  if (r.is_trial && r.trial_end && new Date(r.trial_end).getTime() <= Date.now()) {
    const patch = { is_trial: false, is_active: paidActive ? r.is_active : false };
    await supabaseAdmin.from("bb_users").update(patch).eq("id", userId);
    r = { ...r, ...patch };
  }


  const trialEnd = r.trial_end ?? null;
  const trialDaysLeft = trialActive(r)
    ? Math.max(1, Math.ceil((new Date(trialEnd as string).getTime() - Date.now()) / 86400000))
    : 0;

  return {
    id: r.id,
    name: r.name,
    businessName: r.business_name,
    email: r.email || "",
    isActive: r.is_active,
    planId: r.plan_id ?? null,
    planName: r.plan_name ?? null,
    planPrice: r.plan_price != null ? Number(r.plan_price) : null,
    planStart: r.plan_start ?? null,
    planExpiry: r.plan_expiry ?? null,
    status: statusOf(r),
    isTrial: trialActive(r),
    trialStart: r.trial_start ?? null,
    trialEnd,
    trialUsed: !!r.trial_used,
    trialDaysLeft,
    trialExpired: !!trialEnd && !trialActive(r) && !paidActive,
  };
}

export async function setUserPlan(
  userId: string,
  updates: { planId?: string | null; planExpiry?: string | null; isActive?: boolean },
) {
  const patch: {
    is_active?: boolean; plan_expiry?: string | null; plan_id?: string | null;
    plan_name?: string | null; plan_price?: number | null; plan_start?: string | null;
  } = {};
  if (updates.isActive !== undefined) patch['is_active'] = updates.isActive;
  if (updates.planExpiry !== undefined) patch['plan_expiry'] = updates.planExpiry;
  if (updates.planId !== undefined) {
    if (updates.planId) {
      const plan = (await listPlans(true)).find((p) => p.id === updates.planId);
      if (plan) {
        patch['plan_id'] = plan.id;
        patch['plan_name'] = plan.name;
        patch['plan_price'] = plan.price;
        if (updates.planExpiry === undefined) {
          const now = new Date();
          patch['plan_start'] = now.toISOString();
          patch['plan_expiry'] = addMonths(now, plan.durationMonths).toISOString();
        }
      }
    } else {
      patch['plan_id'] = null;
      patch['plan_name'] = null;
      patch['plan_price'] = null;
      patch['plan_expiry'] = null;
    }
  }
  const { error } = await supabaseAdmin.from("bb_users").update(patch).eq("id", userId);
  if (error) throw error;
}
