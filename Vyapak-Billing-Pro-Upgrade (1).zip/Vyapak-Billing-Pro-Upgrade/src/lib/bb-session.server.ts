/** Signed app-session tokens for privacy-sensitive CA and ledger API routes. */
export interface SessionClaims {
  id: string;
  accountType: "business" | "ca" | "admin";
  expiresAt: number;
}

const encoder = new TextEncoder();
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const ADMIN_SESSION_TTL_MS = 4 * 60 * 60 * 1000;

function secretValue() {
  // Reuse the server-only Supabase secret if no dedicated session secret was configured.
  const value = process.env["APP_SESSION_SECRET"] || process.env["SUPABASE_SERVICE_ROLE_KEY"] || "";
  if (value.length < 24)
    throw new Error(
      "Set APP_SESSION_SECRET (at least 24 characters) or configure SUPABASE_SERVICE_ROLE_KEY",
    );
  return value;
}

function encode(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function decode(value: string) {
  const base64 =
    value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - (value.length % 4)) % 4);
  return Uint8Array.from(atob(base64), (char) => char.charCodeAt(0));
}

async function signingKey() {
  return crypto.subtle.importKey(
    "raw",
    encoder.encode(secretValue()),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
}

export async function createSessionToken(
  id: string,
  accountType: "business" | "ca" | "admin",
  ttlMs = SESSION_TTL_MS,
) {
  const payload = encode(
    encoder.encode(JSON.stringify({ id, accountType, expiresAt: Date.now() + ttlMs })),
  );
  const content = `v1.${payload}`;
  const signature = new Uint8Array(
    await crypto.subtle.sign("HMAC", await signingKey(), encoder.encode(content)),
  );
  return `${content}.${encode(signature)}`;
}

export async function getSessionClaims(request: Request): Promise<SessionClaims | null> {
  const authorization = request.headers.get("authorization") || "";
  const token = authorization.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return null;
  const [version, payload, signature, extra] = token.split(".");
  if (version !== "v1" || !payload || !signature || extra) return null;
  try {
    const valid = await crypto.subtle.verify(
      "HMAC",
      await signingKey(),
      decode(signature),
      encoder.encode(`${version}.${payload}`),
    );
    if (!valid) return null;
    const claims = JSON.parse(new TextDecoder().decode(decode(payload))) as SessionClaims;
    if (
      !claims.id ||
      !["business", "ca", "admin"].includes(claims.accountType) ||
      !Number.isFinite(claims.expiresAt)
    )
      return null;
    if (claims.expiresAt <= Date.now()) return null;
    return claims;
  } catch {
    return null;
  }
}

/** Admin sessions are separate from business/CA sessions and expire after four hours. */
export async function createAdminSessionToken() {
  return createSessionToken("admin", "admin", ADMIN_SESSION_TTL_MS);
}

export async function getAdminSessionClaims(request: Request): Promise<SessionClaims | null> {
  const token = request.headers.get("x-admin-session");
  if (!token) return null;
  const adminRequest = new Request(request.url, { headers: { authorization: `Bearer ${token}` } });
  const claims = await getSessionClaims(adminRequest);
  return claims?.accountType === "admin" && claims.id === "admin" ? claims : null;
}
