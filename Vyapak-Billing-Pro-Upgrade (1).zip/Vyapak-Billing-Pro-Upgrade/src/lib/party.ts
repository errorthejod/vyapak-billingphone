import { Party, GstFirm, PartyKind } from "@/types";

/** GST state code = first two digits of the GSTIN */
export function stateCodeFromGstin(gstin?: string): string {
  const g = (gstin || "").trim();
  return /^\d{2}/.test(g) ? g.slice(0, 2) : "";
}

export function partyKindOf(party: Party): PartyKind {
  return party.kind ?? (party.gst ? "gst" : "normal");
}

/** Everything a bill needs from a saved party — no external GST API involved. */
export interface PartyBillFields {
  partyId: string;
  partyName: string;
  partyLegalName: string;
  partyGst: string;
  partyAddress: string;
  partyState: string;
  partyStateCode: string;
  partyPincode: string;
  partyPhone: string;
  partyEmail: string;
  partyGstDetails: string;
  partyKind: PartyKind;
}

export interface PartyOption extends PartyBillFields {
  /** id of the underlying record ("firm-<id>" for legacy GST firm entries) */
  id: string;
  label: string;
  /** true when the option comes from the legacy GST firms list */
  fromFirm: boolean;
}

export function partyToOption(party: Party): PartyOption {
  const kind = partyKindOf(party);
  return {
    id: party.id,
    label: party.name,
    fromFirm: false,
    partyId: party.id,
    partyName: party.name,
    partyLegalName: party.legalName || "",
    partyGst: party.gst || "",
    partyAddress: party.address || "",
    partyState: party.state || "",
    partyStateCode: party.stateCode || stateCodeFromGstin(party.gst),
    partyPincode: party.pincode || "",
    partyPhone: party.phone || "",
    partyEmail: party.email || "",
    partyGstDetails: party.gstDetails || "",
    partyKind: kind,
  };
}

/** Legacy "GST firms" saved before parties supported GST details. */
export function firmToOption(firm: GstFirm): PartyOption {
  return {
    id: `firm-${firm.id}`,
    label: firm.businessName,
    fromFirm: true,
    partyId: "",
    partyName: firm.businessName,
    partyLegalName: firm.ownerName || "",
    partyGst: firm.gstin || "",
    partyAddress: firm.address || "",
    partyState: "",
    partyStateCode: stateCodeFromGstin(firm.gstin),
    partyPincode: "",
    partyPhone: firm.phone || "",
    partyEmail: "",
    partyGstDetails: "",
    partyKind: "gst",
  };
}

/**
 * All saved parties (plus legacy GST firms) as bill suggestions.
 * A firm that already exists as a party (same GSTIN or name) is not duplicated.
 */
export function buildPartyOptions(parties: Party[], gstFirms: GstFirm[] = []): PartyOption[] {
  const options = parties.map(partyToOption);
  const seenGst = new Set(options.map(o => o.partyGst.trim().toUpperCase()).filter(Boolean));
  const seenName = new Set(options.map(o => o.partyName.trim().toLowerCase()));
  gstFirms.forEach(f => {
    const gst = (f.gstin || "").trim().toUpperCase();
    const name = (f.businessName || "").trim().toLowerCase();
    if ((gst && seenGst.has(gst)) || (name && seenName.has(name))) return;
    options.push(firmToOption(f));
  });
  return options;
}

/** Search by name, legal name, GSTIN, phone, email, address, state or pincode. */
export function searchPartyOptions(options: PartyOption[], query: string): PartyOption[] {
  const q = query.trim().toLowerCase();
  if (!q) return options.slice(0, 30);
  const haystack = (o: PartyOption) =>
    [
      o.partyName,
      o.partyLegalName,
      o.partyGst,
      o.partyPhone,
      o.partyEmail,
      o.partyAddress,
      o.partyState,
      o.partyStateCode,
      o.partyPincode,
      o.partyGstDetails,
    ]
      .join(" ")
      .toLowerCase();

  return options
    .filter(o => haystack(o).includes(q))
    .sort((a, b) => {
      const aStarts = a.partyName.toLowerCase().startsWith(q) ? 0 : 1;
      const bStarts = b.partyName.toLowerCase().startsWith(q) ? 0 : 1;
      if (aStarts !== bStarts) return aStarts - bStarts;
      return a.partyName.localeCompare(b.partyName);
    })
    .slice(0, 30);
}
