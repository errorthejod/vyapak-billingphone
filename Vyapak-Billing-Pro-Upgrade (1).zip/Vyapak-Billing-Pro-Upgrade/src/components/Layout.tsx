import { AppSidebar } from "./AppSidebar";
import { TrialBanner } from "./TrialBanner";
import { useState } from "react";
import { Menu, X } from "lucide-react";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-20 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className={`fixed inset-y-0 left-0 z-30 md:relative md:translate-x-0 transition-transform duration-200 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
        <AppSidebar />
      </div>

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="md:hidden glass-panel sticky top-0 z-10 flex items-center gap-3 px-4 py-3">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-1.5 rounded-xl hover:bg-muted transition-colors">
            {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
          <div className="flex items-center gap-2">
            <div className="brand-gradient glow-primary h-7 w-7 rounded-lg shrink-0 flex items-center justify-center">
              <span className="text-xs font-black text-primary-foreground">V</span>
            </div>
            <span className="brand-text font-extrabold tracking-tight">
              Vyapak Billing
            </span>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-4 md:p-6">
          <TrialBanner />
          {children}
        </main>
      </div>
    </div>
  );
}
