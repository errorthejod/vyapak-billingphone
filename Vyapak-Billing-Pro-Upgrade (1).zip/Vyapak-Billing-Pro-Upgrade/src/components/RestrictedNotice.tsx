import { Link } from "@/lib/nav";
import { Button } from "@/components/ui/button";
import { Lock, Sparkles, CreditCard } from "lucide-react";
import { useAccessStore } from "@/store/useAccessStore";

export function RestrictedNotice() {
  const account = useAccessStore((s) => s.account);
  const expired = account?.status === "expired";
  // Trial users that never bought a plan get trial-specific wording.
  const trialOver = !!account?.trialEnd && !account?.planExpiry;

  return (
    <div className="flex min-h-[70vh] items-center justify-center p-4">
      <div className="w-full max-w-lg rounded-2xl border border-border bg-card p-8 text-center shadow-sm">
        <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-destructive/10">
          <Lock className="h-6 w-6 text-destructive" />
        </div>
        <h1 className="text-xl font-bold text-foreground">
          {trialOver
            ? "Your 7-day free trial has expired."
            : expired
              ? "Your plan has expired"
              : "Your plan is inactive"}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {trialOver
            ? "Renew your plan to continue using Vyapak Billing. Your previous bills and data are safe and stay viewable."
            : "Your plan is inactive. Renew your plan to unlock billing features."}
        </p>

        {trialOver && account?.trialEnd && (
          <p className="mt-3 text-xs text-muted-foreground">
            Trial ended on{" "}
            <span className="font-semibold text-foreground">
              {new Date(account.trialEnd).toLocaleDateString("en-IN")}
            </span>
          </p>
        )}

        {account?.planExpiry && (
          <p className="mt-3 text-xs text-muted-foreground">
            {expired ? "Expired on " : "Valid till "}
            <span className="font-semibold text-foreground">
              {new Date(account.planExpiry).toLocaleDateString("en-IN")}
            </span>
          </p>
        )}

        <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:justify-center">
          <Button asChild variant="outline">
            <Link to="/plans">
              <Sparkles className="mr-2 h-4 w-4" />
              View Plans
            </Link>
          </Button>
          <Button asChild>
            <Link to="/plans?renew=1">
              <CreditCard className="mr-2 h-4 w-4" />
              Renew Now
            </Link>
          </Button>
        </div>

        <p className="mt-6 text-xs text-muted-foreground">
          Need help? Email us at{" "}
          <a className="text-primary underline" href="mailto:vyapakbilling2026@gmail.com">
            vyapakbilling2026@gmail.com
          </a>
        </p>
      </div>
    </div>
  );
}
