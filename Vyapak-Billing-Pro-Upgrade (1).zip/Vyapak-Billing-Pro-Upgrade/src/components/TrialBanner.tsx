import { Link } from "@/lib/nav";
import { Sparkles } from "lucide-react";
import { useAccessStore } from "@/store/useAccessStore";

/** Small notice shown while a 7-day free trial is running. */
export function TrialBanner() {
  const account = useAccessStore((s) => s.account);
  if (!account?.isTrial) return null;
  const days = account.trialDaysLeft;

  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-primary/30 bg-primary/5 px-4 py-2.5">
      <p className="flex items-center gap-2 text-sm font-medium text-foreground">
        <Sparkles className="h-4 w-4 text-primary" />
        Free Trial — {days} {days === 1 ? "day" : "days"} remaining
      </p>
      <Link
        to="/plans"
        className="text-xs font-semibold text-primary underline underline-offset-2"
      >
        Upgrade now
      </Link>
    </div>
  );
}
