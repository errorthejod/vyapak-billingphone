import { BillStyle } from "@/types";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const ACCENT_PRESETS = ["#000000", "#1e40af", "#047857", "#b91c1c", "#7c3aed", "#c2410c", "#0e7490", "#be185d"];

const LAYOUTS = [
  { id: "classic", label: "Classic" },
  { id: "modern", label: "Modern" },
  { id: "compact", label: "Compact" },
  { id: "gst", label: "GST Theme" },
] as const;

const COPY_PRESETS = ["ORIGINAL FOR RECIPIENT", "DUPLICATE FOR TRANSPORT", "TRIPLICATE FOR SUPPLIER"];

const ThemeThumb = ({ layout, label, accent, active, onClick }: { layout: BillStyle["layout"]; label: string; accent: string; active: boolean; onClick: () => void }) => {
  const filled = layout === "modern" || layout === "gst";
  return (
    <button type="button" onClick={onClick}
      className={`rounded-lg border-2 p-1 bg-card transition-all ${active ? "border-primary shadow-sm" : "border-border hover:border-muted-foreground/40"}`}>
      <div className="w-full aspect-[4/5] bg-white rounded-[3px] border border-border/50 overflow-hidden flex flex-col p-1 gap-[3px]">
        <div className="flex justify-between items-center">
          <div className="h-[5px] w-3/5 rounded-full bg-neutral-800" />
          <div className="h-[4px] w-1/5 rounded-full bg-neutral-300" />
        </div>
        {layout === "modern" ? (
          <div className="h-[7px] w-full rounded-[2px]" style={{ backgroundColor: accent }} />
        ) : layout === "compact" ? (
          <div className="h-[5px] w-2/5 mx-auto rounded-full border-b-2" style={{ borderColor: accent }} />
        ) : layout === "gst" ? (
          <div className="h-[5px] w-2/5 mx-auto rounded-full" style={{ backgroundColor: accent }} />
        ) : (
          <div className="h-[7px] w-full rounded-[2px] border-y" style={{ backgroundColor: `${accent}14`, borderColor: accent }} />
        )}
        <div className="flex gap-[3px]">
          <div className="h-[9px] flex-[2] border border-neutral-300 rounded-[2px]" />
          <div className="h-[9px] flex-1 border border-neutral-300 rounded-[2px]" />
        </div>
        <div className="h-[6px] w-full rounded-[2px]" style={{ backgroundColor: filled ? accent : `${accent}20` }} />
        <div className="h-[4px] w-full rounded-full bg-neutral-200" />
        <div className="h-[4px] w-full rounded-full bg-neutral-200" />
        <div className="h-[4px] w-4/5 rounded-full bg-neutral-200" />
        <div className="mt-auto ml-auto h-[5px] w-2/5 rounded-full" style={{ backgroundColor: filled ? accent : `${accent}33` }} />
      </div>
      <p className={`text-[10px] font-medium text-center mt-1 leading-tight ${active ? "text-primary" : "text-foreground"}`}>{label}</p>
    </button>
  );
};

const StyleToggle = ({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) => (
  <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
    <Label className="text-xs">{label}</Label>
    <Switch checked={checked} onCheckedChange={onChange} />
  </div>
);

/** Shared bill design controls — used by Settings (global) and the Bill Editor (per bill). */
export const BillStyleControls = ({ style, onChange }: { style: BillStyle; onChange: (updates: Partial<BillStyle>) => void }) => (
  <Tabs defaultValue="layout">
    <TabsList className="grid w-full grid-cols-4">
      <TabsTrigger value="layout" className="text-xs px-1">Layout</TabsTrigger>
      <TabsTrigger value="colours" className="text-xs px-1">Colours</TabsTrigger>
      <TabsTrigger value="header" className="text-xs px-1">Header</TabsTrigger>
      <TabsTrigger value="more" className="text-xs px-1">More</TabsTrigger>
    </TabsList>

    <TabsContent value="layout" className="space-y-3 pt-3">
      <div>
        <Label className="text-xs text-muted-foreground">Change layout / theme</Label>
        <div className="grid grid-cols-4 gap-2 mt-2">
          {LAYOUTS.map((l) => (
            <ThemeThumb key={l.id} layout={l.id} label={l.label} accent={style.accentColor}
              active={style.layout === l.id} onClick={() => onChange({ layout: l.id })} />
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs text-muted-foreground">Paper size</Label>
          <Select value={style.paperSize} onValueChange={(v) => onChange({ paperSize: v as BillStyle["paperSize"] })}>
            <SelectTrigger className="mt-1 h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="a4">A4</SelectItem>
              <SelectItem value="a5">A5 (compact)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">Orientation</Label>
          <Select value={style.orientation} onValueChange={(v) => onChange({ orientation: v as BillStyle["orientation"] })}>
            <SelectTrigger className="mt-1 h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="portrait">Portrait</SelectItem>
              <SelectItem value="landscape">Landscape</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">Company name text size</Label>
          <Select value={style.companyNameSize} onValueChange={(v) => onChange({ companyNameSize: v as BillStyle["companyNameSize"] })}>
            <SelectTrigger className="mt-1 h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="small">Small</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="large">Large</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">Invoice text size</Label>
          <Select value={style.invoiceTextSize} onValueChange={(v) => onChange({ invoiceTextSize: v as BillStyle["invoiceTextSize"] })}>
            <SelectTrigger className="mt-1 h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="small">Small</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="large">Large</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </TabsContent>

    <TabsContent value="colours" className="space-y-3 pt-3">
      <div>
        <Label className="text-xs text-muted-foreground">Accent colour</Label>
        <div className="flex items-center gap-2 mt-2 flex-wrap">
          {ACCENT_PRESETS.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => onChange({ accentColor: c })}
              className={`h-7 w-7 rounded-full border-2 transition-transform hover:scale-110 ${style.accentColor === c ? "border-foreground scale-110" : "border-border"}`}
              style={{ backgroundColor: c }}
              title={c}
            />
          ))}
          <input
            type="color"
            value={style.accentColor}
            onChange={(e) => onChange({ accentColor: e.target.value })}
            className="h-7 w-10 cursor-pointer rounded border border-border bg-transparent"
            title="Custom colour"
          />
        </div>
        <p className="text-[11px] text-muted-foreground mt-2">Colours the title band, table header and totals highlights.</p>
      </div>
    </TabsContent>

    <TabsContent value="header" className="space-y-2 pt-3">
      <p className="text-[11px] text-muted-foreground">Print Company Info / Header — the text itself comes from your Business Profile above.</p>
      <div className="grid grid-cols-2 gap-2">
        <StyleToggle label="Company name" checked={style.showCompanyName} onChange={(v) => onChange({ showCompanyName: v })} />
        <StyleToggle label="Company logo" checked={style.showLogo} onChange={(v) => onChange({ showLogo: v })} />
        <StyleToggle label="Address" checked={style.showAddress} onChange={(v) => onChange({ showAddress: v })} />
        <StyleToggle label="Phone number" checked={style.showPhone} onChange={(v) => onChange({ showPhone: v })} />
        <StyleToggle label="Email" checked={style.showEmail} onChange={(v) => onChange({ showEmail: v })} />
        <StyleToggle label="GSTIN on sale" checked={style.showGstin} onChange={(v) => onChange({ showGstin: v })} />
      </div>
      <div className="rounded-lg border border-border px-3 py-2 space-y-2">
        <div className="flex items-center justify-between">
          <Label className="text-xs">Print Original / Duplicate label</Label>
          <Switch checked={style.showCopyLabel} onCheckedChange={(v) => onChange({ showCopyLabel: v })} />
        </div>
        {style.showCopyLabel && (
          <>
            <div className="flex flex-wrap gap-1">
              {COPY_PRESETS.map((p) => (
                <button key={p} type="button" onClick={() => onChange({ copyLabel: p })}
                  className={`text-[10px] px-2 py-1 rounded-full border transition-colors ${style.copyLabel === p ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:bg-muted"}`}>
                  {p}
                </button>
              ))}
            </div>
            <Input value={style.copyLabel} onChange={(e) => onChange({ copyLabel: e.target.value.toUpperCase() })}
              placeholder="ORIGINAL FOR RECIPIENT" className="text-xs h-8" />
          </>
        )}
      </div>
    </TabsContent>

    <TabsContent value="more" className="space-y-3 pt-3">
      <div>
        <Label className="text-xs text-muted-foreground">Item table columns</Label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          <StyleToggle label="HSN/SAC column" checked={style.showHsn} onChange={(v) => onChange({ showHsn: v })} />
          <StyleToggle label="Unit column" checked={style.showUnit} onChange={(v) => onChange({ showUnit: v })} />
        </div>
      </div>
      <div>
        <Label className="text-xs text-muted-foreground">Bill content</Label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          <StyleToggle label="Show signature" checked={style.showSignature} onChange={(v) => onChange({ showSignature: v })} />
          <StyleToggle label="Show stamp" checked={style.showStamp} onChange={(v) => onChange({ showStamp: v })} />
          <StyleToggle label="Show terms" checked={style.showTerms} onChange={(v) => onChange({ showTerms: v })} />
          <StyleToggle label="Amount in words" checked={style.showAmountInWords} onChange={(v) => onChange({ showAmountInWords: v })} />
          <StyleToggle label="GST breakup" checked={style.showGstBreakup} onChange={(v) => onChange({ showGstBreakup: v })} />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs text-muted-foreground">Extra space on top (mm)</Label>
          <Input type="number" min={0} max={40} value={style.topMargin}
            onChange={(e) => onChange({ topMargin: Math.max(0, Number(e.target.value)) })} className="text-sm mt-1 h-9" />
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">Bill height / page fill (%)</Label>
          <Input type="number" min={50} max={100} value={style.pageFill ?? 100}
            onChange={(e) => onChange({ pageFill: Math.min(100, Math.max(50, Number(e.target.value) || 100)) })} className="text-sm mt-1 h-9" />
          <p className="text-[10px] text-muted-foreground mt-1">100% = bill stretches over the full sheet.</p>
        </div>
      </div>
      <div>
        <Label className="text-xs text-muted-foreground">Logo, signature &amp; stamp size (px)</Label>
        <div className="grid grid-cols-3 gap-2 mt-2">
          <div>
            <Label className="text-[10px] text-muted-foreground">Logo</Label>
            <Input type="number" min={20} max={200} value={style.logoSize ?? 65}
              onChange={(e) => onChange({ logoSize: Math.min(200, Math.max(20, Number(e.target.value) || 65)) })} className="text-sm mt-1 h-9" />
          </div>
          <div>
            <Label className="text-[10px] text-muted-foreground">Signature</Label>
            <Input type="number" min={20} max={160} value={style.signatureSize ?? 48}
              onChange={(e) => onChange({ signatureSize: Math.min(160, Math.max(20, Number(e.target.value) || 48)) })} className="text-sm mt-1 h-9" />
          </div>
          <div>
            <Label className="text-[10px] text-muted-foreground">Stamp</Label>
            <Input type="number" min={20} max={160} value={style.stampSize ?? 36}
              onChange={(e) => onChange({ stampSize: Math.min(160, Math.max(20, Number(e.target.value) || 36)) })} className="text-sm mt-1 h-9" />
          </div>
        </div>
      </div>
    </TabsContent>
  </Tabs>
);
