import { downloadInvoicePdf, printInvoiceElement } from "@/lib/printInvoice";
import { useState, useRef, useEffect } from "react";
import { useCurrentStore as useStore } from "@/store/useCurrentStore";
import { InvoiceItem, Invoice, TaxType, GST_RATES } from "@/types";
import { InvoiceTemplate } from "@/components/InvoiceTemplate";
import { api, GlobalBillTemplate } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, FileText, Printer, Download, User, Calendar, Hash, Percent, IndianRupee } from "lucide-react";
import { toast } from "sonner";

function getFinancialYear(dateStr: string): string {
  const d = new Date(dateStr);
  const year = d.getFullYear();
  return `${year}-${year + 1}`;
}

const SuggestionInput = ({
  value,
  onChange,
  suggestions,
  placeholder,
  className = "",
}: {
  value: string;
  onChange: (val: string, selected?: { id?: string; phone?: string; address?: string; gst?: string }) => void;
  suggestions: { label: string; id?: string; phone?: string; address?: string; gst?: string }[];
  placeholder: string;
  className?: string;
}) => {
  const [query, setQuery] = useState(value);
  const [show, setShow] = useState(false);
  const q = query.trim().toLowerCase();
  const filtered = suggestions.filter((s) =>
    !q ||
    s.label.toLowerCase().includes(q) ||
    (s.phone || "").toLowerCase().includes(q) ||
    (s.gst || "").toLowerCase().includes(q)
  );


  return (
    <div className="relative">
      <Input
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setShow(true);
          onChange(e.target.value);
        }}
        onFocus={(e) => { setShow(true); e.target.select(); }}
        onBlur={() => setTimeout(() => setShow(false), 200)}
        placeholder={placeholder}
        className={className}
      />
      {show && query && filtered.length > 0 && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1 bg-popover border border-border rounded-lg shadow-xl max-h-44 overflow-auto">
          {filtered.map((s, idx) => (
            <button
              key={s.id || idx}
              className="w-full text-left px-3 py-2.5 text-sm hover:bg-accent/10 border-b border-border/40 last:border-0"
              onMouseDown={() => { setQuery(s.label); setShow(false); onChange(s.label, s); }}
            >
              <span className="font-medium">{s.label}</span>
              {s.phone && <span className="ml-2 text-xs text-muted-foreground">{s.phone}</span>}
              {s.gst && <span className="ml-2 text-[10px] font-medium text-primary">{s.gst}</span>}
            </button>

          ))}
        </div>
      )}
    </div>
  );
};

const ProductInput = ({
  value,
  onChange,
  items: productList,
}: {
  value: string;
  onChange: (name: string, itemId?: string, rate?: number, gstPercent?: number, unit?: string) => void;
  items: { id: string; name: string; price: number; gstPercent: number; unit: string }[];
}) => {
  const [query, setQuery] = useState(value);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const filtered = productList.filter((p) =>
    p.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="relative">
      <Input
        value={query}
        onChange={(e) => { setQuery(e.target.value); setShowSuggestions(true); onChange(e.target.value); }}
        onFocus={(e) => { setShowSuggestions(true); e.target.select(); }}
        onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
        placeholder="Item / Service name"
        className="text-sm"
      />
      {showSuggestions && query && filtered.length > 0 && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1 bg-popover border border-border rounded-lg shadow-xl max-h-44 overflow-auto">
          {filtered.map((item) => (
            <button
              key={item.id}
              className="w-full text-left px-3 py-2.5 text-sm hover:bg-accent/10 border-b border-border/40 last:border-0"
              onMouseDown={() => { setQuery(item.name); setShowSuggestions(false); onChange(item.name, item.id, item.price, item.gstPercent, item.unit); }}
            >
              <span className="font-medium">{item.name}</span>
              <span className="ml-2 text-xs text-muted-foreground">₹{item.price}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

const emptyItem = (): InvoiceItem => ({
  itemId: "", name: "", qty: 1, rate: 0, gstPercent: 18, amount: 0, cgst: 0, sgst: 0,
});




const calcFromRate = (item: InvoiceItem): InvoiceItem => {
  const baseAmount = item.qty * item.rate;
  const gstAmount = (baseAmount * item.gstPercent) / 100;
  const amount = baseAmount + gstAmount;
  return { ...item, amount, cgst: gstAmount / 2, sgst: gstAmount / 2 };
};

const calcFromAmount = (item: InvoiceItem): InvoiceItem => {
  const divisor = 1 + item.gstPercent / 100;
  const baseAmount = divisor > 0 ? item.amount / divisor : item.amount;
  const gstAmount = item.amount - baseAmount;
  const rate = item.qty > 0 ? baseAmount / item.qty : 0;
  return { ...item, rate, cgst: gstAmount / 2, sgst: gstAmount / 2 };
};

interface Props {
  open: boolean;
  onClose: () => void;
  editInvoice?: Invoice | null;
}

export function SaleFormDialog({ open, onClose, editInvoice }: Props) {
  const { parties, items, invoices, addInvoice, updateInvoice, addParty, updateParty, addItem, shopInfo, gstFirms } = useStore();
  const isEditMode = !!editInvoice;
  const [savedInvoice, setSavedInvoice] = useState<Invoice | null>(null);
  const [globalBillTemplates, setGlobalBillTemplates] = useState<GlobalBillTemplate[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState("");
  const invoiceRef = useRef<HTMLDivElement>(null);

  
  const [creditOn, setCreditOn] = useState(false);


  const isAllNonGst = (invoiceItems: InvoiceItem[]) =>
    invoiceItems.length > 0 && invoiceItems.every((it) => it.gstPercent === 0);

  const getNextInvoiceNum = (nonGst = false, offset = 0) => {
    const count = invoices.filter((i) => i.type === "sale").length + 1 + offset;
    const num = String(count).padStart(4, "0");
    return nonGst ? `inv.non-gst.${num}` : `inv.GST.${num}`;
  };

  const makeDefaultForm = () => {
    if (editInvoice) {
      return {
        partyId: editInvoice.partyId || "",
        partyName: editInvoice.partyName,
        partyAddress: editInvoice.partyAddress || "",
        partyPhone: editInvoice.partyPhone || "",
        partyGst: editInvoice.partyGst || "",
        date: editInvoice.date,
        invoiceItems: editInvoice.items.length > 0 ? editInvoice.items : [emptyItem()],
        invoiceYear: editInvoice.invoiceYear || getFinancialYear(editInvoice.date),
        invoiceNumber: editInvoice.invoiceNumber,
        description: editInvoice.description || "",
        received: editInvoice.receivedAmount != null ? String(editInvoice.receivedAmount) : "",
      };
    }
    const today = new Date().toISOString().split("T")[0];
    const fy = getFinancialYear(today);
    return {
      partyId: "", partyName: "", partyAddress: "", partyPhone: "", partyGst: "",
      date: today,
      invoiceItems: [emptyItem()],
      invoiceYear: fy,
      invoiceNumber: getNextInvoiceNum(false),
      description: "",
      received: "",
    };
  };

  const [form, setForm] = useState(makeDefaultForm());

  useEffect(() => {
    if (open) {
      setForm(makeDefaultForm());
      setSavedInvoice(null);
      api.getBillTemplates().then((templates) => {
        const activeTemplates = templates.filter((template) => template.active).sort((a, b) => a.sortOrder - b.sortOrder);
        setGlobalBillTemplates(activeTemplates);
        const preferredId = editInvoice?.templateId || shopInfo.activeTemplateId;
        const preferred = activeTemplates.find((template) => template.id === preferredId)?.id || activeTemplates[0]?.id || "";
        setSelectedTemplateId(preferred);
      }).catch(() => { setGlobalBillTemplates([]); setSelectedTemplateId(""); });
      if (editInvoice) {
        setCreditOn(
          editInvoice.isCredit ??
          (editInvoice.totalAmount - (editInvoice.receivedAmount ?? editInvoice.totalAmount) > 0),
        );
      } else {
        setCreditOn(shopInfo.creditEnabledByDefault ?? false);
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editInvoice]);


  const updateItem = (index: number, updates: Partial<InvoiceItem>, fromAmount = false) => {
    setForm((prev) => {
      const newItems = [...prev.invoiceItems];
      const merged = { ...newItems[index], ...updates };
      newItems[index] = fromAmount ? calcFromAmount(merged) : calcFromRate(merged);

      let invoiceNumber = prev.invoiceNumber;
      if ('gstPercent' in updates) {
        const nonGst = isAllNonGst(newItems);
        invoiceNumber = invoiceNumber
          .replace(/inv\.non-gst\./i, nonGst ? 'inv.non-gst.' : 'inv.GST.')
          .replace(/inv\.GST\./i, nonGst ? 'inv.non-gst.' : 'inv.GST.');
      }

      return { ...prev, invoiceItems: newItems, invoiceNumber };
    });
  };

  const addItemRow = () => setForm((prev) => ({ ...prev, invoiceItems: [...prev.invoiceItems, emptyItem()] }));
  const removeItemRow = (index: number) => setForm((prev) => ({ ...prev, invoiceItems: prev.invoiceItems.filter((_, i) => i !== index) }));

  /**
   * CREDIT mode suggests only the GST firms saved with the "Add GST" button.
   * CASH mode suggests only customers that were remembered automatically while
   * saving earlier bills. The two lists never mix.
   */
  const gstPartySuggestions = gstFirms.map((f) => ({
    label: f.businessName || f.ownerName,
    id: f.id,
    phone: f.phone,
    address: f.address,
    gst: f.gstin,
  }));

  const cashCustomerSuggestions = (() => {
    const map = new Map<string, { label: string; id?: string; phone?: string; address?: string; gst?: string }>();
    invoices
      .filter((inv) => inv.type === "sale" && inv.partyName?.trim())
      .forEach((inv) => {
        const key = inv.partyName.trim().toLowerCase();
        map.set(key, {
          label: inv.partyName.trim(),
          id: inv.partyId || undefined,
          phone: inv.partyPhone || map.get(key)?.phone || "",
          address: inv.partyAddress || map.get(key)?.address || "",
        });
      });
    return Array.from(map.values());
  })();

  const totalCgst = form.invoiceItems.reduce((s, i) => s + i.cgst, 0);
  const totalSgst = form.invoiceItems.reduce((s, i) => s + i.sgst, 0);
  /** GST applies automatically whenever any row carries a GST rate. */
  const gstOn = form.invoiceItems.some((i) => i.gstPercent > 0);
  /**
   * Intra-state (CGST + SGST) vs inter-state (IGST) is derived from the seller's
   * state code and the customer's GSTIN — never chosen by hand.
   */
  const sellerStateCode = (shopInfo.stateCode || shopInfo.gst || "").replace(/\s/g, "").slice(0, 2);
  const buyerStateCode = (form.partyGst || "").replace(/\s/g, "").slice(0, 2);
  const taxType: TaxType =
    gstOn && sellerStateCode.length === 2 && buyerStateCode.length === 2 && sellerStateCode !== buyerStateCode
      ? "igst"
      : shopInfo.defaultTaxType && !buyerStateCode ? shopInfo.defaultTaxType : "cgst_sgst";
  const totalGst = gstOn ? totalCgst + totalSgst : 0;
  const isIgst = taxType === "igst";

  const totalAmount = form.invoiceItems.reduce((s, i) => s + i.amount, 0);
  const subtotal = totalAmount - totalGst;
  const receivedAmount = !creditOn
    ? totalAmount
    : form.received.trim() === ""
      ? 0
      : Math.min(totalAmount, Math.max(0, Number(form.received) || 0));
  const creditAmount = Math.max(0, totalAmount - receivedAmount);

  const handleSave = () => {
    if (!selectedTemplateId || !globalBillTemplates.some((template) => template.id === selectedTemplateId && template.active)) {
      toast.error("No active bill template is available. Ask the administrator to enable a template.");
      return;
    }
    if (!form.partyName) { toast.error("Please enter customer name"); return; }
    if (form.invoiceItems.some((i) => !i.name || i.amount <= 0)) { toast.error("Please fill all item details"); return; }

    // Auto-save new party if not already in the list
    const partyExists = parties.some(
      (p) => p.name.trim().toLowerCase() === form.partyName.trim().toLowerCase()
    );
    let savedPartyId = form.partyId;
    if (!partyExists) {
      const newParty = {
        id: `party-${Date.now()}`,
        name: form.partyName.trim(),
        phone: form.partyPhone || "",
        address: form.partyAddress || "",
        gst: form.partyGst || undefined,
        type: "customer" as const,
        balance: 0,
        createdAt: new Date().toISOString(),
      };
      addParty(newParty);
      savedPartyId = newParty.id;
    }

    // Auto-save new items if not already in the list
    form.invoiceItems.forEach((invItem) => {
      if (!invItem.name) return;
      const itemExists = items.some(
        (it) => it.name.trim().toLowerCase() === invItem.name.trim().toLowerCase()
      );
      if (!itemExists) {
        addItem({
          id: invItem.itemId || `item-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          name: invItem.name.trim(),
          price: invItem.rate,
          gstPercent: invItem.gstPercent,
          stock: 0,
          unit: invItem.unit || "pcs",
          hsn: invItem.hsn,
        });
      }
    });

    const invoice: Invoice = {
      id: isEditMode ? editInvoice!.id : Date.now().toString(),
      invoiceNumber: form.invoiceNumber,
      invoiceYear: form.invoiceYear,
      date: form.date,
      templateId: selectedTemplateId || undefined,
      partyId: savedPartyId,
      partyName: form.partyName,
      partyAddress: form.partyAddress,
      partyPhone: form.partyPhone,
      partyGst: form.partyGst,
      items: form.invoiceItems,
      subtotal, totalCgst, totalSgst,
      igst: totalGst,
      totalAmount,
      receivedAmount,
      gstEnabled: gstOn,
      taxType,
      isCredit: creditOn && creditAmount > 0,
      sellerGstin: gstOn ? shopInfo.gst : undefined,
      sellerState: shopInfo.state,
      sellerStateCode: shopInfo.stateCode,
      description: form.description || undefined,
      type: "sale",
      createdAt: isEditMode ? editInvoice!.createdAt : new Date().toISOString(),
    };

    // Keep the customer's outstanding credit balance in sync
    const previousCredit = isEditMode
      ? Math.max(0, editInvoice!.totalAmount - (editInvoice!.receivedAmount ?? editInvoice!.totalAmount))
      : 0;
    const creditDelta = creditAmount - previousCredit;
    if (creditDelta !== 0 && savedPartyId) {
      const party = parties.find((p) => p.id === savedPartyId);
      if (party) updateParty(savedPartyId, { balance: Math.max(0, (party.balance || 0) + creditDelta) });
    }

    if (isEditMode) {
      updateInvoice(editInvoice!.id, invoice);
      toast.success(`Invoice ${form.invoiceNumber} updated!`);
      setSavedInvoice(invoice);
    } else {
      addInvoice(invoice);
      toast.success(`Invoice ${form.invoiceNumber} saved!`);
      setSavedInvoice(invoice);
      const today = new Date().toISOString().split("T")[0];
      const fy = getFinancialYear(today);
      setForm({
        partyId: "", partyName: "", partyAddress: "", partyPhone: "", partyGst: "",
        date: today,
        invoiceItems: [emptyItem()],
        invoiceYear: fy,
        invoiceNumber: getNextInvoiceNum(false, 1),
        description: "",
        received: "",
      });
    }
  };

  const handlePrint = async (invoice: Invoice) => {
    try { await printInvoiceElement(invoiceRef.current, invoice.invoiceNumber || "Invoice"); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Could not print invoice"); }
  };

  const handleDownloadPDF = async () => {
    if (!invoiceRef.current) return;
    toast.info("Generating PDF...");
    try {
      await downloadInvoicePdf(invoiceRef.current, savedInvoice?.invoiceNumber || "invoice", { orientation: "portrait", format: "a4" });
      toast.success("PDF downloaded!");
    } catch {
      toast.error("Failed to generate PDF");
    }
  };

  const handleClose = () => {
    setSavedInvoice(null);
    setForm(makeDefaultForm());
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[92vh] overflow-auto p-0">
        {savedInvoice ? (
          <div>
            <div className="flex items-center justify-between px-5 py-3 border-b bg-card">
              <DialogTitle className="flex items-center gap-2 text-base font-semibold">
                <FileText className="h-4 w-4 text-primary" />
                {savedInvoice.invoiceNumber} — Saved
              </DialogTitle>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => handlePrint(savedInvoice)}>
                  <Printer className="h-4 w-4 mr-1.5" /> Print
                </Button>
                <Button size="sm" onClick={handleDownloadPDF}>
                  <Download className="h-4 w-4 mr-1.5" /> PDF
                </Button>
              </div>
            </div>
            <div className="p-4">
              <InvoiceTemplate ref={invoiceRef} invoice={savedInvoice} shopInfo={shopInfo} />
              <div className="flex justify-end gap-2 mt-4 pt-3 border-t">
                <Button variant="outline" onClick={() => setSavedInvoice(null)}>+ Create Another</Button>
                <Button onClick={handleClose}>Done</Button>
              </div>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center justify-between px-5 py-3.5 border-b bg-primary text-primary-foreground">
              <DialogTitle className="flex items-center gap-2 text-base font-semibold text-primary-foreground">
                <FileText className="h-4 w-4" />
                New Sale Invoice
              </DialogTitle>
              <div className="flex items-center gap-4 text-xs text-primary-foreground/80">
                <span className="flex items-center gap-1 font-medium opacity-90">Invoice Year: {form.invoiceYear}</span>
                <span className="flex items-center gap-1"><Hash className="h-3 w-3" />{form.invoiceNumber}</span>
              </div>
            </div>

            <div className="p-5 space-y-5">
              <div className="flex flex-wrap items-center gap-3 rounded-xl border border-border/70 px-3 py-3">
                <Label className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Bill Template</Label>
                <Select value={selectedTemplateId} onValueChange={setSelectedTemplateId}>
                  <SelectTrigger className="w-full sm:w-72"><SelectValue placeholder="Choose invoice template" /></SelectTrigger>
                  <SelectContent>
                    {globalBillTemplates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>{template.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <span className="text-[11px] text-muted-foreground">Templates are managed globally by Admin.</span>
                {!globalBillTemplates.length && <span className="text-[11px] text-destructive">No active admin templates are available.</span>}
              </div>
              {/* ── SALE TYPE ── */}
              <div className="flex flex-wrap items-center gap-3 rounded-xl border border-border/70 bg-muted/40 px-3 py-2.5">
                <span className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Sale Type</span>
                <div className="flex items-center gap-1 rounded-full bg-background p-1 border border-border/70">
                  {([
                    { key: true, label: "Credit", icon: <IndianRupee className="h-3.5 w-3.5" /> },
                    { key: false, label: "Cash", icon: <Percent className="h-3.5 w-3.5" /> },
                  ]).map((t) => (
                    <button
                      key={String(t.key)}
                      type="button"
                      onClick={() => {
                        if (t.key === creditOn) return;
                        setCreditOn(t.key);
                        setForm((prev) => ({
                          ...prev,
                          received: t.key ? "0" : "",
                          partyId: "",
                          partyName: "",
                          partyPhone: "",
                          partyAddress: "",
                          partyGst: "",
                        }));
                      }}
                      className={`flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wide transition-all ${
                        creditOn === t.key
                          ? "bg-primary text-primary-foreground shadow"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {t.icon} {t.label}
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground">
                  {creditOn
                    ? "Balance added to customer credit — GST-registered parties suggested."
                    : "Fully paid sale — GSTIN optional."}
                  {gstOn && (isIgst ? " GST auto: IGST (inter-state)." : " GST auto: CGST + SGST.")}
                </p>
              </div>


              <div className="grid grid-cols-1 md:grid-cols-5 gap-3 bg-primary/5 rounded-xl p-4 border border-primary/15">
                <div className="md:col-span-2">
                  <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 flex items-center gap-1">
                    <User className="h-3 w-3" /> Customer Name *
                  </Label>
                  <SuggestionInput
                    key={creditOn ? "credit" : "cash"}
                    value={form.partyName}
                    suggestions={creditOn ? gstPartySuggestions : cashCustomerSuggestions}
                    placeholder="Select or type name"
                    onChange={(val, selected) => {
                      setForm((prev) => ({
                        ...prev,
                        partyName: val,
                        partyId: selected?.id || "",
                        partyPhone: selected?.phone || prev.partyPhone,
                        partyAddress: selected?.address || prev.partyAddress,
                        partyGst: selected?.gst || prev.partyGst,
                      }));
                    }}
                  />
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {creditOn
                      ? "Showing GST parties added with Add GST — name, GSTIN and phone"
                      : "Showing customers saved from previous bills — name and phone"}
                  </p>

                </div>
                <div>
                  <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Phone</Label>
                  <Input
                    value={form.partyPhone}
                    onChange={(e) => setForm((prev) => ({ ...prev, partyPhone: e.target.value }))}
                    placeholder="Mobile no."
                    className="text-sm"
                  />
                </div>
                <div>
                  <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 flex items-center gap-1">
                    <Calendar className="h-3 w-3" /> Invoice Date
                  </Label>
                  <Input
                    type="date"
                    value={form.date}
                    onChange={(e) => {
                      const d = e.target.value;
                      setForm((prev) => ({ ...prev, date: d, invoiceYear: getFinancialYear(d) }));
                    }}
                    className="text-sm"
                  />
                </div>
                <div>
                  <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 flex items-center gap-1">
                    <Hash className="h-3 w-3" /> Bill No
                  </Label>
                  <Input
                    value={form.invoiceNumber}
                    onChange={(e) => setForm((prev) => ({ ...prev, invoiceNumber: e.target.value }))}
                    placeholder="INV-001"
                    className="text-sm font-medium"
                  />
                </div>
                <div>
                  <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">GSTIN</Label>
                  <Input value={form.partyGst} onChange={(e) => setForm((prev) => ({ ...prev, partyGst: e.target.value }))} placeholder="Optional" className="text-sm" />
                </div>
                <div className="md:col-span-5">
                  <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Address</Label>
                  <Input value={form.partyAddress} onChange={(e) => setForm((prev) => ({ ...prev, partyAddress: e.target.value }))} placeholder="Customer address (optional)" className="text-sm" />
                </div>
              </div>

              <div className="rounded-xl border border-border overflow-hidden">
                <div className="grid grid-cols-12 gap-0 bg-sidebar text-sidebar-accent-foreground text-xs font-semibold">
                  <div className="col-span-4 px-3 py-2.5">#  Item / Service</div>
                  <div className="col-span-1 px-2 py-2.5 text-center">Qty</div>
                  <div className="col-span-2 px-2 py-2.5 text-right">Rate (₹)</div>
                  <div className="col-span-1 px-1 py-2.5 text-center">GST%</div>
                  <div className="col-span-2 px-2 py-2.5 text-right">{gstOn ? (isIgst ? "IGST" : "CGST") : "GST"}</div>
                  <div className="col-span-2 px-2 py-2.5 text-right">Amount (₹)</div>
                </div>
                <div className="divide-y divide-border">
                  {form.invoiceItems.map((item, i) => (
                    <div key={i} className={`grid grid-cols-12 gap-0 items-center ${i % 2 === 0 ? 'bg-background' : 'bg-muted/30'}`}>
                      <div className="col-span-4 px-2 py-1.5 flex items-center gap-1.5">
                        <span className="text-xs text-muted-foreground w-4 shrink-0">{i + 1}</span>
                        <ProductInput
                          value={item.name}
                          items={items}
                          onChange={(name, itemId, rate, gstPercent, unit) => {
                            updateItem(i, { name, itemId: itemId || "", rate: rate || 0, gstPercent: gstPercent || 18, unit: unit || item.unit });
                          }}
                        />
                      </div>
                      <div className="col-span-1 px-1 py-1.5">
                        <Input type="number" min={1} value={item.qty}
                          onChange={(e) => updateItem(i, { qty: Number(e.target.value) })}
                          className="text-center text-sm h-8 px-1" />
                      </div>
                      <div className="col-span-2 px-1 py-1.5">
                        <Input type="number" value={item.rate}
                          onChange={(e) => updateItem(i, { rate: Number(e.target.value) })}
                          className="text-right text-sm h-8 px-2" />
                      </div>
                      <div className="col-span-1 px-1 py-1.5">
                        <Select
                          value={String(item.gstPercent)}
                          
                          onValueChange={(v) => updateItem(i, { gstPercent: Number(v) })}
                        >
                          <SelectTrigger className="text-xs h-8 px-1"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {GST_RATES.map((g) => (
                              <SelectItem key={g} value={String(g)}>{g === 0 ? 'Non-GST' : `${g}%`}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="col-span-2 px-2 py-1.5 text-right text-xs text-muted-foreground">
                        {gstOn ? `₹${(isIgst ? item.cgst + item.sgst : item.cgst).toFixed(2)}` : "—"}
                      </div>
                      <div className="col-span-2 px-1 py-1.5 flex items-center gap-1">
                        <Input
                          type="number"
                          value={item.amount === 0 ? "" : item.amount}
                          onChange={(e) => updateItem(i, { amount: Number(e.target.value) }, true)}
                          className="text-right text-sm h-8 px-2 font-semibold"
                          placeholder="0"
                        />
                        {form.invoiceItems.length > 1 && (
                          <button onClick={() => removeItemRow(i)} className="text-destructive hover:text-destructive/80 shrink-0">
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="px-3 py-2 bg-muted/20 border-t">
                  <Button variant="ghost" size="sm" onClick={addItemRow} className="text-primary hover:text-primary text-xs gap-1">
                    <Plus className="h-3.5 w-3.5" /> Add Item
                  </Button>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="flex-1">
                  <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 block">
                    Description <span className="text-muted-foreground/60 normal-case">(serial no., notes, etc.)</span>
                  </Label>
                  <textarea
                    value={form.description}
                    onChange={(e) => setForm((prev) => ({ ...prev, description: e.target.value }))}
                    placeholder="e.g. SR NO 25BBR... or any additional notes"
                    rows={4}
                    className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div className="w-72 rounded-2xl border border-border/60 bg-gradient-to-b from-card to-muted/40 overflow-hidden shrink-0 shadow-lg shadow-primary/5 backdrop-blur">
                  <div className="px-4 py-3 space-y-1.5">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Sub Total</span>
                      <span className="font-medium">₹{subtotal.toLocaleString('en-IN')}</span>
                    </div>
                    {!gstOn ? (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">GST</span>
                        <span className="font-medium text-muted-foreground">Not applicable</span>
                      </div>
                    ) : isIgst ? (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">IGST</span>
                        <span>₹{totalGst.toFixed(2)}</span>
                      </div>
                    ) : (
                      <>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">CGST</span>
                          <span>₹{(totalGst / 2).toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">SGST</span>
                          <span>₹{(totalGst / 2).toFixed(2)}</span>
                        </div>
                      </>
                    )}
                    {gstOn && (
                      <div className="flex justify-between text-sm border-t pt-1.5">
                        <span className="text-muted-foreground">Total GST</span>
                        <span className="font-semibold">₹{totalGst.toFixed(2)}</span>
                      </div>
                    )}
                  </div>
                  <div className="relative flex justify-between px-4 py-3 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground font-bold text-sm shadow-[0_6px_20px_-6px_hsl(var(--primary))]">
                    <span className="tracking-wide uppercase text-[11px] opacity-90 self-center">Total Amount</span>
                    <span className="text-base">₹{totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="px-4 py-3 space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Received</span>
                      <div className="relative">
                        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">₹</span>
                        <input
                          type="number"
                          min={0}
                          inputMode="decimal"
                          value={creditOn ? form.received : totalAmount.toFixed(2)}
                          disabled={!creditOn}
                          onChange={(e) => setForm((prev) => ({ ...prev, received: e.target.value }))}
                          placeholder={totalAmount.toFixed(2)}
                          className="w-32 rounded-lg border border-input/70 bg-background/80 pl-6 pr-2 py-1.5 text-sm font-semibold text-right shadow-inner transition-all focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/15 disabled:opacity-60"
                        />
                      </div>
                    </div>
                    {creditOn ? (
                      <button
                        type="button"
                        onClick={() => setForm((prev) => ({ ...prev, received: "0" }))}
                        className="text-[11px] font-medium text-primary/80 hover:text-primary transition-colors"
                      >
                        Mark full credit (received ₹0)
                      </button>
                    ) : (
                      <p className="text-[11px] text-muted-foreground">Credit is OFF — bill counted as fully paid.</p>
                    )}
                    <div
                      className={`flex items-center justify-between rounded-xl px-3 py-2 border transition-all ${
                        creditAmount > 0
                          ? "border-destructive/30 bg-destructive/10 shadow-[0_0_18px_-6px_hsl(var(--destructive))]"
                          : "border-emerald-500/30 bg-emerald-500/10"
                      }`}
                    >
                      <span className={`text-[11px] font-semibold uppercase tracking-wide ${creditAmount > 0 ? "text-destructive" : "text-emerald-600"}`}>
                        Credit Balance
                      </span>
                      <span className={`text-sm font-bold ${creditAmount > 0 ? "text-destructive" : "text-emerald-600"}`}>
                        ₹{creditAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center pt-1 border-t">
                <Button variant="ghost" size="sm" onClick={handleClose} className="text-muted-foreground">Cancel</Button>
                <Button onClick={handleSave} size="default" className="px-8" disabled={!selectedTemplateId || !globalBillTemplates.some((template) => template.id === selectedTemplateId && template.active)}>
                  <FileText className="h-4 w-4 mr-2" /> Save Invoice
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
