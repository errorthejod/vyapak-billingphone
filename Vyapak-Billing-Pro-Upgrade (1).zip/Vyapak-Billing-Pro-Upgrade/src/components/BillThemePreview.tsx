import { BillStyle, Invoice, ShopInfo } from "@/types";
import { InvoiceTemplate } from "@/components/InvoiceTemplate";
import { useIsMobile } from "@/hooks/use-mobile";


/** A realistic demo bill used only to preview the selected theme live. */
export const sampleInvoice = (): Invoice => {
  const mk = (name: string, qty: number, rate: number, gst: number, hsn: string, unit: string) => {
    const base = qty * rate;
    const tax = (base * gst) / 100;
    return { itemId: name, name, hsn, qty, unit, rate, gstPercent: gst, amount: base + tax, cgst: tax / 2, sgst: tax / 2 };
  };
  const items = [
    mk("Smart LED Bulb 9W", 4, 250, 18, "8539", "pcs"),
    mk("Extension Board 4+1", 2, 480, 18, "8536", "pcs"),
    mk("Installation Charges", 1, 500, 18, "9987", "job"),
  ];
  const subtotal = items.reduce((s, i) => s + i.qty * i.rate, 0);
  const gst = items.reduce((s, i) => s + i.cgst + i.sgst, 0);
  return {
    id: "preview",
    invoiceNumber: "inv.GST.0001",
    invoiceYear: "2026-2027",
    date: new Date().toISOString().split("T")[0],
    partyId: "preview-party",
    partyName: "Sharma Electricals",
    partyAddress: "12, Main Bazar Road, New Delhi - 110006",
    partyPhone: "98110 22334",
    partyGst: "07AABCS1429B1ZX",
    items,
    subtotal,
    totalCgst: gst / 2,
    totalSgst: gst / 2,
    igst: gst,
    totalAmount: subtotal + gst,
    receivedAmount: subtotal + gst,
    gstEnabled: true,
    taxType: "cgst_sgst",
    type: "sale",
    createdAt: new Date().toISOString(),
  };
};

/**
 * Live preview of the invoice with the currently selected theme.
 * Zoomed down (zoom affects layout, so no blank space) to fit mobile and desktop.
 */
export const BillThemePreview = ({ shopInfo, style }: { shopInfo: ShopInfo; style: BillStyle }) => {
  const invoice = sampleInvoice();
  const isMobile = useIsMobile();
  return (
    <div className="rounded-xl border border-border bg-muted/30 p-3">
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        Live preview — sample bill
      </p>
      <div className="overflow-x-auto">
        <div style={{ zoom: isMobile ? 0.42 : 0.72 }}>
          <InvoiceTemplate invoice={invoice} shopInfo={{ ...shopInfo, billStyle: style }} useLocalStyle />
        </div>
      </div>
    </div>
  );
};

