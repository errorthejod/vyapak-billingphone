import { useCallback, useEffect, useState } from "react";
import { api, CaAccessRequest } from "@/lib/api";
import { useAuthStore } from "@/store/useAuthStore";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { ShieldCheck, Clock3, Check, X, Unplug, RefreshCw } from "lucide-react";

export function CaAccessManager() {
  const businessId = useAuthStore(s => s.currentUserId) || "";
  const [requests, setRequests] = useState<CaAccessRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const reload = useCallback(async () => {
    if (!businessId) return;
    setLoading(true);
    try { setRequests(await api.getCaAccessRequests({ businessId })); }
    catch (err) { toast.error(err instanceof Error ? err.message : "Could not load CA requests"); }
    finally { setLoading(false); }
  }, [businessId]);
  useEffect(() => { void reload(); }, [reload]);
  const decide = async (request: CaAccessRequest, action: "approved" | "rejected" | "revoked") => {
    setLoading(true);
    try {
      await api.decideCaAccessRequest(request.id, businessId, action);
      toast.success(action === "approved" ? "CA access approved" : action === "revoked" ? "CA access revoked" : "CA request rejected");
      await reload();
    } catch (err) { toast.error(err instanceof Error ? err.message : "Could not update CA access"); }
    finally { setLoading(false); }
  };
  const badge = (status: string) => status === "approved" ? "bg-emerald-500/10 text-emerald-700" : status === "pending" ? "bg-amber-500/10 text-amber-700" : "bg-muted text-muted-foreground";
  return <section className="max-w-2xl overflow-hidden rounded-xl border bg-card shadow-sm">
    <div className="flex items-center gap-3 border-b bg-primary/5 px-6 py-4"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10"><ShieldCheck className="h-5 w-5 text-primary" /></div><div className="min-w-0 flex-1"><h3 className="font-semibold">CA Access Requests</h3><p className="text-xs text-muted-foreground">No CA can see your business data unless you approve them.</p></div><Button variant="outline" size="sm" onClick={() => void reload()} disabled={loading}><RefreshCw className={`mr-1.5 h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />Refresh</Button></div>
    <div className="space-y-3 p-5">
      {requests.map((request) => <div key={request.id} className="rounded-xl border p-4">
        <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-semibold">{request.caName}</p><p className="text-sm text-muted-foreground">{request.caFirm}</p><p className="text-xs text-muted-foreground">{request.caEmail}</p><p className="mt-1 text-xs text-muted-foreground">Requested: {new Date(request.createdAt).toLocaleString()}</p></div><span className={`rounded-full px-2.5 py-1 text-xs font-medium capitalize ${badge(request.status)}`}>{request.status}</span></div>
        {request.status === "pending" && <div className="mt-3 flex flex-wrap gap-2"><Button size="sm" disabled={loading} onClick={() => void decide(request,"approved")}><Check className="mr-1 h-3.5 w-3.5"/>Accept Request</Button><Button size="sm" variant="destructive" disabled={loading} onClick={() => void decide(request,"rejected")}><X className="mr-1 h-3.5 w-3.5"/>Reject</Button></div>}
        {request.status === "approved" && <div className="mt-3 space-y-2"><p className="text-xs text-muted-foreground">Approved access is read-only by default. Revoking access immediately disables this connection.</p><Button size="sm" variant="outline" disabled={loading} onClick={() => void decide(request,"revoked")}><Unplug className="mr-1 h-3.5 w-3.5"/>Revoke Access</Button></div>}
        {request.status === "rejected" && <p className="mt-2 text-xs text-muted-foreground">You rejected this request. The CA has no access.</p>}
        {request.status === "revoked" && <p className="mt-2 text-xs text-muted-foreground">Access has been revoked. The CA has no access.</p>}
      </div>)}
      {!requests.length && !loading && <div className="py-8 text-center text-sm text-muted-foreground"><Clock3 className="mx-auto mb-2 h-6 w-6 opacity-40"/>No CA access requests yet.</div>}
      <p className="text-xs text-muted-foreground">Approval only creates an access relationship; it does not share data before approval. You can revoke an approved CA at any time.</p>
    </div>
  </section>;
}
