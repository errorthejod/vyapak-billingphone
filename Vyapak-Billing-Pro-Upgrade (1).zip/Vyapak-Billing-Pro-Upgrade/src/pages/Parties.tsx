import { useState } from "react";
import Layout from "@/components/Layout";
import { useCurrentStore as useStore } from "@/store/useCurrentStore";
import { Party, GstFirm } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Search, Trash2, Edit, Phone, MapPin, Building2, User, Receipt } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

const emptyParty = { name: "", phone: "", address: "" };
const emptyFirm = { gstin: "", businessName: "", ownerName: "", phone: "", address: "" };

const Parties = () => {
  const {
    parties, addParty, updateParty, deleteParty,
    gstFirms, addGstFirm, updateGstFirm, deleteGstFirm,
  } = useStore();

  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editingParty, setEditingParty] = useState<Party | null>(null);
  const [form, setForm] = useState({ ...emptyParty });

  const [gstOpen, setGstOpen] = useState(false);
  const [editingFirm, setEditingFirm] = useState<GstFirm | null>(null);
  const [firmForm, setFirmForm] = useState({ ...emptyFirm });

  const q = search.trim().toLowerCase();
  const filtered = parties.filter(p =>
    p.name.toLowerCase().includes(q) || p.phone.includes(search)
  );
  const filteredFirms = gstFirms.filter(f =>
    f.businessName.toLowerCase().includes(q) ||
    f.ownerName.toLowerCase().includes(q) ||
    f.gstin.toLowerCase().includes(q) ||
    f.phone.includes(search)
  );

  const resetPartyForm = () => { setForm({ ...emptyParty }); setEditingParty(null); };
  const resetFirmForm = () => { setFirmForm({ ...emptyFirm }); setEditingFirm(null); };

  const handleSubmit = () => {
    if (!form.name || !form.phone) {
      toast.error("Name and phone are required");
      return;
    }
    if (editingParty) {
      updateParty(editingParty.id, { ...form });
      toast.success("Party updated");
    } else {
      addParty({
        id: Date.now().toString(),
        ...form,
        type: 'customer',
        balance: 0,
        createdAt: new Date().toISOString().split('T')[0],
      });
      toast.success("Party added");
    }
    resetPartyForm();
    setOpen(false);
  };

  const handleEdit = (party: Party) => {
    setEditingParty(party);
    setForm({ name: party.name, phone: party.phone, address: party.address });
    setOpen(true);
  };

  const handleDelete = (id: string) => {
    deleteParty(id);
    toast.success("Party deleted");
  };

  const handleFirmSubmit = () => {
    if (!firmForm.gstin || !firmForm.businessName) {
      toast.error("GSTIN and business name are required");
      return;
    }
    if (editingFirm) {
      updateGstFirm(editingFirm.id, { ...firmForm });
      toast.success("GST firm updated");
    } else {
      addGstFirm({
        id: Date.now().toString(),
        ...firmForm,
        createdAt: new Date().toISOString().split('T')[0],
      });
      toast.success("GST firm added");
    }
    resetFirmForm();
    setGstOpen(false);
  };

  const handleFirmEdit = (firm: GstFirm) => {
    setEditingFirm(firm);
    setFirmForm({
      gstin: firm.gstin,
      businessName: firm.businessName,
      ownerName: firm.ownerName,
      phone: firm.phone,
      address: firm.address,
    });
    setGstOpen(true);
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-heading font-bold text-foreground">Parties</h1>
            <p className="text-sm text-muted-foreground mt-1">
              {parties.length} customers · {gstFirms.length} GST firms
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) resetPartyForm(); }}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingParty ? "Edit Party" : "Add New Party"}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div><Label>Name *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Customer name" /></div>
                  <div><Label>Phone *</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="Phone number" /></div>
                  <div><Label>Address</Label><Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="Full address" /></div>
                  <Button onClick={handleSubmit} className="w-full">Update Party</Button>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={gstOpen} onOpenChange={(v) => { setGstOpen(v); if (!v) resetFirmForm(); }}>
              <DialogTrigger asChild>
                <Button variant="outline"><Receipt className="h-4 w-4 mr-2" />Add GST</Button>
              </DialogTrigger>
              <DialogContent className="max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingFirm ? "Edit GST Firm" : "Add GST Firm"}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <Label>GSTIN *</Label>
                    <Input
                      value={firmForm.gstin}
                      onChange={e => setFirmForm({ ...firmForm, gstin: e.target.value.toUpperCase() })}
                      placeholder="Enter GSTIN"
                    />
                  </div>
                  <div><Label>Business Name *</Label><Input value={firmForm.businessName} onChange={e => setFirmForm({ ...firmForm, businessName: e.target.value })} placeholder="Firm / business name" /></div>
                  <div><Label>Owner Name</Label><Input value={firmForm.ownerName} onChange={e => setFirmForm({ ...firmForm, ownerName: e.target.value })} placeholder="Proprietor name" /></div>
                  <div><Label>Phone Number</Label><Input value={firmForm.phone} onChange={e => setFirmForm({ ...firmForm, phone: e.target.value })} placeholder="Phone number" /></div>
                  <div><Label>Address</Label><Input value={firmForm.address} onChange={e => setFirmForm({ ...firmForm, address: e.target.value })} placeholder="Full address" /></div>
                  <Button onClick={handleFirmSubmit} className="w-full">{editingFirm ? "Update Firm" : "Add GST Firm"}</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search parties or GST firms..." className="pl-9" />
        </div>

        {/* ── GST FIRMS ── */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-foreground uppercase tracking-wide">GST Firms</h2>
            <span className="text-xs text-muted-foreground">{filteredFirms.length}</span>
          </div>
          {filteredFirms.length === 0 ? (
            <p className="text-sm text-muted-foreground bg-card rounded-xl p-4 card-shadow">
              No GST firms yet. Use “Add GST” to save one.
            </p>
          ) : (
            <div className="grid gap-3">
              {filteredFirms.map((firm, i) => (
                <motion.div
                  key={firm.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-card rounded-xl p-4 card-shadow flex items-start justify-between gap-3"
                >
                  <div className="flex items-start gap-4 min-w-0">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <Building2 className="h-4 w-4 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-foreground truncate">{firm.businessName}</p>
                      <p className="text-xs text-primary font-semibold mt-0.5">{firm.gstin}</p>
                      <div className="flex flex-wrap items-center gap-3 mt-1">
                        {firm.ownerName && <span className="text-xs text-muted-foreground flex items-center gap-1"><User className="h-3 w-3" />{firm.ownerName}</span>}
                        {firm.phone && <span className="text-xs text-muted-foreground flex items-center gap-1"><Phone className="h-3 w-3" />{firm.phone}</span>}
                        {firm.address && <span className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="h-3 w-3" />{firm.address}</span>}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Button variant="ghost" size="icon" onClick={() => handleFirmEdit(firm)}><Edit className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => { deleteGstFirm(firm.id); toast.success("GST firm deleted"); }}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* ── PARTIES ── */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-foreground uppercase tracking-wide">Customers</h2>
            <span className="text-xs text-muted-foreground">{filtered.length}</span>
          </div>
          {filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground bg-card rounded-xl p-4 card-shadow">No parties here yet.</p>
          ) : (
            <div className="grid gap-3">
              {filtered.map((party, i) => (
                <motion.div
                  key={party.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-card rounded-xl p-4 card-shadow flex items-center justify-between"
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <span className="text-sm font-semibold text-primary">{party.name[0]}</span>
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-foreground truncate">{party.name}</p>
                      <div className="flex flex-wrap items-center gap-3 mt-0.5">
                        <span className="text-xs text-muted-foreground flex items-center gap-1"><Phone className="h-3 w-3" />{party.phone}</span>
                        {party.address && <span className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="h-3 w-3" />{party.address}</span>}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <p className={`text-sm font-semibold ${party.balance >= 0 ? 'text-receivable' : 'text-payable'}`}>
                      ₹{Math.abs(party.balance).toLocaleString('en-IN')}
                    </p>
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(party)}><Edit className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(party.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default Parties;
