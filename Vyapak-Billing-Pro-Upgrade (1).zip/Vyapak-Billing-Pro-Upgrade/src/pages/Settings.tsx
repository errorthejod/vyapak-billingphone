import Layout from "@/components/Layout";
import { useCurrentStore as useStore } from "@/store/useCurrentStore";
import { useState, useRef, useEffect, type ReactNode } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Store, Phone, Mail, MapPin, FileText, Hash, ScrollText, Image as ImageIcon,
  PenLine, Stamp, X, Upload, Percent, Building2, Landmark, Save, RotateCcw,
  Settings2, ShieldCheck, CheckCircle2, Users, ReceiptText,
  Palette, ChevronRight, LockKeyhole, Info, Printer, SlidersHorizontal, Check,
} from "lucide-react";
import { GST_RATES, GstRegType, TaxType, type ShopInfo, type BillStyle, defaultBillStyle } from "@/types";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CaAccessManager } from "@/components/CaAccessManager";
import { BillThemePreview } from "@/components/BillThemePreview";

const REG_TYPES: { key: GstRegType; label: string }[] = [
  { key: "regular", label: "Registered — Regular" },
  { key: "composition", label: "Registered — Composition" },
  { key: "unregistered", label: "Unregistered" },
];

const DEFAULT_TERMS = "1. Goods once sold will not be taken back.\n2. Subject to local jurisdiction only.\n3. All disputes subject to local jurisdiction.";

type SettingsSection = "business" | "tax" | "bank" | "branding" | "terms" | "print" | "ca" | "templates";
type PrinterTab = "regular" | "thermal";
type PrintSubTab = "layout" | "colors";

function SectionHeading({ icon, title, description }: { icon: ReactNode; title: string; description: string }) {
  return (
    <div className="flex items-start gap-3 border-b border-border/70 px-5 py-4 sm:px-6">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">{icon}</div>
      <div className="min-w-0">
        <h2 className="font-heading text-base font-semibold text-foreground">{title}</h2>
        <p className="mt-1 text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

function Field({ label, icon, hint, children }: { label: string; icon?: ReactNode; hint?: string; children: ReactNode }) {
  return (
    <div className="min-w-0 space-y-1.5">
      <Label className="flex items-center gap-1.5 text-sm font-medium">
        {icon ? <span className="text-primary">{icon}</span> : null}{label}
      </Label>
      {children}
      {hint ? <p className="text-xs leading-5 text-muted-foreground">{hint}</p> : null}
    </div>
  );
}

function SettingSwitch({ label, description, checked, onChange, disabled }: {
  label: string; description: string; checked: boolean; onChange: (value: boolean) => void; disabled?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-xl border border-border/70 bg-background p-4">
      <div className="min-w-0">
        <div className="text-sm font-medium">{label}</div>
        <div className="mt-1 text-xs leading-5 text-muted-foreground">{description}</div>
      </div>
      <button
        type="button"
        role="switch"
        aria-label={label}
        aria-checked={checked}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={`relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${checked ? "bg-primary" : "bg-muted-foreground/30"}`}
      >
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-background shadow transition-all ${checked ? "left-[22px]" : "left-0.5"}`} />
      </button>
    </div>
  );
}

const ImageUploadBox = ({
  label, icon, hint, value, onChange, onClear, previewHeight = 80, disabled = false,
}: {
  label: string; icon: ReactNode; hint: string; value?: string; onChange: (base64: string) => void;
  onClear: () => void; previewHeight?: number; disabled?: boolean;
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Choose an image file"); e.target.value = ""; return; }
    if (file.size > 2 * 1024 * 1024) { toast.error("Image must be under 2 MB"); e.target.value = ""; return; }
    const reader = new FileReader();
    reader.onload = (ev) => onChange(String(ev.target?.result || ""));
    reader.onerror = () => toast.error("Could not read this image");
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  return (
    <div className="min-w-0">
      <Label className="mb-2 flex items-center gap-1.5 text-sm font-medium">{icon}{label}</Label>
      <div className={`relative overflow-hidden rounded-xl border border-dashed border-border bg-muted/20 transition-colors ${!disabled ? "hover:border-primary/60" : "opacity-70"}`}>
        {value ? (
          <div className="flex min-h-32 flex-col items-center justify-center gap-3 p-4">
            <img src={value} alt={label} style={{ maxHeight: `${previewHeight}px`, maxWidth: "100%", objectFit: "contain" }} className="rounded-md" />
            <div className="flex flex-wrap justify-center gap-2">
              <Button type="button" size="sm" variant="outline" disabled={disabled} onClick={() => inputRef.current?.click()} className="h-8 gap-1.5 text-xs"><Upload className="h-3.5 w-3.5" /> Change</Button>
              <Button type="button" size="sm" variant="outline" disabled={disabled} onClick={onClear} className="h-8 gap-1.5 text-xs text-destructive hover:text-destructive"><X className="h-3.5 w-3.5" /> Remove</Button>
            </div>
          </div>
        ) : (
          <button type="button" disabled={disabled} onClick={() => inputRef.current?.click()} className="flex min-h-32 w-full flex-col items-center justify-center gap-2 p-5 text-center disabled:cursor-not-allowed">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary"><Upload className="h-5 w-5" /></div>
            <span className="text-sm font-medium">Upload {label.toLowerCase()}</span>
            <span className="max-w-56 text-xs leading-5 text-muted-foreground">{hint}</span>
            <span className="text-[11px] text-muted-foreground">PNG, JPG or WebP · Max 2 MB</span>
          </button>
        )}
      </div>
      <input ref={inputRef} type="file" accept="image/*" className="hidden" disabled={disabled} onChange={handleFile} />
    </div>
  );
};

const SettingsPage = () => {
  const { shopInfo, updateShopInfo, restricted } = useStore();
  const [form, setForm] = useState<ShopInfo>({ ...shopInfo });
  const [activeSection, setActiveSection] = useState<SettingsSection>("business");
  const [printerTab, setPrinterTab] = useState<PrinterTab>("regular");
  const [printSubTab, setPrintSubTab] = useState<PrintSubTab>("layout");

  useEffect(() => { setForm({ ...shopInfo }); }, [shopInfo]);

  const dirty = JSON.stringify(form) !== JSON.stringify(shopInfo);
  const update = <K extends keyof ShopInfo>(key: K, value: ShopInfo[K]) => setForm((current) => ({ ...current, [key]: value }));
  const regularPrintStyle: BillStyle = { ...defaultBillStyle(), ...(form.billStyle || {}) };
  const thermalPrintStyle: BillStyle = {
    ...defaultBillStyle(), layout: "compact", paperSize: "thermal80", orientation: "portrait",
    companyNameSize: "small", invoiceTextSize: "small", showHsn: false, showUnit: true,
    pageFill: 50, topMargin: 0, ...(form.thermalBillStyle || {}),
  };
  const printStyle = printerTab === "regular" ? regularPrintStyle : thermalPrintStyle;
  const updatePrintStyle = (patch: Partial<BillStyle>) => {
    const next = { ...printStyle, ...patch };
    if (printerTab === "regular") update("billStyle", next);
    else update("thermalBillStyle", next);
  };
  const setPrinterDefault = (mode: PrinterTab, enabled: boolean) => {
    if (enabled) {
      if (mode === "thermal" && !form.thermalBillStyle) update("thermalBillStyle", thermalPrintStyle);
      if (mode === "regular" && !form.billStyle) update("billStyle", regularPrintStyle);
      update("defaultPrinter", mode);
    } else if ((form.defaultPrinter || "regular") === mode) {
      update("defaultPrinter", mode === "regular" ? "thermal" : "regular");
    }
  };
  const handleSave = () => {
    if (restricted) { toast.error("Your plan is inactive. Settings are read-only until renewal."); return; }
    updateShopInfo(form);
    toast.success("Settings saved successfully");
  };
  const handleReset = () => setForm({ ...shopInfo });

  const sections: { id: SettingsSection; label: string; description: string; icon: ReactNode }[] = [
    { id: "business", label: "Business profile", description: "Name, address and contact", icon: <Store className="h-4 w-4" /> },
    { id: "tax", label: "GST & tax", description: "GSTIN, state and defaults", icon: <Percent className="h-4 w-4" /> },
    { id: "bank", label: "Bank details", description: "Payment and jurisdiction", icon: <Landmark className="h-4 w-4" /> },
    { id: "branding", label: "Invoice branding", description: "Logo, signature and stamp", icon: <Palette className="h-4 w-4" /> },
    { id: "terms", label: "Terms & conditions", description: "Printed on bills", icon: <ScrollText className="h-4 w-4" /> },
    { id: "print", label: "Print settings", description: "Regular and thermal printer", icon: <Printer className="h-4 w-4" /> },
    { id: "ca", label: "CA access", description: "Manage accountant permissions", icon: <Users className="h-4 w-4" /> },
    { id: "templates", label: "Bill templates", description: "Available invoice layouts", icon: <ReceiptText className="h-4 w-4" /> },
  ];

  const active = sections.find((section) => section.id === activeSection) || sections[0];
  const cardClass = "overflow-hidden rounded-2xl border border-border/70 bg-card shadow-sm";
  const inputClass = "h-10 bg-background text-sm";

  return (
    <Layout>
      <div className="mx-auto w-full max-w-7xl space-y-6 pb-24">
        <motion.header initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-primary"><Settings2 className="h-4 w-4" /> Workspace settings</div>
            <h1 className="font-heading text-2xl font-bold tracking-tight text-foreground sm:text-3xl">Settings</h1>
            <p className="mt-1.5 max-w-2xl text-sm leading-6 text-muted-foreground">Manage your business details, tax defaults and the information printed on every invoice.</p>
          </div>
          <div className="flex items-center gap-2 self-start rounded-full border border-border/70 bg-card px-3 py-2 text-xs text-muted-foreground sm:self-auto">
            {restricted ? <LockKeyhole className="h-3.5 w-3.5 text-amber-600" /> : <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />}
            {restricted ? "Read-only · plan inactive" : "Saved to your business account"}
          </div>
        </motion.header>

        {restricted && (
          <div className="flex gap-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm">
            <LockKeyhole className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
            <div><div className="font-semibold">Settings are read-only</div><p className="mt-1 text-muted-foreground">Renew your plan to change business settings. You can still view your saved information.</p></div>
          </div>
        )}

        <div className="grid items-start gap-5 lg:grid-cols-[260px_minmax(0,1fr)]">
          <aside className="rounded-2xl border border-border/70 bg-card p-2 shadow-sm">
            <div className="px-3 pb-2 pt-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Manage</div>
            <nav className="flex gap-1 overflow-x-auto lg:flex-col lg:overflow-visible" aria-label="Settings sections">
              {sections.map((section) => {
                const selected = section.id === activeSection;
                return (
                  <button key={section.id} type="button" onClick={() => setActiveSection(section.id)} aria-current={selected ? "page" : undefined}
                    className={`group flex min-w-max items-center gap-3 rounded-xl px-3 py-3 text-left transition-colors lg:w-full ${selected ? "bg-primary text-primary-foreground shadow-sm" : "text-foreground hover:bg-muted"}`}>
                    <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${selected ? "bg-white/15" : "bg-muted text-muted-foreground group-hover:text-primary"}`}>{section.icon}</span>
                    <span className="min-w-0"><span className="block text-sm font-semibold">{section.label}</span><span className={`mt-0.5 hidden text-[11px] lg:block ${selected ? "text-primary-foreground/75" : "text-muted-foreground"}`}>{section.description}</span></span>
                    <ChevronRight className={`ml-auto hidden h-4 w-4 lg:block ${selected ? "opacity-100" : "opacity-0"}`} />
                  </button>
                );
              })}
            </nav>
            <div className="mx-2 mt-3 hidden rounded-xl bg-muted/50 p-3 lg:block">
              <div className="flex items-center gap-2 text-xs font-semibold"><CheckCircle2 className="h-4 w-4 text-emerald-600" /> Tip</div>
              <p className="mt-1.5 text-xs leading-5 text-muted-foreground">Keep your GSTIN, address and bank details updated to reduce manual edits on invoices.</p>
            </div>
          </aside>

          <div className="min-w-0 space-y-4">
            <div className="px-1">
              <h2 className="text-lg font-bold">{active.label}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{active.description}</p>
            </div>

            {activeSection === "business" && (
              <motion.section key="business" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className={cardClass}>
                <SectionHeading icon={<Building2 className="h-5 w-5" />} title="Business information" description="This information appears in the header of your invoices." />
                <div className="grid gap-5 p-5 sm:grid-cols-2 sm:p-6">
                  <div className="sm:col-span-2"><Field label="Business / shop name" icon={<Store className="h-3.5 w-3.5" />}><Input disabled={restricted} value={form.name || ""} onChange={(e) => update("name", e.target.value)} placeholder="Enter business name" className={inputClass} /></Field></div>
                  <div className="sm:col-span-2"><Field label="Business address" icon={<MapPin className="h-3.5 w-3.5" />} hint="Use separate lines for shop, street, city and PIN code."><textarea disabled={restricted} value={form.address || ""} onChange={(e) => update("address", e.target.value)} placeholder="Shop / street address, city, state and PIN code" rows={4} className="w-full resize-y rounded-xl border border-input bg-background px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-60" /></Field></div>
                  <Field label="Phone / mobile" icon={<Phone className="h-3.5 w-3.5" />}><Input disabled={restricted} value={form.phone || ""} onChange={(e) => update("phone", e.target.value)} placeholder="Business contact number" className={inputClass} /></Field>
                  <Field label="Business email" icon={<Mail className="h-3.5 w-3.5" />}><Input disabled={restricted} type="email" value={form.email || ""} onChange={(e) => update("email", e.target.value)} placeholder="Business email address" className={inputClass} /></Field>
                  <Field label="State / region"><Input disabled={restricted} value={form.state || ""} onChange={(e) => update("state", e.target.value)} placeholder="Enter state" className={inputClass} /></Field>
                  <Field label="Trade / other tax number" icon={<Hash className="h-3.5 w-3.5" />}><Input disabled={restricted} value={form.gtNo || ""} onChange={(e) => update("gtNo", e.target.value)} placeholder="Optional — leave blank if unused" className={inputClass} /></Field>
                </div>
              </motion.section>
            )}

            {activeSection === "tax" && (
              <motion.section key="tax" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className={cardClass}>
                <SectionHeading icon={<Percent className="h-5 w-5" />} title="GST and tax preferences" description="Set the tax identity and defaults used when creating new bills." />
                <div className="space-y-6 p-5 sm:p-6">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="GSTIN" icon={<Hash className="h-3.5 w-3.5" />} hint="Leave blank if your business is not GST registered."><Input disabled={restricted} value={form.gst || ""} onChange={(e) => update("gst", e.target.value.toUpperCase())} placeholder="Enter your GSTIN" className={`${inputClass} uppercase tracking-wide`} maxLength={15} /></Field>
                    <Field label="GST registration type"><Select disabled={restricted} value={form.gstRegType || "regular"} onValueChange={(v) => update("gstRegType", v as GstRegType)}><SelectTrigger className={inputClass}><SelectValue placeholder="Choose registration type" /></SelectTrigger><SelectContent>{REG_TYPES.map((item) => <SelectItem key={item.key} value={item.key}>{item.label}</SelectItem>)}</SelectContent></Select></Field>
                    <Field label="PAN" hint="Optional business PAN. Do not enter a personal number unless it belongs on your business invoices."><Input disabled={restricted} value={form.pan || ""} onChange={(e) => update("pan", e.target.value.toUpperCase())} placeholder="Enter PAN (optional)" className={`${inputClass} uppercase`} maxLength={10} /></Field>
                    <Field label="GST state code"><Input disabled={restricted} value={form.stateCode || ""} onChange={(e) => update("stateCode", e.target.value.replace(/\D/g, "").slice(0, 2))} placeholder="Two-digit code" className={inputClass} maxLength={2} inputMode="numeric" /></Field>
                    <Field label="Default GST rate"><Select disabled={restricted} value={String(form.defaultGstRate ?? 18)} onValueChange={(v) => update("defaultGstRate", Number(v))}><SelectTrigger className={inputClass}><SelectValue /></SelectTrigger><SelectContent>{GST_RATES.map((rate) => <SelectItem key={rate} value={String(rate)}>{rate === 0 ? "Non-GST / 0%" : `${rate}%`}</SelectItem>)}</SelectContent></Select></Field>
                    <Field label="Default tax split"><Select disabled={restricted} value={form.defaultTaxType || "cgst_sgst"} onValueChange={(v) => update("defaultTaxType", v as TaxType)}><SelectTrigger className={inputClass}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="cgst_sgst">CGST + SGST (within state)</SelectItem><SelectItem value="igst">IGST (inter-state)</SelectItem></SelectContent></Select></Field>
                  </div>
                  <div className="space-y-3 border-t border-border/70 pt-5">
                    <div><h3 className="text-sm font-semibold">New invoice defaults</h3><p className="mt-1 text-xs text-muted-foreground">These preferences apply to newly created bills; they don't recalculate existing invoices.</p></div>
                    <SettingSwitch disabled={restricted} label="GST enabled by default" description="Start new invoices with GST turned on." checked={form.gstEnabledByDefault ?? true} onChange={(value) => update("gstEnabledByDefault", value)} />
                    <SettingSwitch disabled={restricted} label="Credit sale by default" description="Start new sales in credit mode instead of cash mode." checked={form.creditEnabledByDefault ?? false} onChange={(value) => update("creditEnabledByDefault", value)} />
                  </div>
                </div>
              </motion.section>
            )}

            {activeSection === "bank" && (
              <motion.section key="bank" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className={cardClass}>
                <SectionHeading icon={<Landmark className="h-5 w-5" />} title="Bank and payment details" description="Optional bank details can be printed at the bottom of your invoice." />
                <div className="grid gap-5 p-5 sm:grid-cols-2 sm:p-6">
                  <Field label="Bank name"><Input disabled={restricted} value={form.bankName || ""} onChange={(e) => update("bankName", e.target.value)} placeholder="Enter bank name" className={inputClass} /></Field>
                  <Field label="Bank branch"><Input disabled={restricted} value={form.bankBranch || ""} onChange={(e) => update("bankBranch", e.target.value)} placeholder="Branch name" className={inputClass} /></Field>
                  <Field label="Account number"><Input disabled={restricted} value={form.bankAccount || ""} onChange={(e) => update("bankAccount", e.target.value)} placeholder="Enter account number" className={inputClass} inputMode="numeric" /></Field>
                  <Field label="IFSC code"><Input disabled={restricted} value={form.bankIfsc || ""} onChange={(e) => update("bankIfsc", e.target.value.toUpperCase())} placeholder="Enter IFSC code" className={`${inputClass} uppercase`} maxLength={11} /></Field>
                  <div className="sm:col-span-2"><Field label="Invoice jurisdiction" hint="Shown only in templates that use this field."><Input disabled={restricted} value={form.jurisdiction || ""} onChange={(e) => update("jurisdiction", e.target.value)} placeholder="e.g. Delhi" className={inputClass} /></Field></div>
                  <div className="sm:col-span-2 flex gap-3 rounded-xl border border-sky-500/20 bg-sky-500/5 p-4 text-sm"><Info className="mt-0.5 h-4 w-4 shrink-0 text-sky-600" /><p className="text-muted-foreground">Bank details are optional. Leave these blank if you don't want them shown on invoices. Only fill in details you're comfortable sharing with customers.</p></div>
                </div>
              </motion.section>
            )}

            {activeSection === "branding" && (
              <motion.section key="branding" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className={cardClass}>
                <SectionHeading icon={<Palette className="h-5 w-5" />} title="Invoice branding" description="Upload your business logo, signature and stamp. These are included only where the chosen invoice template supports them." />
                <div className="grid gap-5 p-5 sm:grid-cols-2 sm:p-6">
                  <div className="sm:col-span-2"><ImageUploadBox label="Company logo" icon={<ImageIcon className="h-4 w-4 text-primary" />} hint="Use a clear, square or horizontal logo for your invoice header." value={form.logoImage} onChange={(value) => update("logoImage", value)} onClear={() => update("logoImage", undefined)} previewHeight={90} disabled={restricted} /></div>
                  <ImageUploadBox label="Authorised signature" icon={<PenLine className="h-4 w-4 text-primary" />} hint="Transparent PNG usually prints best. Leave blank to sign by hand." value={form.signatureImage} onChange={(value) => update("signatureImage", value)} onClear={() => update("signatureImage", undefined)} previewHeight={70} disabled={restricted} />
                  <ImageUploadBox label="Business stamp" icon={<Stamp className="h-4 w-4 text-primary" />} hint="Optional stamp image for templates that support stamps." value={form.stampImage} onChange={(value) => update("stampImage", value)} onClear={() => update("stampImage", undefined)} previewHeight={70} disabled={restricted} />
                </div>
              </motion.section>
            )}

            {activeSection === "terms" && (
              <motion.section key="terms" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className={cardClass}>
                <SectionHeading icon={<ScrollText className="h-5 w-5" />} title="Terms and conditions" description="These conditions are used on new invoices and can be printed as one condition per line." />
                <div className="p-5 sm:p-6">
                  <Field label="Invoice terms" hint="Use one condition per line. Keep wording clear and consistent with your business policy.">
                    <textarea disabled={restricted} value={form.termsAndConditions ?? DEFAULT_TERMS} onChange={(e) => update("termsAndConditions", e.target.value)} rows={9} placeholder={DEFAULT_TERMS} className="w-full resize-y rounded-xl border border-input bg-background px-3 py-3 text-sm leading-6 focus:outline-none focus:ring-2 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-60" />
                  </Field>
                  <div className="mt-4 rounded-xl border border-border/70 bg-muted/30 p-4 text-xs leading-5 text-muted-foreground"><strong className="text-foreground">Preview note:</strong> Exact placement depends on the invoice template you choose. Check a draft invoice before printing.</div>
                </div>
              </motion.section>
            )}

            {activeSection === "print" && (
              <motion.section key="print" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className={cardClass}>
                <SectionHeading icon={<Printer className="h-5 w-5" />} title="Bill print settings" description="Configure regular A4/A5 printing and thermal receipt printing. Settings are saved for this business account." />
                <div className="space-y-5 p-4 sm:p-6">
                  <div className="grid grid-cols-2 gap-2 rounded-xl bg-muted/60 p-1">
                    {([{ id: "regular", label: "REGULAR PRINTER", hint: "A4 / A5 paper" }, { id: "thermal", label: "THERMAL PRINTER", hint: "58mm / 80mm roll" }] as const).map((tab) => (
                      <button key={tab.id} type="button" onClick={() => { setPrinterTab(tab.id); setPrintSubTab("layout"); }} className={`rounded-lg px-3 py-3 text-left transition ${printerTab === tab.id ? "bg-background text-primary shadow-sm ring-1 ring-primary/20" : "text-muted-foreground hover:text-foreground"}`}>
                        <span className="block text-xs font-bold sm:text-sm">{tab.label}</span><span className="mt-1 block text-xs opacity-80">{tab.hint}</span>
                      </button>
                    ))}
                  </div>

                  <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_minmax(0,0.95fr)]">
                    <div className="min-w-0 space-y-5">
                      <div className="space-y-3">
                        <div className="flex gap-2 border-b border-border/70">
                          <button type="button" onClick={() => setPrintSubTab("layout")} className={`border-b-2 px-3 py-2 text-sm font-semibold ${printSubTab === "layout" ? "border-primary text-primary" : "border-transparent text-muted-foreground"}`}><SlidersHorizontal className="mr-1.5 inline h-4 w-4" /> Change Layout</button>
                          <button type="button" onClick={() => setPrintSubTab("colors")} className={`border-b-2 px-3 py-2 text-sm font-semibold ${printSubTab === "colors" ? "border-primary text-primary" : "border-transparent text-muted-foreground"}`}><Palette className="mr-1.5 inline h-4 w-4" /> Change Colors</button>
                        </div>

                        {printSubTab === "layout" ? (
                          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                            {([{ id: "classic", label: "Classic" }, { id: "modern", label: "Standard" }, { id: "gst", label: "GST Theme" }, { id: "compact", label: "Compact" }] as const).map((layout) => (
                              <button key={layout.id} type="button" disabled={restricted} onClick={() => updatePrintStyle({ layout: layout.id })} className={`rounded-xl border p-2 text-left transition ${printStyle.layout === layout.id ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "border-border hover:border-primary/40"}`}>
                                <div className="mb-2 flex h-16 flex-col gap-1 rounded-md border border-border/60 bg-white p-1.5">
                                  <div className="h-2 rounded-sm" style={{ background: printStyle.accentColor }} />
                                  <div className="grid flex-1 grid-cols-3 gap-1"><span className="rounded-sm bg-slate-100"/><span className="rounded-sm bg-slate-100"/><span className="rounded-sm bg-slate-100"/></div>
                                  <div className="h-1 rounded-sm bg-slate-200" />
                                </div>
                                <span className="flex items-center justify-between text-xs font-semibold">{layout.label}{printStyle.layout === layout.id && <Check className="h-3.5 w-3.5 text-primary" />}</span>
                              </button>
                            ))}
                          </div>
                        ) : (
                          <div className="space-y-3 rounded-xl border border-border/70 p-4">
                            <Field label="Invoice accent color" hint="Used by the built-in invoice layout. Imported admin templates can keep their own colors.">
                              <div className="flex items-center gap-3"><input aria-label="Invoice accent color" type="color" value={printStyle.accentColor || "#000000"} disabled={restricted} onChange={(e) => updatePrintStyle({ accentColor: e.target.value })} className="h-11 w-14 cursor-pointer rounded-lg border border-input bg-background p-1"/><Input value={printStyle.accentColor || "#000000"} disabled={restricted} onChange={(e) => updatePrintStyle({ accentColor: e.target.value })} className={inputClass} maxLength={7}/></div>
                            </Field>
                            <div className="flex flex-wrap gap-2">{["#000000", "#CE0084", "#2563EB", "#0F766E", "#7C3AED", "#B45309"].map((color) => <button key={color} type="button" disabled={restricted} aria-label={`Use ${color}`} onClick={() => updatePrintStyle({ accentColor: color })} className={`h-8 w-8 rounded-full border-2 ${printStyle.accentColor === color ? "border-foreground ring-2 ring-primary/30" : "border-white shadow"}`} style={{ backgroundColor: color }} />)}</div>
                          </div>
                        )}
                      </div>

                      <section className="rounded-xl border border-border/70 p-4">
                        <div className="mb-3 flex items-center justify-between gap-3"><div><h3 className="text-sm font-bold">Print Company Info / Header</h3><p className="mt-1 text-xs text-muted-foreground">Choose which business details appear on the built-in bill layout.</p></div><Button type="button" variant="outline" size="sm" onClick={() => setActiveSection("branding")} className="shrink-0">Manage logo</Button></div>
                        <div className="space-y-2.5">
                          <SettingSwitch disabled={restricted} label={`Make ${printerTab === "regular" ? "Regular" : "Thermal"} Printer Default`} description="Use this printer profile by default for invoice previews." checked={(form.defaultPrinter || "regular") === printerTab} onChange={(value) => setPrinterDefault(printerTab, value)} />
                          <SettingSwitch disabled={restricted} label="Show company name" description="Print your business/shop name in the invoice header." checked={printStyle.showCompanyName} onChange={(v) => updatePrintStyle({ showCompanyName: v })} />
                          <SettingSwitch disabled={restricted} label="Show company logo" description={form.logoImage ? "Logo uploaded. It will print when the chosen template supports it." : "Upload a logo from Invoice Branding to use it here."} checked={printStyle.showLogo} onChange={(v) => updatePrintStyle({ showLogo: v })} />
                          <SettingSwitch disabled={restricted} label="Show address" description="Print the business address." checked={printStyle.showAddress} onChange={(v) => updatePrintStyle({ showAddress: v })} />
                          <SettingSwitch disabled={restricted} label="Show phone number" description="Print the business contact number." checked={printStyle.showPhone} onChange={(v) => updatePrintStyle({ showPhone: v })} />
                          <SettingSwitch disabled={restricted} label="Show email" description="Print the business email address." checked={printStyle.showEmail} onChange={(v) => updatePrintStyle({ showEmail: v })} />
                          <SettingSwitch disabled={restricted} label="Show GSTIN on sale" description="Print GSTIN where applicable on GST invoices." checked={printStyle.showGstin} onChange={(v) => updatePrintStyle({ showGstin: v })} />
                        </div>
                      </section>

                      <section className="rounded-xl border border-border/70 p-4">
                        <h3 className="mb-3 text-sm font-bold">Print Options</h3>
                        <div className="grid gap-4 sm:grid-cols-2">
                          <Field label="Paper size"><Select disabled={restricted} value={printStyle.paperSize} onValueChange={(v) => updatePrintStyle({ paperSize: v as BillStyle["paperSize"] })}><SelectTrigger className={inputClass}><SelectValue /></SelectTrigger><SelectContent>{(printerTab === "regular" ? [{ value: "a4", label: "A4" }, { value: "a5", label: "A5" }] : [{ value: "thermal58", label: "58mm roll" }, { value: "thermal80", label: "80mm roll" }]).map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent></Select></Field>
                          {printerTab === "regular" && <Field label="Orientation"><Select disabled={restricted} value={printStyle.orientation} onValueChange={(v) => updatePrintStyle({ orientation: v as BillStyle["orientation"] })}><SelectTrigger className={inputClass}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="portrait">Portrait</SelectItem><SelectItem value="landscape">Landscape</SelectItem></SelectContent></Select></Field>}
                          <Field label="Company name text size"><Select disabled={restricted} value={printStyle.companyNameSize} onValueChange={(v) => updatePrintStyle({ companyNameSize: v as BillStyle["companyNameSize"] })}><SelectTrigger className={inputClass}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="small">Small</SelectItem><SelectItem value="medium">Medium</SelectItem><SelectItem value="large">Large</SelectItem></SelectContent></Select></Field>
                          <Field label="Invoice text size"><Select disabled={restricted} value={printStyle.invoiceTextSize} onValueChange={(v) => updatePrintStyle({ invoiceTextSize: v as BillStyle["invoiceTextSize"] })}><SelectTrigger className={inputClass}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="small">Small</SelectItem><SelectItem value="medium">Medium</SelectItem><SelectItem value="large">Large</SelectItem></SelectContent></Select></Field>
                          <Field label="Default number of copies"><Input type="number" min={1} max={5} disabled={restricted} value={String(printStyle.defaultCopies ?? 1)} onChange={(e) => updatePrintStyle({ defaultCopies: Math.max(1, Math.min(5, Number(e.target.value) || 1)) })} className={inputClass} /></Field>
                          {printerTab === "regular" && <Field label="Extra space on top of PDF (mm)"><Input type="number" min={0} max={25} disabled={restricted} value={String(printStyle.topMargin ?? 0)} onChange={(e) => updatePrintStyle({ topMargin: Math.max(0, Math.min(25, Number(e.target.value) || 0)) })} className={inputClass} /></Field>}
                        </div>
                        <div className="mt-4 space-y-2.5">
                          <SettingSwitch disabled={restricted} label="Print Original / Duplicate copy label" description="Show the copy label in the invoice header." checked={printStyle.showCopyLabel} onChange={(v) => updatePrintStyle({ showCopyLabel: v })} />
                          <SettingSwitch disabled={restricted} label="Repeat item-table header on each printed page" description="Keep the column headings visible on multipage invoices." checked={printStyle.repeatHeader !== false} onChange={(v) => updatePrintStyle({ repeatHeader: v })} />
                        </div>
                      </section>

                      <section className="rounded-xl border border-border/70 p-4">
                        <h3 className="mb-3 text-sm font-bold">Item Table Settings</h3>
                        <div className="space-y-2.5">
                          <SettingSwitch disabled={restricted} label="Show HSN/SAC code" description="Display the HSN/SAC column." checked={printStyle.showHsn} onChange={(v) => updatePrintStyle({ showHsn: v })} />
                          <SettingSwitch disabled={restricted} label="Show unit" description="Display item units such as Pcs, Kg or Job." checked={printStyle.showUnit} onChange={(v) => updatePrintStyle({ showUnit: v })} />
                          <SettingSwitch disabled={restricted} label="Show GST column" description="Display GST amount/rate for each item." checked={printStyle.showGstColumn !== false} onChange={(v) => updatePrintStyle({ showGstColumn: v })} />
                          <SettingSwitch disabled={restricted} label="Show item serial number" description="Show the numbered item rows." checked={printStyle.showSerialNumber !== false} onChange={(v) => updatePrintStyle({ showSerialNumber: v })} />
                          <SettingSwitch disabled={restricted} label="Show discount column" description="Saved for templates that support line-item discounts." checked={printStyle.showDiscountColumn === true} onChange={(v) => updatePrintStyle({ showDiscountColumn: v })} />
                          <SettingSwitch disabled={restricted} label="Show last sale price" description="Optional column preference for templates with price history." checked={printStyle.showLastSalePrice === true} onChange={(v) => updatePrintStyle({ showLastSalePrice: v })} />
                          <SettingSwitch disabled={restricted} label="Show free item quantity" description="Optional quantity preference for supported templates." checked={printStyle.showFreeItemQuantity === true} onChange={(v) => updatePrintStyle({ showFreeItemQuantity: v })} />
                          <SettingSwitch disabled={restricted} label="Show item remarks" description="Optional remarks column preference for supported templates." checked={printStyle.showItemRemarks === true} onChange={(v) => updatePrintStyle({ showItemRemarks: v })} />
                          <Field label="Item table font size"><Select disabled={restricted} value={printStyle.itemTableFontSize || "normal"} onValueChange={(v) => updatePrintStyle({ itemTableFontSize: v as NonNullable<BillStyle["itemTableFontSize"]> })}><SelectTrigger className={inputClass}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="small">Small</SelectItem><SelectItem value="normal">Normal</SelectItem><SelectItem value="large">Large</SelectItem></SelectContent></Select></Field>
                        </div>
                      </section>
                    </div>

                    <div className="min-w-0 space-y-4">
                      <div className="rounded-xl border border-border/70 bg-muted/20 p-3"><div className="mb-2 flex items-center gap-2"><Printer className="h-4 w-4 text-primary"/><h3 className="text-sm font-bold">{printerTab === "regular" ? "Regular Printer" : "Thermal Printer"} Preview</h3></div><p className="mb-3 text-xs text-muted-foreground">Sample preview updates with the settings on the left. Custom uploaded templates may keep their own internal layout.</p><BillThemePreview shopInfo={{ ...shopInfo, ...form, billStyle: printStyle, defaultPrinter: "regular" }} style={printStyle} /></div>
                      <div className="rounded-xl border border-border/70 p-4"><div className="flex items-start gap-3"><Info className="mt-0.5 h-4 w-4 shrink-0 text-primary"/><div><p className="text-sm font-semibold">Settings are saved per user</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Regular and thermal profiles are stored separately with your account. Built-in invoice layouts use these controls directly; admin-uploaded HTML templates retain their own specialized layout rules.</p></div></div></div>
                    </div>
                  </div>
                </div>
              </motion.section>
            )}

            {activeSection === "ca" && (
              <motion.section key="ca" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="min-w-0 space-y-3">
                <div className="rounded-2xl border border-border/70 bg-card p-4 shadow-sm"><div className="flex items-start gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary"><ShieldCheck className="h-5 w-5" /></div><div><h2 className="font-semibold">Control accountant access</h2><p className="mt-1 text-sm leading-5 text-muted-foreground">A CA should only see your business data after you approve their access request. You can review permissions or revoke access here.</p></div></div></div>
                <CaAccessManager />
              </motion.section>
            )}

            {activeSection === "templates" && (
              <motion.section key="templates" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className={cardClass}>
                <SectionHeading icon={<ReceiptText className="h-5 w-5" />} title="Bill templates" description="Choose an approved invoice layout when creating a new bill." />
                <div className="space-y-4 p-5 sm:p-6">
                  <div className="flex items-start gap-3 rounded-xl border border-border/70 bg-muted/30 p-4"><FileText className="mt-0.5 h-5 w-5 shrink-0 text-primary" /><div><div className="text-sm font-semibold">Templates managed by your administrator</div><p className="mt-1 text-sm leading-5 text-muted-foreground">Available templates are maintained centrally so the invoice design stays consistent. Select the template from the new invoice screen.</p></div></div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {[{ title: "Preview before printing", text: "Confirm business, customer, tax and total fields in the invoice preview." }, { title: "Print-ready layout", text: "Use the Print or PDF action on the invoice to produce an A4 copy." }].map((item) => <div key={item.title} className="rounded-xl border border-border/70 p-4"><div className="text-sm font-semibold">{item.title}</div><p className="mt-1 text-xs leading-5 text-muted-foreground">{item.text}</p></div>)}
                  </div>
                </div>
              </motion.section>
            )}
          </div>
        </div>

        {activeSection !== "ca" && activeSection !== "templates" && (
          <div className="pointer-events-none fixed inset-x-0 bottom-0 z-30 flex justify-center px-3 pb-3 sm:px-6">
            <div className={`pointer-events-auto flex w-full max-w-3xl flex-col gap-3 rounded-2xl border border-border/80 bg-card/95 p-3 shadow-2xl backdrop-blur sm:flex-row sm:items-center sm:justify-between sm:px-5 ${dirty ? "" : "opacity-95"}`}>
              <div className="flex min-w-0 items-center gap-2 text-sm">
                {dirty ? <span className="h-2 w-2 shrink-0 rounded-full bg-amber-500" /> : <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />}
                <span className="truncate text-muted-foreground">{dirty ? "You have unsaved changes" : "All changes saved"}</span>
              </div>
              <div className="flex items-center gap-2 self-end sm:self-auto">
                <Button type="button" variant="outline" disabled={!dirty || restricted} onClick={handleReset} className="gap-2"><RotateCcw className="h-4 w-4" /> Discard</Button>
                <Button type="button" disabled={!dirty || restricted} onClick={handleSave} className="gap-2"><Save className="h-4 w-4" /> Save settings</Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default SettingsPage;
