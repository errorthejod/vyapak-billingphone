import { useMemo, useState } from "react";
import Layout from "@/components/Layout";
import { useCurrentStore } from "@/store/useCurrentStore";
import { gstRowFromInvoice, inr, inr0 } from "@/lib/gst";
import { Search, Percent, FileText } from "lucide-react";


type RangeKey = "today" | "month" | "all" | "custom";

const RANGES: { key: RangeKey; label: string }[] = [
  { key: "today", label: "Today" },
  { key: "month", label: "This Month" },
  { key: "all", label: "All Time" },
  { key: "custom", label: "Custom" },
];

function inRange(date: string, range: RangeKey, from: string, to: string) {
  const d = date.slice(0, 10);
  const now = new Date();
  const iso = (x: Date) => x.toISOString().slice(0, 10);
  if (range === "today") return d === iso(now);
  if (range === "month") return d.slice(0, 7) === iso(now).slice(0, 7);
  if (range === "custom") {
    if (from && d < from) return false;
    if (to && d > to) return false;
    return true;
  }
  return true;
}

export default function GstPage() {
  const { invoices } = useCurrentStore();
  const [range, setRange] = useState<RangeKey>("month");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [query, setQuery] = useState("");

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return invoices
      .filter(i => inRange(i.date, range, from, to))
      .filter(i => !q || i.partyName.toLowerCase().includes(q) || i.invoiceNumber.toLowerCase().includes(q))
      .map(gstRowFromInvoice)
      .sort((a, b) => (a.invoice.date < b.invoice.date ? 1 : -1));
  }, [invoices, range, from, to, query]);

  const totals = useMemo(() => {
    const sales = rows.filter(r => r.invoice.type === "sale");
    const purchases = rows.filter(r => r.invoice.type === "purchase");
    const output = sales.reduce((s, r) => s + r.totalGst, 0);
    const input = purchases.reduce((s, r) => s + r.totalGst, 0);
    return {
      output,
      input,
      payable: Math.max(0, output - input),
      taxable: sales.reduce((s, r) => s + r.taxable, 0),
      cgst: sales.reduce((s, r) => s + r.cgst, 0),
      sgst: sales.reduce((s, r) => s + r.sgst, 0),
      igst: sales.reduce((s, r) => s + r.igst, 0),
      gstBills: sales.filter(r => r.gstEnabled).length,
    };
  }, [rows]);

  return (
    <Layout>
      <div className="flex flex-col h-full -m-4 md:-m-6">
        {/* ── SUMMARY HEADER ── */}
        <div className="relative shrink-0 overflow-hidden border-b border-border/60 bg-gradient-to-br from-card via-card to-muted px-4 py-6 md:px-5 md:py-7">
          <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-72 -translate-x-1/2 rounded-full bg-primary/20 blur-3xl" />
          <div className="relative text-center">

            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">GST Payable</p>
            <p className="mt-2 text-4xl md:text-5xl font-extrabold text-primary drop-shadow-[0_0_24px_hsl(var(--primary)/0.35)]">
              {inr0(totals.payable)}
            </p>
            <div className="mt-3 inline-flex flex-wrap items-center justify-center gap-2 text-xs">
              <span className="rounded-full border border-primary/30 bg-primary/10 px-3 py-1 font-medium text-primary">
                Output GST {inr0(totals.output)}
              </span>
              <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 font-medium text-emerald-600">
                Input GST / ITC {inr0(totals.input)}
              </span>
              <span className="rounded-full border border-border bg-muted px-3 py-1 font-medium text-muted-foreground">
                Taxable {inr0(totals.taxable)}
              </span>
              <span className="rounded-full border border-border bg-muted px-3 py-1 font-medium text-muted-foreground">
                {totals.gstBills} GST {totals.gstBills === 1 ? "bill" : "bills"}
              </span>
            </div>

            <div className="mt-4 grid grid-cols-3 gap-2 max-w-md mx-auto">
              {[
                { label: "CGST", value: totals.cgst },
                { label: "SGST", value: totals.sgst },
                { label: "IGST", value: totals.igst },
              ].map(b => (
                <div key={b.label} className="rounded-xl border border-border/60 bg-card px-2 py-2 shadow-sm">
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{b.label}</p>
                  <p className="text-sm font-bold text-foreground">{inr0(b.value)}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── FILTERS + LIST ── */}
        <div className="flex-1 overflow-auto p-4 space-y-3 bg-muted/40">
          <div className="flex flex-wrap gap-2">
            {RANGES.map(r => (
              <button
                key={r.key}
                onClick={() => setRange(r.key)}
                className={`text-xs font-semibold px-3.5 py-2 rounded-xl border transition-all ${
                  range === r.key
                    ? "border-primary bg-primary text-primary-foreground shadow-[0_6px_18px_-6px_hsl(var(--primary))]"
                    : "border-border/70 bg-card text-foreground hover:border-primary/40"
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>

          {range === "custom" && (
            <div className="flex flex-wrap items-center gap-2">
              <input type="date" value={from} onChange={e => setFrom(e.target.value)}
                className="rounded-xl border border-border/70 bg-card px-3 py-2 text-sm outline-none focus:border-primary" />
              <span className="text-xs text-muted-foreground">to</span>
              <input type="date" value={to} onChange={e => setTo(e.target.value)}
                className="rounded-xl border border-border/70 bg-card px-3 py-2 text-sm outline-none focus:border-primary" />
            </div>
          )}

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search party or bill no."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-border/70 bg-card shadow-sm outline-none transition-all focus:border-primary focus:ring-4 focus:ring-primary/15"
            />
          </div>

          {rows.length === 0 ? (
            <div className="rounded-2xl border border-border/60 bg-card p-10 text-center shadow-sm">
              <Percent className="h-6 w-6 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">No bills in this period.</p>
            </div>
          ) : (
            <>
              {/* Mobile cards */}
              <div className="space-y-2.5 md:hidden">
                {rows.map(r => (
                  <div key={r.invoice.id} className="rounded-2xl border border-border/60 bg-card p-4 shadow-sm">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-bold truncate">{r.invoice.partyName || "Cash Sale"}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{r.invoice.invoiceNumber} · {r.invoice.date}</p>
                      </div>
                      <span className={`shrink-0 rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase ${
                        r.gstEnabled
                          ? "border-primary/30 bg-primary/10 text-primary"
                          : "border-border bg-muted text-muted-foreground"
                      }`}>
                        {r.gstEnabled ? `GST ${r.rate}%` : "Non-GST"}
                      </span>
                    </div>
                    <div className="mt-3 grid grid-cols-2 gap-2 text-xs border-t border-border/60 pt-3">
                      <div><span className="text-muted-foreground">Taxable</span><p className="font-semibold">{inr(r.taxable)}</p></div>
                      <div><span className="text-muted-foreground">Total GST</span><p className="font-semibold text-primary">{inr(r.totalGst)}</p></div>
                      <div><span className="text-muted-foreground">CGST</span><p className="font-medium">{inr(r.cgst)}</p></div>
                      <div><span className="text-muted-foreground">SGST</span><p className="font-medium">{inr(r.sgst)}</p></div>
                      <div><span className="text-muted-foreground">IGST</span><p className="font-medium">{inr(r.igst)}</p></div>
                      <div><span className="text-muted-foreground">Invoice total</span><p className="font-bold">{inr(r.total)}</p></div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Desktop table */}
              <div className="hidden md:block rounded-2xl border border-border/60 bg-card shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted/60 text-[11px] uppercase tracking-wide text-muted-foreground">
                        <th className="px-3 py-2.5 text-left font-semibold">Bill No</th>
                        <th className="px-3 py-2.5 text-left font-semibold">Customer</th>
                        <th className="px-3 py-2.5 text-left font-semibold">Date</th>
                        <th className="px-3 py-2.5 text-right font-semibold">Taxable</th>
                        <th className="px-3 py-2.5 text-center font-semibold">GST %</th>
                        <th className="px-3 py-2.5 text-right font-semibold">CGST</th>
                        <th className="px-3 py-2.5 text-right font-semibold">SGST</th>
                        <th className="px-3 py-2.5 text-right font-semibold">IGST</th>
                        <th className="px-3 py-2.5 text-right font-semibold">Total GST</th>
                        <th className="px-3 py-2.5 text-right font-semibold">Invoice Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/60">
                      {rows.map(r => (
                        <tr key={r.invoice.id} className="hover:bg-muted/30 transition-colors">
                          <td className="px-3 py-2.5 font-medium whitespace-nowrap">
                            <span className="inline-flex items-center gap-1.5">
                              <FileText className="h-3.5 w-3.5 text-muted-foreground" />
                              {r.invoice.invoiceNumber}
                            </span>
                          </td>
                          <td className="px-3 py-2.5">{r.invoice.partyName || "Cash Sale"}</td>
                          <td className="px-3 py-2.5 text-muted-foreground whitespace-nowrap">{r.invoice.date}</td>
                          <td className="px-3 py-2.5 text-right">{inr(r.taxable)}</td>
                          <td className="px-3 py-2.5 text-center">
                            {r.gstEnabled ? `${r.rate}%` : <span className="text-muted-foreground">Non-GST</span>}
                          </td>
                          <td className="px-3 py-2.5 text-right">{inr(r.cgst)}</td>
                          <td className="px-3 py-2.5 text-right">{inr(r.sgst)}</td>
                          <td className="px-3 py-2.5 text-right">{inr(r.igst)}</td>
                          <td className="px-3 py-2.5 text-right font-semibold text-primary">{inr(r.totalGst)}</td>
                          <td className="px-3 py-2.5 text-right font-bold">{inr(r.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </Layout>
  );
}
