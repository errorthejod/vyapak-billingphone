import { useState } from "react";
import { Link, useNavigate } from "@/lib/nav";
import { BriefcaseBusiness, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useAuthStore } from "@/store/useAuthStore";

export default function CaSignup() {
  const caSignup = useAuthStore((s) => s.caSignup);
  const [form, setForm] = useState({ name: "", firmName: "", email: "", mobile: "", registrationNo: "", password: "", confirm: "" });
  const [showPending, setShowPending] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const update = (field: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement>) => setForm(old => ({ ...old, [field]: event.target.value }));

  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); setError("");
    if (!form.name.trim() || !form.firmName.trim() || !form.email.trim() || !form.mobile.trim() || !form.password) return setError("Please complete all required fields.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) return setError("Enter a valid email address.");
    if (form.mobile.replace(/\D/g, "").length < 10) return setError("Enter a valid 10-digit mobile number.");
    if (form.password.length < 6) return setError("Password must be at least 6 characters.");
    if (form.password !== form.confirm) return setError("Passwords do not match.");
    setBusy(true);
    try {
      await caSignup({ name: form.name.trim(), firmName: form.firmName.trim(), email: form.email.trim(), mobile: form.mobile, password: form.password, registrationNo: form.registrationNo.trim() || undefined });
      setShowPending(true);
      toast.success("CA registration submitted for review");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not register CA account.");
    } finally { setBusy(false); }
  };

  if (showPending) return <div className="min-h-screen flex items-center justify-center bg-sidebar p-4"><div className="w-full max-w-md rounded-2xl border border-sidebar-border bg-sidebar-accent/40 p-8 text-center text-sidebar-foreground shadow-2xl"><div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/15"><ShieldCheck className="h-7 w-7 text-emerald-500" /></div><h1 className="text-2xl font-bold">Registration Submitted</h1><p className="mt-3 text-sm text-sidebar-foreground/70">Your CA account is pending Admin approval. You can log in after your registration is approved.</p><Button className="mt-6 w-full" onClick={() => navigate("/login", { replace: true })}>Go to Login</Button></div></div>;

  const inputClass = "bg-sidebar/60 border-sidebar-border text-sidebar-accent-foreground placeholder:text-sidebar-foreground/40";
  return <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-sidebar p-4"><div className="pointer-events-none absolute -top-24 left-1/4 h-72 w-72 rounded-full bg-primary/25 blur-[100px]"/><div className="relative w-full max-w-lg py-6"><div className="mb-6 text-center"><div className="brand-gradient mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl"><BriefcaseBusiness className="h-7 w-7 text-primary-foreground"/></div><h1 className="brand-text text-3xl font-black">Vyapak Billing</h1><p className="mt-1 text-sm text-sidebar-foreground/70">Chartered Accountant Portal</p></div><div className="rounded-2xl border border-sidebar-border bg-sidebar-accent/40 p-7 shadow-2xl"><h2 className="text-center text-xl font-semibold text-sidebar-accent-foreground">Register as CA</h2><p className="mb-5 mt-1 text-center text-xs text-sidebar-foreground/60">Your account needs Admin approval before you can log in.</p><form onSubmit={submit} className="space-y-4"><div className="grid gap-4 sm:grid-cols-2">{([['name','Full Name'],['firmName','CA Firm Name'],['email','Email'],['mobile','Mobile Number'],['registrationNo','Membership / Registration No.']] as [keyof typeof form,string][]).map(([key,label])=><div key={key}><Label className="text-sm text-sidebar-foreground">{label}{key!=='registrationNo'?' *':''}</Label><Input className={`${inputClass} mt-1.5`} value={form[key]} onChange={update(key)} type={key==='email'?'email':'text'} autoComplete={key==='email'?'email':key==='mobile'?'tel':'off'} placeholder={key==='registrationNo'?'Optional':''}/></div>)}</div><div className="grid gap-4 sm:grid-cols-2"><div><Label className="text-sm text-sidebar-foreground">Password *</Label><Input className={`${inputClass} mt-1.5`} type="password" autoComplete="new-password" value={form.password} onChange={update('password')}/></div><div><Label className="text-sm text-sidebar-foreground">Confirm Password *</Label><Input className={`${inputClass} mt-1.5`} type="password" autoComplete="new-password" value={form.confirm} onChange={update('confirm')}/></div></div>{error&&<p className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">{error}</p>}<Button disabled={busy} className="brand-gradient h-11 w-full font-semibold">{busy?'Submitting…':'Create CA Account'}</Button></form><div className="mt-5 border-t border-sidebar-border pt-4 text-center text-xs text-sidebar-foreground/60"><p>Already registered? <Link to="/login" className="font-semibold text-primary hover:underline">Login</Link></p><p className="mt-2">Business owner? <Link to="/signup" className="font-semibold text-primary hover:underline">Create a business account</Link></p></div></div></div></div>;
}
