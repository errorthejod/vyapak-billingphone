import { useEffect, useMemo, useState } from "react";
import { useAuthStore } from "@/store/useAuthStore";
import { useAccessStore } from "@/store/useAccessStore";
import { api, Plan } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import {
  Check, Sparkles, Loader2, QrCode, Upload, ShieldCheck, Clock, XCircle, FileText,
} from "lucide-react";

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || "");
      resolve(result.slice(result.indexOf(",") + 1));
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function Plans() {
  const currentUserId = useAuthStore((s) => s.currentUserId) || "";
  const { account, payments, refresh } = useAccessStore();

  const [plans, setPlans] = useState<Plan[]>([]);
  const [qr, setQr] = useState("");
  const [upi, setUpi] = useState("");
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Plan | null>(null);
  const [utr, setUtr] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const [p, cfg] = await Promise.all([api.getPlans(), api.getAdminConfig()]);
        if (!alive) return;
        setPlans(p);
        setQr(cfg.paymentQrUrl || "");
        setUpi(cfg.upiId || "");
      } catch {
        toast.error("Could not load plans");
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, []);

  const pending = useMemo(() => payments.find((p) => p.status === "pending"), [payments]);

  const submit = async () => {
    if (!selected) return;
    if (!utr.trim()) { toast.error("Enter the UTR / transaction reference"); return; }
    setBusy(true);
    try {
      const extra = file
        ? { fileName: file.name, fileType: file.type, fileBase64: await fileToBase64(file) }
        : {};
      const result = await api.submitPayment({ userId: currentUserId, planId: selected.id, utr: utr.trim(), ...extra });
      toast.success("Purchase request submitted — we'll verify your payment shortly");
      if (!result.notifications?.adminSent || !result.notifications?.buyerSent) {
        const reasons = [result.notifications?.adminReason, result.notifications?.buyerReason].filter(Boolean);
        const reasonText = reasons.length ? ` (${[...new Set(reasons)].join(", ")})` : "";
        toast.warning(`Purchase is saved, but an email could not be delivered${reasonText}. Check Resend settings or server logs.`);
      }
      setSelected(null);
      setUtr("");
      setFile(null);
      if (currentUserId) await refresh(currentUserId);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not submit payment");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-5xl space-y-8 py-2">
      <header className="text-center">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10">
          <Sparkles className="h-5 w-5 text-primary" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight">Plans &amp; Pricing</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Unlock unlimited billing, GST invoices, reports and backups.
        </p>
        {account && (
          <p className="mt-3 inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs">
            <span className={cn("h-2 w-2 rounded-full", account.status === "active" ? "bg-emerald-500" : "bg-destructive")} />
            {account.status === "active"
              ? `Active${account.planExpiry ? ` till ${new Date(account.planExpiry).toLocaleDateString("en-IN")}` : ""}`
              : account.status === "expired" ? "Plan expired" : "Plan inactive"}
          </p>
        )}
      </header>

      {pending && (
        <div className="flex items-start gap-3 rounded-xl border border-amber-300 bg-amber-50 p-4 text-amber-900">
          <Clock className="mt-0.5 h-4 w-4 shrink-0" />
          <div className="text-sm">
            <p className="font-semibold">Payment under review</p>
            <p className="text-xs">
              Your proof for {pending.planName} (₹{pending.amount}, UTR {pending.utr}) is being verified.
              You'll get an email once it's approved.
            </p>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-16"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2">
          {plans.map((plan, i) => (
            <div
              key={plan.id}
              className={cn(
                "relative rounded-2xl border bg-card p-6 shadow-sm",
                i === 1 && "border-primary ring-1 ring-primary/30",
              )}
            >
              {i === 1 && (
                <span className="absolute -top-3 right-5 rounded-full bg-primary px-2.5 py-0.5 text-[11px] font-semibold text-primary-foreground">
                  Best value
                </span>
              )}
              <h2 className="text-base font-semibold">{plan.name}</h2>
              <div className="mt-2 flex items-end gap-1">
                <span className="text-3xl font-black tracking-tight">₹{plan.price.toLocaleString("en-IN")}</span>
                <span className="pb-1 text-xs text-muted-foreground">
                  / {plan.durationMonths} months
                </span>
              </div>
              <ul className="mt-4 space-y-2">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                    {f}
                  </li>
                ))}
              </ul>
              <Button className="mt-6 w-full" onClick={() => setSelected(plan)}>
                Purchase Plan
              </Button>
            </div>
          ))}
        </div>
      )}

      <section className="rounded-2xl border bg-card p-5 sm:p-6">
        <h2 className="font-semibold">Need Help?</h2>
        <p className="mt-1 text-sm text-muted-foreground">Contact our support team for plans, renewals, or payment verification.</p>
        <div className="mt-4 flex flex-wrap gap-3 text-sm">
          <a className="inline-flex items-center gap-2 rounded-lg border px-4 py-2 hover:bg-muted" href="tel:9711212040">📞 Helpline: 9711212040</a>
          <a className="inline-flex items-center gap-2 rounded-lg border px-4 py-2 hover:bg-muted" href="mailto:vyapakbilling2026@gmail.com">✉ vyapakbilling2026@gmail.com</a>
        </div>
      </section>

      {payments.length > 0 && (
        <section className="space-y-2">
          <h3 className="text-sm font-semibold">Payment history</h3>
          <div className="space-y-2">
            {payments.map((p) => (
              <div key={p.id} className="flex items-center justify-between gap-3 rounded-xl border px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{p.planName} · ₹{p.amount}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    UTR {p.utr} · {new Date(p.createdAt).toLocaleDateString("en-IN")}
                  </p>
                </div>
                <span className={cn(
                  "flex shrink-0 items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
                  p.status === "approved" && "bg-emerald-100 text-emerald-700",
                  p.status === "pending" && "bg-amber-100 text-amber-700",
                  p.status === "rejected" && "bg-red-100 text-red-700",
                )}>
                  {p.status === "approved" ? <ShieldCheck className="h-3 w-3" />
                    : p.status === "pending" ? <Clock className="h-3 w-3" />
                    : <XCircle className="h-3 w-3" />}
                  {p.status}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="h-4 w-4 text-primary" />
              Scan &amp; Pay — {selected?.name}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="rounded-xl border bg-muted/40 p-4 text-center">
              {qr ? (
                <img src={qr} alt="Vyapak Billing payment QR code" className="mx-auto h-48 w-48 rounded-lg bg-white object-contain p-2" />
              ) : (
                <div className="mx-auto flex h-48 w-48 items-center justify-center rounded-lg border border-dashed text-xs text-muted-foreground">
                  QR code not configured yet
                </div>
              )}
              <p className="mt-3 text-2xl font-black">₹{selected?.price.toLocaleString("en-IN")}</p>
              {upi && <p className="text-xs text-muted-foreground">UPI ID: <span className="font-mono">{upi}</span></p>}
              <p className="mt-2 text-xs text-muted-foreground">
                Scan the QR with any UPI app, pay the exact amount, then submit the payment proof below.
              </p>
            </div>

            <div>
              <Label>UTR / Transaction ID *</Label>
              <Input value={utr} onChange={(e) => setUtr(e.target.value)} placeholder="e.g. 431298765432" className="mt-1" />
            </div>

            <div>
              <Label>Payment screenshot / receipt (JPG, PNG or PDF)</Label>
              <input
                id="proof-input"
                type="file"
                accept="image/png,image/jpeg,application/pdf"
                className="hidden"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              />
              <Button
                variant="outline"
                className="mt-1 w-full justify-start"
                onClick={() => document.getElementById("proof-input")?.click()}
              >
                {file ? <FileText className="mr-2 h-4 w-4" /> : <Upload className="mr-2 h-4 w-4" />}
                <span className="truncate">{file ? file.name : "Choose file"}</span>
              </Button>
            </div>

            <Button className="w-full" onClick={submit} disabled={busy}>
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
              {busy ? "Submitting..." : "Submit Payment Proof"}
            </Button>
            <p className="text-center text-[11px] text-muted-foreground">
              Our team verifies payments manually. You'll be notified by email once approved.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
