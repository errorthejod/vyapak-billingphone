import { useMemo, useRef, useState } from "react";
import Layout from "@/components/Layout";
import { useCurrentStore as useStore } from "@/store/useCurrentStore";
import { Invoice } from "@/types";
import { InvoiceTemplate } from "@/components/InvoiceTemplate";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Eye, RotateCcw, Trash2, Search, Trash } from "lucide-react";
import { toast } from "sonner";

const fmt = (n: number) => `₹${(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;

const gstOf = (inv: Invoice) =>
  (inv.totalCgst || 0) + (inv.totalSgst || 0) + (inv.igst || 0);

const payTypeOf = (inv: Invoice) => (inv.isCredit ? "Credit" : "Cash");

export default function RemovedBills() {
  const { deletedInvoices, shopInfo, restoreInvoice, purgeInvoice } = useStore();
  const [query, setQuery] = useState("");
  const [showInvoice, setShowInvoice] = useState<Invoice | null>(null);
  const [confirmPurge, setConfirmPurge] = useState<Invoice | null>(null);
  const invoiceRef = useRef<HTMLDivElement>(null);

  const bills = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = [...deletedInvoices].sort(
      (a, b) => new Date(b.deletedAt || b.createdAt).getTime() - new Date(a.deletedAt || a.createdAt).getTime(),
    );
    if (!q) return list;
    return list.filter(
      (b) =>
        b.invoiceNumber?.toLowerCase().includes(q) ||
        b.partyName?.toLowerCase().includes(q) ||
        b.partyPhone?.toLowerCase().includes(q),
    );
  }, [deletedInvoices, query]);

  const handleRestore = (inv: Invoice) => {
    restoreInvoice(inv.id);
    toast.success(`${inv.invoiceNumber} restored`);
  };

  const handlePurge = (inv: Invoice) => {
    purgeInvoice(inv.id);
    setConfirmPurge(null);
    toast.success(`${inv.invoiceNumber} permanently deleted`);
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-2xl font-heading font-bold text-foreground">Removed Bills</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Deleted invoices are kept here. You can view, restore or permanently delete them.
            </p>
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search bill no, party or phone"
              className="pl-9 h-9 text-sm"
            />
          </div>
        </div>

        <div className="bg-card rounded-xl p-5 card-shadow">
          <h3 className="font-heading font-semibold mb-4 flex items-center gap-2">
            <Trash className="h-4 w-4 text-destructive" />
            Removed Bills ({bills.length})
          </h3>

          {bills.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Trash className="h-10 w-10 mx-auto mb-3 opacity-30" />
              <p className="text-sm">No removed bills.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="py-2 pr-3">Invoice No</th>
                    <th className="py-2 pr-3">Date</th>
                    <th className="py-2 pr-3">Customer / Party</th>
                    <th className="py-2 pr-3 text-right">Amount</th>
                    <th className="py-2 pr-3 text-right">GST</th>
                    <th className="py-2 pr-3">Payment</th>
                    <th className="py-2 pr-3">Deleted On</th>
                    <th className="py-2 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {bills.map((inv) => (
                    <tr key={inv.id} className="border-t border-border/60">
                      <td className="py-3 pr-3 font-medium">{inv.invoiceNumber}</td>
                      <td className="py-3 pr-3 text-muted-foreground">{inv.date}</td>
                      <td className="py-3 pr-3">
                        <p className="font-medium">{inv.partyName || "—"}</p>
                        {inv.partyPhone && (
                          <p className="text-xs text-muted-foreground">{inv.partyPhone}</p>
                        )}
                      </td>
                      <td className="py-3 pr-3 text-right font-semibold">{fmt(inv.totalAmount)}</td>
                      <td className="py-3 pr-3 text-right">{fmt(gstOf(inv))}</td>
                      <td className="py-3 pr-3">{payTypeOf(inv)}</td>
                      <td className="py-3 pr-3 text-xs text-muted-foreground">
                        {inv.deletedAt ? new Date(inv.deletedAt).toLocaleString("en-IN") : "—"}
                      </td>
                      <td className="py-3">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" title="View bill" onClick={() => setShowInvoice(inv)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Restore bill" onClick={() => handleRestore(inv)}>
                            <RotateCcw className="h-4 w-4 text-primary" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            title="Delete permanently"
                            onClick={() => setConfirmPurge(inv)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <Dialog open={!!showInvoice} onOpenChange={() => setShowInvoice(null)}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-auto">
            <DialogHeader>
              <DialogTitle>Removed Bill Preview</DialogTitle>
            </DialogHeader>
            {showInvoice && <InvoiceTemplate ref={invoiceRef} invoice={showInvoice} shopInfo={shopInfo} />}
          </DialogContent>
        </Dialog>

        <Dialog open={!!confirmPurge} onOpenChange={() => setConfirmPurge(null)}>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle>Delete permanently?</DialogTitle>
            </DialogHeader>
            <p className="text-sm text-muted-foreground">
              {confirmPurge?.invoiceNumber} will be removed for good. This cannot be undone.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setConfirmPurge(null)}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={() => confirmPurge && handlePurge(confirmPurge)}>
                Delete permanently
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
