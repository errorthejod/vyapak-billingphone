import { useMemo, useState } from "react";
import { useNavigate } from "@/lib/nav";
import Layout from "@/components/Layout";
import { useCurrentStore } from "@/store/useCurrentStore";
import { useAuthStore } from "@/store/useAuthStore";
import { SaleFormDialog } from "@/components/SaleFormDialog";
import { PurchaseFormDialog } from "@/components/PurchaseFormDialog";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  ArrowDownLeft,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  Boxes,
  CalendarDays,
  CheckCircle2,
  CircleDollarSign,
  ClipboardList,
  CreditCard,
  FileText,
  Package,
  Plus,
  ShoppingBag,
  ShoppingCart,
  TrendingUp,
  Users,
} from "lucide-react";
import type { Invoice } from "@/types";
import type { LucideIcon } from "lucide-react";

type DatePreset = "today" | "week" | "month" | "year" | "custom";

const currency = (value: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number.isFinite(value) ? value : 0);

const compactCurrency = (value: number) => {
  if (value >= 10_000_000) return `₹${(value / 10_000_000).toFixed(1)}Cr`;
  if (value >= 100_000) return `₹${(value / 100_000).toFixed(1)}L`;
  if (value >= 1_000) return `₹${(value / 1_000).toFixed(1)}k`;
  return `₹${Math.round(value)}`;
};

const dateKey = (date: Date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const startOfWeek = (date: Date) => {
  const result = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  result.setDate(result.getDate() - ((result.getDay() + 6) % 7));
  return result;
};

function invoicePaidAmount(invoice: Invoice) {
  const received = invoice.receivedAmount;
  const paid = received == null ? (invoice.isCredit ? 0 : invoice.totalAmount) : received;
  return Math.max(0, Math.min(invoice.totalAmount, Number(paid) || 0));
}

function makeDateRange(preset: DatePreset, start: string, end: string, now: Date) {
  const today = dateKey(now);
  if (preset === "today") return { start: today, end: today };
  if (preset === "week") return { start: dateKey(startOfWeek(now)), end: today };
  if (preset === "year") return { start: `${now.getFullYear()}-01-01`, end: today };
  if (preset === "custom") {
    const a = start || today;
    const b = end || today;
    return a <= b ? { start: a, end: b } : { start: b, end: a };
  }
  return {
    start: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`,
    end: today,
  };
}

function buildChartData(invoices: Invoice[], start: string, end: string) {
  const startDate = new Date(`${start}T00:00:00`);
  const endDate = new Date(`${end}T00:00:00`);
  if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime())) return [];
  const dayCount = Math.max(
    1,
    Math.round((endDate.getTime() - startDate.getTime()) / 86_400_000) + 1,
  );
  const monthly = dayCount > 62;
  const totals = new Map<string, { sale: number; purchase: number }>();

  for (const invoice of invoices) {
    const key = monthly ? invoice.date.slice(0, 7) : invoice.date.slice(0, 10);
    const current = totals.get(key) || { sale: 0, purchase: 0 };
    if (invoice.type === "sale") current.sale += invoice.totalAmount;
    else current.purchase += invoice.totalAmount;
    totals.set(key, current);
  }

  const points: { label: string; sale: number; purchase: number }[] = [];
  const cursor = new Date(
    startDate.getFullYear(),
    monthly ? startDate.getMonth() : startDate.getMonth(),
    monthly ? 1 : startDate.getDate(),
  );
  const limit = new Date(
    endDate.getFullYear(),
    endDate.getMonth(),
    monthly ? 1 : endDate.getDate(),
  );
  while (cursor <= limit && points.length < 400) {
    const key = monthly
      ? `${cursor.getFullYear()}-${String(cursor.getMonth() + 1).padStart(2, "0")}`
      : dateKey(cursor);
    const amount = totals.get(key) || { sale: 0, purchase: 0 };
    points.push({
      label: monthly
        ? cursor.toLocaleDateString("en-IN", { month: "short", year: "2-digit" })
        : cursor.toLocaleDateString("en-IN", { day: "numeric", month: "short" }),
      ...amount,
    });
    if (monthly) cursor.setMonth(cursor.getMonth() + 1);
    else cursor.setDate(cursor.getDate() + 1);
  }
  return points;
}

function MetricCard({
  label,
  value,
  detail,
  icon: Icon,
  tone = "indigo",
}: {
  label: string;
  value: string | number;
  detail: string;
  icon: LucideIcon;
  tone?: "indigo" | "green" | "orange" | "rose" | "blue";
}) {
  const tones = {
    indigo: "bg-primary/10 text-primary ring-primary/15",
    green: "bg-emerald-500/10 text-emerald-600 ring-emerald-500/15",
    orange: "bg-amber-500/10 text-amber-600 ring-amber-500/15",
    rose: "bg-rose-500/10 text-rose-600 ring-rose-500/15",
    blue: "bg-sky-500/10 text-sky-600 ring-sky-500/15",
  };
  return (
    <div className="surface-card min-w-0 p-4 sm:p-5 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-xs font-semibold text-muted-foreground">{label}</p>
          <p className="mt-2 truncate text-xl font-bold tracking-tight text-foreground sm:text-2xl">
            {value}
          </p>
          <p className="mt-1 truncate text-[11px] text-muted-foreground">{detail}</p>
        </div>
        <span
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ring-1 ${tones[tone]}`}
        >
          <Icon className="h-[18px] w-[18px]" />
        </span>
      </div>
    </div>
  );
}

export default function Index() {
  const { parties, items, invoices, shopInfo, restricted } = useCurrentStore();
  const currentUserId = useAuthStore((s) => s.currentUserId);
  const users = useAuthStore((s) => s.users);
  const navigate = useNavigate();
  const [showSaleForm, setShowSaleForm] = useState(false);
  const [showPurchaseForm, setShowPurchaseForm] = useState(false);
  const [preset, setPreset] = useState<DatePreset>("month");
  const [customStart, setCustomStart] = useState(() =>
    dateKey(new Date(new Date().getFullYear(), new Date().getMonth(), 1)),
  );
  const [customEnd, setCustomEnd] = useState(() => dateKey(new Date()));

  const now = new Date();
  const today = dateKey(now);
  const monthStart = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`;
  const monthName = now.toLocaleDateString("en-IN", { month: "long" });
  const currentUser = users.find((user) => user.id === currentUserId);
  const range = makeDateRange(preset, customStart, customEnd, now);

  const rangeInvoices = useMemo(
    () => invoices.filter((invoice) => invoice.date >= range.start && invoice.date <= range.end),
    [invoices, range.start, range.end],
  );
  const sales = useMemo(
    () => rangeInvoices.filter((invoice) => invoice.type === "sale"),
    [rangeInvoices],
  );
  const purchases = useMemo(
    () => rangeInvoices.filter((invoice) => invoice.type === "purchase"),
    [rangeInvoices],
  );
  const rangeSales = sales.reduce((sum, invoice) => sum + invoice.totalAmount, 0);
  const rangePurchases = purchases.reduce((sum, invoice) => sum + invoice.totalAmount, 0);
  const lifetimeSales = invoices
    .filter((invoice) => invoice.type === "sale")
    .reduce((sum, invoice) => sum + invoice.totalAmount, 0);
  const todaySales = invoices
    .filter((invoice) => invoice.type === "sale" && invoice.date === today)
    .reduce((sum, invoice) => sum + invoice.totalAmount, 0);
  const monthSales = invoices
    .filter(
      (invoice) => invoice.type === "sale" && invoice.date >= monthStart && invoice.date <= today,
    )
    .reduce((sum, invoice) => sum + invoice.totalAmount, 0);
  const outstanding = invoices
    .filter((invoice) => invoice.type === "sale")
    .reduce(
      (sum, invoice) => sum + Math.max(0, invoice.totalAmount - invoicePaidAmount(invoice)),
      0,
    );
  const customerCount = parties.filter((party) => party.type === "customer").length;
  const supplierCount = parties.filter((party) => party.type === "supplier").length;
  const lowStockItems = items.filter((item) => item.stock <= 5).sort((a, b) => a.stock - b.stock);

  const chartData = useMemo(
    () => buildChartData(rangeInvoices, range.start, range.end),
    [rangeInvoices, range.start, range.end],
  );

  const topProducts = useMemo(() => {
    const totals = new Map<string, { name: string; qty: number; revenue: number }>();
    for (const invoice of sales) {
      for (const line of invoice.items) {
        const key = line.itemId || line.name.toLowerCase();
        const current = totals.get(key) || { name: line.name, qty: 0, revenue: 0 };
        current.qty += Number(line.qty) || 0;
        current.revenue += Number(line.amount) || 0;
        totals.set(key, current);
      }
    }
    return [...totals.values()].sort((a, b) => b.qty - a.qty).slice(0, 5);
  }, [sales]);

  const recentTransactions = useMemo(
    () =>
      [...rangeInvoices]
        .sort((a, b) => `${b.date}${b.createdAt}`.localeCompare(`${a.date}${a.createdAt}`))
        .slice(0, 6),
    [rangeInvoices],
  );

  const formatRangeLabel = () => {
    if (preset === "today") return "Today";
    if (preset === "week") return "This week";
    if (preset === "month") return "This month";
    if (preset === "year") return "This year";
    return `${new Date(`${range.start}T00:00:00`).toLocaleDateString("en-IN", { day: "numeric", month: "short" })} – ${new Date(`${range.end}T00:00:00`).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}`;
  };

  return (
    <Layout>
      <SaleFormDialog open={showSaleForm} onClose={() => setShowSaleForm(false)} />
      <PurchaseFormDialog open={showPurchaseForm} onClose={() => setShowPurchaseForm(false)} />

      <div className="mx-auto flex w-full max-w-[1500px] flex-col gap-5 pb-5">
        <section className="relative overflow-hidden rounded-2xl border border-border/70 bg-gradient-to-br from-card via-card to-primary/[0.06] p-5 shadow-sm sm:p-6">
          <div className="pointer-events-none absolute -right-10 -top-20 h-56 w-56 rounded-full bg-primary/15 blur-3xl" />
          <div className="relative flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-primary">
                Business overview
              </p>
              <h1 className="mt-1 truncate text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl">
                Welcome back, {currentUser?.name?.split(" ")[0] || "there"}
              </h1>
              <p className="mt-1 text-sm text-muted-foreground">
                {shopInfo.name || currentUser?.businessName || "Your business"}{" "}
                <span className="mx-1.5 text-border">•</span>{" "}
                {now.toLocaleDateString("en-IN", {
                  weekday: "long",
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => (restricted ? navigate("/plans") : setShowSaleForm(true))}
                className="brand-gradient inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-md transition hover:opacity-90 active:scale-[0.98]"
              >
                <Plus className="h-4 w-4" /> New sale
              </button>
              <button
                disabled={restricted}
                onClick={() => setShowPurchaseForm(true)}
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-semibold text-foreground shadow-sm transition hover:border-primary/40 hover:text-primary disabled:cursor-not-allowed disabled:opacity-50"
              >
                <ShoppingCart className="h-4 w-4" /> New purchase
              </button>
            </div>
          </div>
        </section>

        <section className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-sm font-bold text-foreground">Performance snapshot</h2>
            <p className="text-xs text-muted-foreground">
              Showing business activity for {formatRangeLabel().toLowerCase()}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1 rounded-xl border border-border bg-card p-1 shadow-sm">
            {(["today", "week", "month", "year", "custom"] as DatePreset[]).map((value) => (
              <button
                key={value}
                onClick={() => setPreset(value)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold capitalize transition ${preset === value ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}
              >
                {value === "week"
                  ? "This week"
                  : value === "month"
                    ? "This month"
                    : value === "year"
                      ? "This year"
                      : value}
              </button>
            ))}
          </div>
        </section>

        {preset === "custom" && (
          <div className="flex flex-wrap items-end gap-3 rounded-xl border border-border bg-card p-3">
            <label className="grid gap-1 text-xs font-medium text-muted-foreground">
              From
              <input
                type="date"
                value={customStart}
                max={customEnd}
                onChange={(event) => setCustomStart(event.target.value)}
                className="h-9 rounded-lg border border-input bg-background px-3 text-sm text-foreground"
              />
            </label>
            <label className="grid gap-1 text-xs font-medium text-muted-foreground">
              To
              <input
                type="date"
                value={customEnd}
                min={customStart}
                max={today}
                onChange={(event) => setCustomEnd(event.target.value)}
                className="h-9 rounded-lg border border-input bg-background px-3 text-sm text-foreground"
              />
            </label>
            <span className="pb-2 text-xs text-muted-foreground">Custom date range</span>
          </div>
        )}

        <section className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard
            label="Sales revenue"
            value={compactCurrency(rangeSales)}
            detail={`${sales.length} sales invoice${sales.length === 1 ? "" : "s"} in range`}
            icon={TrendingUp}
            tone="green"
          />
          <MetricCard
            label="Today's sales"
            value={compactCurrency(todaySales)}
            detail={currency(todaySales)}
            icon={CircleDollarSign}
            tone="indigo"
          />
          <MetricCard
            label="Monthly revenue"
            value={compactCurrency(monthSales)}
            detail={`${monthName} ${now.getFullYear()}`}
            icon={CalendarDays}
            tone="blue"
          />
          <MetricCard
            label="Pending payments"
            value={compactCurrency(outstanding)}
            detail="Outstanding on sales invoices"
            icon={CreditCard}
            tone="orange"
          />
        </section>

        <section className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard
            label="Purchases"
            value={compactCurrency(rangePurchases)}
            detail={`${purchases.length} purchase invoice${purchases.length === 1 ? "" : "s"} in range`}
            icon={ShoppingBag}
            tone="rose"
          />
          <MetricCard
            label="Sales less purchases"
            value={compactCurrency(rangeSales - rangePurchases)}
            detail="Trading difference, not net profit"
            icon={BarChart3}
            tone="indigo"
          />
          <MetricCard
            label="Customers & suppliers"
            value={`${customerCount} / ${supplierCount}`}
            detail={`${parties.length} total parties`}
            icon={Users}
            tone="blue"
          />
          <MetricCard
            label="Products in catalogue"
            value={items.length.toLocaleString("en-IN")}
            detail={`${lowStockItems.length} items at or below 5 in stock`}
            icon={Boxes}
            tone={lowStockItems.length ? "orange" : "green"}
          />
        </section>

        <section className="grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1.7fr)_minmax(300px,1fr)]">
          <div className="surface-card min-w-0 p-4 sm:p-5">
            <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-foreground">Sales & purchases</h3>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {formatRangeLabel()} · {chartData.length > 62 ? "Monthly view" : "Daily view"}
                </p>
              </div>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-primary" /> Sales
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-emerald-500" /> Purchases
                </span>
              </div>
            </div>
            <div className="h-[260px] w-full">
              {chartData.length ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                    <defs>
                      <linearGradient id="dashboardSales" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="hsl(var(--chart-1))" stopOpacity={0.28} />
                        <stop offset="100%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="dashboardPurchases" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#10b981" stopOpacity={0.2} />
                        <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid
                      stroke="hsl(var(--border))"
                      strokeDasharray="3 3"
                      vertical={false}
                    />
                    <XAxis
                      dataKey="label"
                      tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                      tickLine={false}
                      axisLine={false}
                      minTickGap={18}
                    />
                    <YAxis
                      tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={compactCurrency}
                      width={56}
                    />
                    <Tooltip
                      formatter={(value, name) => [
                        currency(Number(value ?? 0)),
                        name === "sale" ? "Sales" : "Purchases",
                      ]}
                      contentStyle={{
                        borderRadius: 12,
                        border: "1px solid hsl(var(--border))",
                        background: "hsl(var(--card))",
                        color: "hsl(var(--foreground))",
                        fontSize: 12,
                        boxShadow: "var(--shadow-elevated)",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="sale"
                      name="Sales"
                      stroke="hsl(var(--chart-1))"
                      strokeWidth={2.5}
                      fill="url(#dashboardSales)"
                      activeDot={{ r: 4 }}
                    />
                    <Area
                      type="monotone"
                      dataKey="purchase"
                      name="Purchases"
                      stroke="#10b981"
                      strokeWidth={2}
                      fill="url(#dashboardPurchases)"
                      activeDot={{ r: 4 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex h-full flex-col items-center justify-center text-center">
                  <BarChart3 className="mb-2 h-8 w-8 text-muted-foreground/40" />
                  <p className="text-sm font-medium text-foreground">
                    No transactions in this period
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Create a sale or purchase to see your trend.
                  </p>
                </div>
              )}
            </div>
            <div className="mt-3 flex flex-wrap justify-between gap-2 border-t border-border/70 pt-3 text-xs text-muted-foreground">
              <span>
                Lifetime sales:{" "}
                <strong className="font-semibold text-foreground">{currency(lifetimeSales)}</strong>
              </span>
              <span>
                Filtered purchase total:{" "}
                <strong className="font-semibold text-foreground">
                  {currency(rangePurchases)}
                </strong>
              </span>
            </div>
          </div>

          <div className="surface-card min-w-0 p-4 sm:p-5">
            <div className="mb-4 flex items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-bold text-foreground">Stock alerts</h3>
                <p className="mt-0.5 text-xs text-muted-foreground">Products that need attention</p>
              </div>
              <button
                onClick={() => navigate("/items")}
                className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
              >
                Manage stock <ArrowRight className="h-3 w-3" />
              </button>
            </div>
            {lowStockItems.length ? (
              <div className="space-y-2">
                {lowStockItems.slice(0, 6).map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between gap-3 rounded-xl border border-border/70 bg-background/60 px-3 py-2.5"
                  >
                    <div className="flex min-w-0 items-center gap-2.5">
                      <span
                        className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${item.stock <= 0 ? "bg-rose-500/10 text-rose-600" : "bg-amber-500/10 text-amber-600"}`}
                      >
                        <Package className="h-4 w-4" />
                      </span>
                      <div className="min-w-0">
                        <p className="truncate text-xs font-semibold text-foreground">
                          {item.name}
                        </p>
                        <p className="text-[10px] text-muted-foreground">
                          {item.category || "Uncategorised"}
                        </p>
                      </div>
                    </div>
                    <span
                      className={`shrink-0 rounded-full px-2 py-1 text-[10px] font-bold ${item.stock <= 0 ? "bg-rose-500/10 text-rose-600" : "bg-amber-500/10 text-amber-700"}`}
                    >
                      {item.stock <= 0 ? "Out of stock" : `${item.stock} left`}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex h-[210px] flex-col items-center justify-center text-center">
                <CheckCircle2 className="mb-2 h-8 w-8 text-emerald-500" />
                <p className="text-sm font-medium text-foreground">Stock looks good</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  No products are at or below 5 units.
                </p>
              </div>
            )}
          </div>
        </section>

        <section className="grid grid-cols-1 gap-4 xl:grid-cols-2">
          <div className="surface-card min-w-0 overflow-hidden">
            <div className="flex items-center justify-between border-b border-border/70 px-4 py-3.5 sm:px-5">
              <div>
                <h3 className="text-sm font-bold text-foreground">Recent transactions</h3>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Latest bills in the selected period
                </p>
              </div>
              <button
                onClick={() => navigate("/sales")}
                className="text-xs font-semibold text-primary hover:underline"
              >
                View all
              </button>
            </div>
            {recentTransactions.length ? (
              <div className="divide-y divide-border/60">
                {recentTransactions.map((invoice) => (
                  <div
                    key={invoice.id}
                    className="flex items-center justify-between gap-3 px-4 py-3 sm:px-5"
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <span
                        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${invoice.type === "sale" ? "bg-emerald-500/10 text-emerald-600" : "bg-rose-500/10 text-rose-600"}`}
                      >
                        {invoice.type === "sale" ? (
                          <ArrowUpRight className="h-4 w-4" />
                        ) : (
                          <ArrowDownLeft className="h-4 w-4" />
                        )}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate text-xs font-semibold text-foreground">
                          {invoice.partyName || "Walk-in customer"}
                        </p>
                        <p className="mt-0.5 truncate text-[10px] text-muted-foreground">
                          {invoice.invoiceNumber} ·{" "}
                          {new Date(`${invoice.date}T00:00:00`).toLocaleDateString("en-IN", {
                            day: "numeric",
                            month: "short",
                            year: "numeric",
                          })}
                        </p>
                      </div>
                    </div>
                    <div className="shrink-0 text-right">
                      <p
                        className={`text-xs font-bold ${invoice.type === "sale" ? "text-emerald-600" : "text-rose-600"}`}
                      >
                        {invoice.type === "sale" ? "+" : "−"}
                        {currency(invoice.totalAmount)}
                      </p>
                      <p className="mt-0.5 text-[10px] capitalize text-muted-foreground">
                        {invoice.type}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="px-5 py-10 text-center text-xs text-muted-foreground">
                No transactions for this date range.
              </div>
            )}
          </div>

          <div className="surface-card min-w-0 overflow-hidden">
            <div className="flex items-center justify-between border-b border-border/70 px-4 py-3.5 sm:px-5">
              <div>
                <h3 className="text-sm font-bold text-foreground">Top-selling products</h3>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Ranked by units sold in this period
                </p>
              </div>
              <button
                onClick={() => navigate("/reports")}
                className="text-xs font-semibold text-primary hover:underline"
              >
                Reports
              </button>
            </div>
            {topProducts.length ? (
              <div className="space-y-4 p-4 sm:p-5">
                {topProducts.map((product, index) => {
                  const maxQty = topProducts[0]?.qty || 1;
                  return (
                    <div key={product.name}>
                      <div className="mb-1.5 flex items-center justify-between gap-3">
                        <div className="flex min-w-0 items-center gap-2">
                          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-primary/10 text-[10px] font-bold text-primary">
                            {index + 1}
                          </span>
                          <span className="truncate text-xs font-semibold text-foreground">
                            {product.name}
                          </span>
                        </div>
                        <span className="shrink-0 text-xs font-bold text-foreground">
                          {product.qty.toLocaleString("en-IN")} sold
                        </span>
                      </div>
                      <div className="ml-8 h-1.5 overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-primary"
                          style={{ width: `${Math.max(4, (product.qty / maxQty) * 100)}%` }}
                        />
                      </div>
                      <p className="ml-8 mt-1 text-[10px] text-muted-foreground">
                        Revenue {currency(product.revenue)}
                      </p>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="flex h-[210px] flex-col items-center justify-center text-center">
                <ClipboardList className="mb-2 h-8 w-8 text-muted-foreground/40" />
                <p className="text-sm font-medium text-foreground">No product sales yet</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Product rankings appear after you create sales invoices.
                </p>
              </div>
            )}
          </div>
        </section>

        <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {[
            {
              label: "Create sale",
              icon: Plus,
              action: () => (restricted ? navigate("/plans") : setShowSaleForm(true)),
            },
            {
              label: "Add purchase",
              icon: ShoppingCart,
              action: () => (restricted ? navigate("/plans") : setShowPurchaseForm(true)),
            },
            { label: "Manage parties", icon: Users, action: () => navigate("/parties") },
            { label: "View reports", icon: FileText, action: () => navigate("/reports") },
          ].map(({ label, icon: Icon, action }) => (
            <button
              key={label}
              onClick={action}
              className="flex items-center justify-between gap-2 rounded-xl border border-border bg-card px-3 py-3 text-left text-xs font-semibold text-foreground shadow-sm transition hover:border-primary/40 hover:bg-primary/[0.03]"
            >
              <span className="flex items-center gap-2">
                <Icon className="h-4 w-4 text-primary" />
                {label}
              </span>
              <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />
            </button>
          ))}
        </section>

        <p className="px-1 text-[10px] leading-relaxed text-muted-foreground">
          “Sales less purchases” is a trading difference only. It is not net profit because
          operating expenses, opening stock, and closing-stock valuation are not included. Pending
          payments are calculated from the received amount saved on each sales invoice.
        </p>
      </div>
    </Layout>
  );
}
