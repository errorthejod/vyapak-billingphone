import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import EditBillPage from "@/pages/EditBill";

export const Route = createFileRoute("/edit-bill")({
  head: () => ({
    meta: [
      { title: "Bill Editor — Vyapak Billing" },
      { name: "description", content: "Edit and customise any saved bill — customer, items, rates, GST, payment, terms and design — with a live print preview." },
      { property: "og:title", content: "Bill Editor — Vyapak Billing" },
      { property: "og:description", content: "Edit and customise any saved bill with a live print preview." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <EditBillPage />
    </ProtectedRoute>
  );
}
