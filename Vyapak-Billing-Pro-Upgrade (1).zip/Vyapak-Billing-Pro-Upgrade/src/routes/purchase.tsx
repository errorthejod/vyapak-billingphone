import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import PurchasePage from "@/pages/Purchase";

export const Route = createFileRoute("/purchase")({
  head: () => ({
    meta: [
      { title: "Purchase & Expense — Vyapak Billing" },
      { name: "description", content: "Record purchases and expenses from suppliers and keep stock up to date." },
      { property: "og:title", content: "Purchase & Expense — Vyapak Billing" },
      { property: "og:description", content: "Record purchases and expenses from suppliers and keep stock up to date." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <PurchasePage />
    </ProtectedRoute>
  );
}
