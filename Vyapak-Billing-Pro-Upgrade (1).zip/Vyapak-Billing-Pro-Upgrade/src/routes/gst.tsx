import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import GstPage from "@/pages/Gst";

export const Route = createFileRoute("/gst")({
  head: () => ({
    meta: [
      { title: "GST Report — Vyapak Billing" },
      { name: "description", content: "Track GST payable, output GST and input tax credit with a full CGST, SGST and IGST breakup for every bill." },
      { property: "og:title", content: "GST Report — Vyapak Billing" },
      { property: "og:description", content: "GST payable, output GST and ITC with a per-bill CGST, SGST and IGST breakup." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <GstPage />
    </ProtectedRoute>
  );
}
