import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import CashBankPage from "@/pages/CashBank";

export const Route = createFileRoute("/cash-bank")({
  head: () => ({
    meta: [
      { title: "Cash & Bank — Vyapak Billing" },
      { name: "description", content: "See cash and bank balances driven by your sales and purchase entries." },
      { property: "og:title", content: "Cash & Bank — Vyapak Billing" },
      { property: "og:description", content: "See cash and bank balances driven by your sales and purchase entries." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <CashBankPage />
    </ProtectedRoute>
  );
}
