import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { proofUrl } from "@/lib/bb-plans.server";
import { getAdminSessionClaims, getSessionClaims } from "@/lib/bb-session.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/api/payments/$id/proof")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        try {
          const { data, error } = await supabaseAdmin
            .from("bb_payment_requests")
            .select("user_id")
            .eq("id", params.id)
            .maybeSingle();
          if (error) throw error;
          if (!data) return json({ error: "Payment request not found" }, 404);
          const session = await getSessionClaims(request);
          const isOwner =
            !!session &&
            session.accountType === "business" &&
            session.id === (data as { user_id: string }).user_id;
          const isAdmin = !!(await getAdminSessionClaims(request));
          if (!isOwner && !isAdmin) return json({ error: "Authorization required" }, 403);
          const url = await proofUrl(params.id);
          if (!url) return json({ error: "No proof attached" }, 404);
          return json({ url });
        } catch (error) {
          return json(
            { error: error instanceof Error ? error.message : "Failed to load proof" },
            500,
          );
        }
      },
    },
  },
});
