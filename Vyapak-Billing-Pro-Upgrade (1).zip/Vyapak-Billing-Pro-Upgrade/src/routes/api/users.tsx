import { createFileRoute } from "@tanstack/react-router";
import { getAdminSessionClaims } from "@/lib/bb-session.server";
import { json, listUsers, createUser, ensureDefaults } from "@/lib/bb-users.server";

export const Route = createFileRoute("/api/users")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          await ensureDefaults();
          return json({ users: await listUsers() });
        } catch (error) {
          const message = error instanceof Error ? error.message : "Unknown database error";
          console.error("[API GET /api/users]", error);
          return json({ error: `Failed to fetch users: ${message}` }, 500);
        }
      },
      POST: async ({ request }) => {
        try {
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          await ensureDefaults();
          const { name, businessName, pin } = (await request.json()) as {
            name?: string;
            businessName?: string;
            pin?: string;
          };
          if (!name?.trim() || !businessName?.trim() || !pin?.trim())
            return json(
              { error: "Customer name, business name, and password/PIN are required." },
              400,
            );
          const user = await createUser(name, businessName, pin);
          // Only the authenticated admin receives this newly generated password, once.
          return json({ user: { ...user, pin } });
        } catch (error) {
          const message = error instanceof Error ? error.message : "Unknown database error";
          console.error("[API POST /api/users] Account creation failed:", error);
          return json({ error: `Account creation failed: ${message}` }, 500);
        }
      },
    },
  },
});
