import { createFileRoute } from "@tanstack/react-router";
import { json, updateUser, deleteUser } from "@/lib/bb-users.server";
import { getAdminSessionClaims } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/users/$id")({
  server: {
    handlers: {
      PUT: async ({ request, params }) => {
        try {
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          const updates = (await request.json()) as Partial<{
            pin: string;
            isActive: boolean;
            name: string;
            businessName: string;
          }>;
          const user = await updateUser(params.id, updates);
          if (!user) return json({ error: "User not found" }, 404);
          return json({ user });
        } catch {
          return json({ error: "Failed to update user" }, 500);
        }
      },
      DELETE: async ({ request, params }) => {
        try {
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          await deleteUser(params.id);
          return json({ ok: true });
        } catch {
          return json({ error: "Failed to delete user" }, 500);
        }
      },
    },
  },
});
