import { createFileRoute } from "@tanstack/react-router";
import { readLocalStorageFile, verifyLocalStorageSignature } from "@/integrations/local-db.server";

export const Route = createFileRoute("/api/local-storage")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        if ((process.env.LOCAL_DB || "").toLowerCase() !== "true") {
          return new Response("Not found", { status: 404 });
        }
        const url = new URL(request.url);
        const bucket = url.searchParams.get("bucket") || "";
        const path = url.searchParams.get("path") || "";
        const expires = Number(url.searchParams.get("exp"));
        const signature = url.searchParams.get("sig") || "";
        // Only the payment-proof bucket is used by this app. Never serve arbitrary files.
        if (bucket !== "payment-proofs" || !path || !signature || !verifyLocalStorageSignature(bucket, path, expires, signature)) {
          return new Response("Invalid or expired file link", { status: 403 });
        }
        const file = readLocalStorageFile(bucket, path);
        if (!file) return new Response("File not found", { status: 404 });
        return new Response(new Uint8Array(file.bytes), {
          status: 200,
          headers: {
            "Content-Type": file.contentType,
            "Content-Length": String(file.bytes.byteLength),
            "Cache-Control": "private, no-store",
            "X-Content-Type-Options": "nosniff",
            "Content-Disposition": "inline",
          },
        });
      },
    },
  },
});
