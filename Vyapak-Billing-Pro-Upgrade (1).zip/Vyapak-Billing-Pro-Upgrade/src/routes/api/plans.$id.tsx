import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { updatePlan, deletePlan } from "@/lib/bb-plans.server";
import { getAdminSessionClaims } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/plans/$id")({
  server: {
    handlers: {
      PUT: async ({ request, params }) => {
        try {
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          const body = (await request.json()) as Record<string, unknown>;
          const plan = await updatePlan(params.id, body);
          if (!plan) return json({ error: "Plan not found" }, 404);
          return json({ plan });
        } catch {
          return json({ error: "Failed to update plan" }, 500);
        }
      },
      DELETE: async ({ request, params }) => {
        try {
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          await deletePlan(params.id);
          return json({ ok: true });
        } catch {
          return json({ error: "Failed to delete plan" }, 500);
        }
      },
    },
  },
});
