import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { getAdminSessionClaims } from "@/lib/bb-session.server";
import { listCaAccounts } from "@/lib/bb-ca.server";

export const Route = createFileRoute("/api/ca-accounts")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          return json({ accounts: await listCaAccounts() });
        } catch (error) {
          return json(
            { error: error instanceof Error ? error.message : "Could not list CA accounts" },
            500,
          );
        }
      },
    },
  },
});
