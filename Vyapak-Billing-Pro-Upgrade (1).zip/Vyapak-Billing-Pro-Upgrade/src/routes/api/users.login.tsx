import { createFileRoute } from "@tanstack/react-router";
import { json, loginUser, ensureDefaults } from "@/lib/bb-users.server";
import { createSessionToken } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/users/login")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          await ensureDefaults();
          const body = (await request.json()) as {
            identifier?: string;
            password?: string;
            name?: string;
            pin?: string;
          };
          const identifier = body.identifier ?? body.name;
          const password = body.password ?? body.pin;
          if (!identifier || !password)
            return json({ error: "Email/mobile and password are required" }, 400);
          const user = await loginUser(identifier, password);
          if (!user) return json({ error: "Invalid credentials" }, 401);
          const sessionToken = await createSessionToken(user.id, user.accountType === "ca" ? "ca" : "business");
          return json({ user, sessionToken });
        } catch (error) {
          const message = error instanceof Error ? error.message : "Login failed";
          const status = /CA registration|Admin approval/i.test(message) ? 403 : 500;
          return json({ error: message }, status);
        }
      },
    },
  },
});
