import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { searchBusinessesForCa } from "@/lib/bb-ca.server";
import { getSessionClaims } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/ca-businesses")({
  server: { handlers: { GET: async ({ request }) => {
    try {
      const session = await getSessionClaims(request);
      if (!session || session.accountType !== "ca") return json({ error: "CA login required" }, 401);
      const url = new URL(request.url);
      const caId = url.searchParams.get("caId") || "";
      const q = url.searchParams.get("q") || "";
      if (!caId || caId !== session.id) return json({ error: "You can only search using your own CA account" }, 403);
      return json({ businesses: await searchBusinessesForCa(session.id, q) });
    } catch (error) {
      return json({ error: error instanceof Error ? error.message : "Could not search businesses" }, 403);
    }
  } } },
});
