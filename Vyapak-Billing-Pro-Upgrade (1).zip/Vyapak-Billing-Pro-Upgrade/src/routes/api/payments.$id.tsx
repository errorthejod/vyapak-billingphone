import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { getAdminSessionClaims } from "@/lib/bb-session.server";
import { decidePayment, getAccount } from "@/lib/bb-plans.server";
import { notifyDecision } from "@/lib/bb-notify.server";

export const Route = createFileRoute("/api/payments/$id")({
  server: {
    handlers: {
      PUT: async ({ request, params }) => {
        try {
          const body = (await request.json()) as {
            status?: "approved" | "rejected";
            adminNote?: string;
          };
          if (body.status !== "approved" && body.status !== "rejected")
            return json({ error: "Invalid status" }, 400);
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);

          const payment = await decidePayment(params.id, body.status, body.adminNote);
          if (!payment) return json({ error: "Payment request not found" }, 404);
          const account = await getAccount(payment.userId);
          await notifyDecision({
            userEmail: payment.userEmail || account?.email || "",
            userName: payment.userName,
            planName: payment.planName,
            approved: body.status === "approved",
            note: body.adminNote ?? null,
            expiry: account?.planExpiry ?? null,
          });
          return json({ payment, account });
        } catch (error) {
          return json(
            { error: error instanceof Error ? error.message : "Failed to update payment request" },
            500,
          );
        }
      },
    },
  },
});
