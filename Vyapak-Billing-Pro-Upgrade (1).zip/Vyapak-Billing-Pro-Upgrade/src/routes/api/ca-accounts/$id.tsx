import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { getAdminSessionClaims } from "@/lib/bb-session.server";
import { decideCaAccount } from "@/lib/bb-ca.server";

export const Route = createFileRoute("/api/ca-accounts/$id")({
  server: {
    handlers: {
      PATCH: async ({ request, params }) => {
        try {
          const body = (await request.json()) as { status?: "approved" | "rejected" };
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          if (body.status !== "approved" && body.status !== "rejected")
            return json({ error: "Status must be approved or rejected" }, 400);
          return json({ account: await decideCaAccount(params.id, body.status) });
        } catch (error) {
          return json(
            { error: error instanceof Error ? error.message : "Could not update CA account" },
            400,
          );
        }
      },
    },
  },
});
