import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { getUserSettings, saveUserSettings } from "@/lib/bb-settings.server";
import { getAccount } from "@/lib/bb-plans.server";
import { getSessionClaims } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/settings/$userId")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        try {
          const session = await getSessionClaims(request);
          if (!session || session.accountType !== "business" || session.id !== params.userId) return json({ error: "Authentication required" }, 401);
          return json({ settings: await getUserSettings(params.userId) });
        } catch (error) {
          return json({ error: error instanceof Error ? error.message : "Failed to load settings" }, 500);
        }
      },
      PUT: async ({ request, params }) => {
        try {
          const session = await getSessionClaims(request);
          if (!session || session.accountType !== "business" || session.id !== params.userId) return json({ error: "Authentication required" }, 401);
          const body = (await request.json()) as { settings?: Record<string, unknown> };
          if (!body?.settings || typeof body.settings !== "object") return json({ error: "settings object required" }, 400);
          const account = await getAccount(params.userId);
          if (!account) return json({ error: "Account not found" }, 404);
          if (account.status !== "active") return json({ error: "Your plan is inactive. Renew your plan to unlock billing features.", status: account.status }, 403);
          await saveUserSettings(params.userId, body.settings);
          return json({ ok: true });
        } catch (error) {
          return json({ error: error instanceof Error ? error.message : "Failed to save settings" }, 500);
        }
      },
    },
  },
});
