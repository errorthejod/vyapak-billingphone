import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { signupCa } from "@/lib/bb-ca.server";

export const Route = createFileRoute("/api/ca-auth/signup")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const body = await request.json() as { name?: string; firmName?: string; email?: string; mobile?: string; password?: string; registrationNo?: string };
          const user = await signupCa({ name: body.name || "", firmName: body.firmName || "", email: body.email || "", mobile: body.mobile || "", password: body.password || "", registrationNo: body.registrationNo });
          return json({ user });
        } catch (error) {
          const message = error instanceof Error ? error.message : "CA registration failed";
          return json({ error: message }, message.includes("already exists") ? 409 : 400);
        }
      },
    },
  },
});
