import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { listPlans, createPlan } from "@/lib/bb-plans.server";
import { getAdminSessionClaims } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/plans")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const all = new URL(request.url).searchParams.get("all") === "1";
          if (all && !(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          return json({ plans: await listPlans(all) });
        } catch {
          return json({ error: "Failed to fetch plans" }, 500);
        }
      },
      POST: async ({ request }) => {
        try {
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          const body = (await request.json()) as Record<string, unknown>;
          return json({ plan: await createPlan(body) });
        } catch {
          return json({ error: "Failed to create plan" }, 500);
        }
      },
    },
  },
});
