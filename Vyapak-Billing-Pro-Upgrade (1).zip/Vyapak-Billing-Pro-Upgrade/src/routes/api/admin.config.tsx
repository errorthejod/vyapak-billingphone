import { timingSafeEqual } from "node:crypto";
import { createFileRoute } from "@tanstack/react-router";
import { json, getConfig, setAdminPassword, setPaymentDetails } from "@/lib/bb-users.server";
import { createAdminSessionToken, getAdminSessionClaims } from "@/lib/bb-session.server";

function passwordMatches(supplied: string, configured: string) {
  const a = Buffer.from(supplied);
  const b = Buffer.from(configured);
  return a.length === b.length && timingSafeEqual(a, b);
}

export const Route = createFileRoute("/api/admin/config")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const body = (await request.json()) as { password?: string };
          const password = typeof body.password === "string" ? body.password : "";
          if (!password || password.length > 256)
            return json({ error: "Invalid admin credentials" }, 401);
          const config = await getConfig();
          if (!passwordMatches(password, String(config.admin_password || "")))
            return json({ error: "Invalid admin credentials" }, 401);
          return json({ token: await createAdminSessionToken(), expiresIn: 4 * 60 * 60 });
        } catch (error) {
          console.error("[API POST /api/admin/config]", error);
          return json({ error: "Admin authentication is unavailable" }, 503);
        }
      },
      GET: async () => {
        try {
          const config = await getConfig();
          return json({
            paymentQrUrl: config.payment_qr_url || "",
            upiId: config.upi_id || "",
          });
        } catch {
          return json({ error: "Failed to fetch config" }, 500);
        }
      },
      PUT: async ({ request }) => {
        try {
          const body = (await request.json()) as {
            currentPassword?: string;
            newPassword?: string;
            paymentQrUrl?: string;
            upiId?: string;
          };
          if (!(await getAdminSessionClaims(request)))
            return json({ error: "Admin authentication required" }, 403);
          const config = await getConfig();
          if (body.newPassword !== undefined) {
            if (
              typeof body.currentPassword !== "string" ||
              body.currentPassword !== config.admin_password
            )
              return json({ error: "Current admin password is incorrect" }, 403);
            if (body.newPassword.length < 10 || body.newPassword.length > 256)
              return json({ error: "New admin password must be at least 10 characters" }, 400);
            await setAdminPassword(body.newPassword);
          }
          if (body.paymentQrUrl !== undefined || body.upiId !== undefined) {
            await setPaymentDetails({
              ...(body.paymentQrUrl !== undefined ? { paymentQrUrl: body.paymentQrUrl } : {}),
              ...(body.upiId !== undefined ? { upiId: body.upiId } : {}),
            });
          }
          return json({ ok: true });
        } catch {
          return json({ error: "Failed to update config" }, 500);
        }
      },
    },
  },
});
