import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { listCaAccessRequests, sendCaAccessRequest } from "@/lib/bb-ca.server";
import { getSessionClaims } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/ca-requests")({
  server: { handlers: {
    GET: async ({ request }) => {
      try {
        const session = await getSessionClaims(request);
        if (!session) return json({ error: "Login required" }, 401);
        const url = new URL(request.url);
        const caId = url.searchParams.get("caId") || undefined;
        const businessId = url.searchParams.get("businessId") || undefined;
        if (caId && (session.accountType !== "ca" || caId !== session.id)) return json({ error: "You can only view your own CA requests" }, 403);
        if (businessId && (session.accountType !== "business" || businessId !== session.id)) return json({ error: "You can only view requests for your own business" }, 403);
        if (!!caId === !!businessId) return json({ error: "Specify either your CA ID or your business ID" }, 400);
        if (!caId && session.accountType !== "business") return json({ error: "Invalid account type for business requests" }, 403);
        if (!businessId && session.accountType !== "ca") return json({ error: "Invalid account type for CA requests" }, 403);
        return json({ requests: await listCaAccessRequests({ caId, businessId }) });
      } catch (error) {
        return json({ error: error instanceof Error ? error.message : "Could not fetch access requests" }, 400);
      }
    },
    POST: async ({ request }) => {
      try {
        const session = await getSessionClaims(request);
        if (!session || session.accountType !== "ca") return json({ error: "CA login required" }, 401);
        const body = await request.json() as { caId?: string; businessId?: string };
        if (!body.caId || !body.businessId) return json({ error: "CA and business are required" }, 400);
        if (body.caId !== session.id) return json({ error: "You can only send requests from your own CA account" }, 403);
        return json({ request: await sendCaAccessRequest(session.id, body.businessId) });
      } catch (error) {
        return json({ error: error instanceof Error ? error.message : "Could not send access request" }, 400);
      }
    },
  } },
});
