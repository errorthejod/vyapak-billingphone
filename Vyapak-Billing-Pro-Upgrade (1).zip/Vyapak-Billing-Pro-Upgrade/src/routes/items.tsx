import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import ItemsPage from "@/pages/Items";

export const Route = createFileRoute("/items")({
  head: () => ({
    meta: [
      { title: "Stock & Items — Vyapak Billing" },
      { name: "description", content: "Manage your item catalogue, pricing, GST rates and live stock levels." },
      { property: "og:title", content: "Stock & Items — Vyapak Billing" },
      { property: "og:description", content: "Manage your item catalogue, pricing, GST rates and live stock levels." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <ItemsPage />
    </ProtectedRoute>
  );
}
