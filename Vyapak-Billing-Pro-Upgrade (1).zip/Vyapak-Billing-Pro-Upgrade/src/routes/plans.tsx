import { createFileRoute } from "@tanstack/react-router";
import Layout from "@/components/Layout";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import PlansPage from "@/pages/Plans";

export const Route = createFileRoute("/plans")({
  head: () => ({
    meta: [
      { title: "Plans & Pricing — Vyapak Billing" },
      { name: "description", content: "Choose a 1 year or 2 year Vyapak Billing plan, pay by UPI and submit your payment proof." },
      { property: "og:title", content: "Plans & Pricing — Vyapak Billing" },
      { property: "og:description", content: "Choose a 1 year or 2 year Vyapak Billing plan, pay by UPI and submit your payment proof." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute allowRestricted>
      <Layout>
        <PlansPage />
      </Layout>
    </ProtectedRoute>
  );
}
