import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import CreditPage from "@/pages/Credit";

export const Route = createFileRoute("/credit")({
  head: () => ({
    meta: [
      { title: "Credit — Vyapak Billing" },
      { name: "description", content: "Track credit left on every bill and see the total outstanding credit across all bills." },
      { property: "og:title", content: "Credit — Vyapak Billing" },
      { property: "og:description", content: "Track credit left on every bill and see the total outstanding credit across all bills." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <CreditPage />
    </ProtectedRoute>
  );
}
