import { createFileRoute } from "@tanstack/react-router";
import Layout from "@/components/Layout";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import AccountPage from "@/pages/Account";

export const Route = createFileRoute("/account")({
  head: () => ({
    meta: [
      { title: "My Profile — Vyapak Billing" },
      { name: "description", content: "View your Vyapak Billing account details, notification email and current plan status." },
      { property: "og:title", content: "My Profile — Vyapak Billing" },
      { property: "og:description", content: "View your Vyapak Billing account details, notification email and current plan status." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute allowRestricted>
      <Layout>
        <AccountPage />
      </Layout>
    </ProtectedRoute>
  );
}
