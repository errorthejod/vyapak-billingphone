console.log("Local database setup was replaced by Supabase mode in this package. Run start-local.bat to check Supabase configuration.");
process.exit(1);
