import "dotenv/config";

const localMode = (process.env.LOCAL_DB || "").toLowerCase() === "true";
const required = localMode ? ["APP_SESSION_SECRET"] : ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY", "APP_SESSION_SECRET"];
const missing = required.filter((key) => !(process.env[key] || "").trim());
if (missing.length) {
  console.error("Missing required .env value(s): " + missing.join(", "));
  if (!localMode && missing.includes("SUPABASE_SERVICE_ROLE_KEY")) {
    console.error("Create/rotate a Supabase Secret key in Project Settings → API Keys, then paste it into SUPABASE_SERVICE_ROLE_KEY in .env. Keep it server-only; never use a VITE_ prefix.");
  }
  process.exit(1);
}
if ((process.env.APP_SESSION_SECRET || "").trim().length < 24) {
  console.error("APP_SESSION_SECRET must be at least 24 characters long.");
  process.exit(1);
}
if (!localMode) {
  try { new URL(process.env.SUPABASE_URL); }
  catch { console.error("SUPABASE_URL must be a valid project URL."); process.exit(1); }
}
console.log(localMode
  ? "Environment check passed. Local persistent database mode is enabled. No Supabase secret is required."
  : "Environment check passed. Supabase server settings are present (secret values hidden). Database migrations must also be applied.");
