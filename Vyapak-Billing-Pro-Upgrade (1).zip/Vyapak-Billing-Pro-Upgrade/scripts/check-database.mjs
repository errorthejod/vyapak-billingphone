import "dotenv/config";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { resolve } from "node:path";

if ((process.env.LOCAL_DB || "").toLowerCase() === "true") {
  const dataDir = resolve(process.cwd(), process.env.LOCAL_DB_DIR || "data");
  const dbFile = resolve(dataDir, "vyapak-local.json");
  mkdirSync(dataDir, { recursive: true });
  if (!existsSync(dbFile)) {
    const now = new Date().toISOString();
    const db = {
      bb_users: [],
      bb_admin_config: [{ id: 1, admin_password: process.env.ADMIN_PASSWORD || "delhi5932", next_user_num: 2, next_ca_num: 1, payment_qr_url: null, upi_id: null, bill_templates: [], bill_templates_initialized: false }],
      bb_user_settings: [], bb_plans: [
        { id: randomUUID(), name: "1 Year", price: 1600, duration_months: 12, features: ["Unlimited GST invoices", "Parties, stock & credit tracking", "Purchase & expense records", "Reports & backups", "Email support"], is_active: true, sort_order: 1, created_at: now, updated_at: now },
        { id: randomUUID(), name: "2 Years", price: 3000, duration_months: 24, features: ["Everything in 1 Year plan", "Save ₹200 vs yearly", "Priority support", "Free bill template updates"], is_active: true, sort_order: 2, created_at: now, updated_at: now }
      ],
      bb_payment_requests: [], bb_ca_access_requests: [], bb_user_ledger: [], bb_ca_access_audit: []
    };
    writeFileSync(dbFile, JSON.stringify(db, null, 2), "utf8");
  } else {
    const parsed = JSON.parse(readFileSync(dbFile, "utf8"));
    for (const table of ["bb_users", "bb_admin_config", "bb_user_settings", "bb_plans", "bb_payment_requests", "bb_ca_access_requests", "bb_user_ledger", "bb_ca_access_audit"]) {
      if (!Array.isArray(parsed[table])) throw new Error(`Local database is missing table array ${table}. Back up data/vyapak-local.json and restart to recreate, or repair the file manually.`);
    }
  }
  console.log(`Local database ready: ${dbFile}`);
  process.exit(0);
}

const url = (process.env.SUPABASE_URL || "").replace(/\/$/, "");
const key = (process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
if (!url || !key) {
  console.error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in .env.");
  process.exit(1);
}
const checks = [
  ["bb_admin_config", "id,next_user_num,next_ca_num,bill_templates,bill_templates_initialized"],
  ["bb_users", "id,name,business_name,pin,email,mobile,password_hash,is_active,is_trial,trial_start,trial_end,trial_used,account_type,ca_status"],
];
let failed = false;
for (const [table, columns] of checks) {
  const endpoint = `${url}/rest/v1/${table}?select=${encodeURIComponent(columns)}&limit=1`;
  try {
    const response = await fetch(endpoint, { headers: { apikey: key, Accept: "application/json" } });
    if (!response.ok) {
      const detail = (await response.text()).slice(0, 700);
      console.error(`FAIL ${table}: HTTP ${response.status}: ${detail}`); failed = true;
    } else console.log(`OK   ${table}: required columns are available`);
  } catch (error) { console.error(`FAIL ${table}: ${error instanceof Error ? error.message : String(error)}`); failed = true; }
}
if (failed) {
  console.error("\nRemote Supabase database setup is incomplete. Run supabase/FIX_ACCOUNT_CREATION.sql in the Supabase SQL Editor.");
  process.exit(1);
}
console.log("Database preflight passed.");
