# Vyapak Billing — Self-Hosted Billing & Business Management

Vyapak Billing supports two storage modes: Supabase (recommended for production and multi-device use) and a local JSON database (single server instance). Keep your existing `.env` and `data/` folder when upgrading an existing installation. **Do not overwrite either one.** This source package intentionally excludes `.env`, `node_modules`, and local database files.

## Upgrade an existing installation

1. Back up your existing `.env`, Supabase database (or the complete `data/` folder in local mode), and uploaded payment-proof files.
2. Replace the source files with this upgraded source package. Preserve your current `.env` and `data/` folder.
3. Install dependencies with `npm install` (or `npm ci` when the lockfile matches your npm version).
4. Run `npm run build` and resolve any environment-specific build errors before deploying.
5. Restart the application using your existing process manager and environment configuration.

No destructive database migration is included in this upgrade. The account password-hash migration happens on successful login for legacy accounts; it retains the account and replaces a plaintext PIN with a PBKDF2 hash.

## Supabase mode

Set `LOCAL_DB=false`, `VITE_LOCAL_DB_MODE=false`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, and `APP_SESSION_SECRET` in the server `.env`. Apply the SQL in `supabase/INSTALL_ALL.sql` to the intended Supabase project if its schema is not already installed. Never put the service-role/Secret key in a `VITE_` variable or expose it to browser code. Rotate any service-role secret previously shared outside your private environment.

The provided `start-supabase.bat` prepares the configured Supabase environment, checks the database, and starts the development server on Windows. `start-local.bat` is retained for compatibility with the existing project package; use the Supabase-specific script when following the Supabase setup flow.

## Local JSON mode

For a single-instance laptop or VPS install, set `LOCAL_DB=true`, `VITE_LOCAL_DB_MODE=true`, and a random `APP_SESSION_SECRET` of at least 32 characters in `.env`. Then run `npm install` followed by `npm run dev`. Local records are stored in `data/vyapak-local.json`; uploaded payment proofs are stored under `data/storage/`. Back up the whole `data/` folder. Do not run multiple replicas against this JSON store; use Supabase/PostgreSQL for multi-instance deployments.

## Admin access and security

- Set a unique `ADMIN_PASSWORD` of at least 10 characters before exposing the app to a network.
- Admin login is verified on the server and creates a signed four-hour session. The configuration API does not return the admin password.
- Admin-created user passwords are shown only once at creation. Existing passwords cannot be retrieved; reset them instead.
- Legacy user PINs are upgraded to PBKDF2-SHA256 hashes after a successful login. New accounts and password resets store hashes, not plaintext PINs.
- Keep `.env` out of source control and ZIP uploads. Only `.env.example` belongs in a distributable archive.

## Email notifications

Email delivery requires a valid Resend API key and a verified sender address. Configure `RESEND_API_KEY`, `RESEND_FROM`, and optionally `RESEND_REPLY_TO` in `.env`. Notifications are not sent until valid credentials are configured.

## Development commands

```bash
npm install
npm run dev
npm run build
npm run preview
npm run lint
```

## Existing modules

The project retains its existing billing, sales, purchase, inventory, parties, credit, GST, cash/bank, reports, invoice templates, backup, account plans, CA access, and payment workflows. See `UPGRADE_NOTES.md` for this upgrade's changes and validation status.
