-- Store admin-managed global invoice templates. Template content is shared globally;
-- user-specific business/customer data is substituted only when rendering an invoice.
ALTER TABLE public.bb_admin_config
  ADD COLUMN IF NOT EXISTS bill_templates jsonb NOT NULL DEFAULT '[]'::jsonb;

ALTER TABLE public.bb_admin_config
  ADD COLUMN IF NOT EXISTS bill_templates_initialized boolean NOT NULL DEFAULT false;
