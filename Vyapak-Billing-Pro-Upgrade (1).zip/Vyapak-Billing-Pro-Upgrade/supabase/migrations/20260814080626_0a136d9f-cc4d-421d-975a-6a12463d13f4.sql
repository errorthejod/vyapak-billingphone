-- Idempotent duplicate of the plan/payment schema migration.
-- Safe after 20260814075125 has already created these objects.
CREATE TABLE IF NOT EXISTS public.bb_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price numeric NOT NULL DEFAULT 0,
  duration_months integer NOT NULL DEFAULT 12,
  features jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.bb_plans TO service_role;
ALTER TABLE public.bb_plans ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Service role only" ON public.bb_plans;
CREATE POLICY "Service role only" ON public.bb_plans FOR ALL TO service_role USING (true) WITH CHECK (true);
DROP TRIGGER IF EXISTS bb_plans_updated_at ON public.bb_plans;
CREATE TRIGGER bb_plans_updated_at BEFORE UPDATE ON public.bb_plans FOR EACH ROW EXECUTE FUNCTION public.bb_touch_updated_at();

CREATE TABLE IF NOT EXISTS public.bb_payment_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  user_name text NOT NULL DEFAULT '',
  user_email text NOT NULL DEFAULT '',
  plan_id uuid,
  plan_name text NOT NULL DEFAULT '',
  amount numeric NOT NULL DEFAULT 0,
  duration_months integer NOT NULL DEFAULT 12,
  utr text NOT NULL DEFAULT '',
  proof_path text,
  proof_name text,
  status text NOT NULL DEFAULT 'pending',
  admin_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.bb_payment_requests TO service_role;
ALTER TABLE public.bb_payment_requests ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Service role only" ON public.bb_payment_requests;
CREATE POLICY "Service role only" ON public.bb_payment_requests FOR ALL TO service_role USING (true) WITH CHECK (true);
DROP TRIGGER IF EXISTS bb_payment_requests_updated_at ON public.bb_payment_requests;
CREATE TRIGGER bb_payment_requests_updated_at BEFORE UPDATE ON public.bb_payment_requests FOR EACH ROW EXECUTE FUNCTION public.bb_touch_updated_at();
CREATE INDEX IF NOT EXISTS bb_payment_requests_user_idx ON public.bb_payment_requests (user_id, created_at DESC);

ALTER TABLE public.bb_users
  ADD COLUMN IF NOT EXISTS email text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS plan_id uuid,
  ADD COLUMN IF NOT EXISTS plan_name text,
  ADD COLUMN IF NOT EXISTS plan_price numeric,
  ADD COLUMN IF NOT EXISTS plan_start timestamptz,
  ADD COLUMN IF NOT EXISTS plan_expiry timestamptz;

ALTER TABLE public.bb_admin_config
  ADD COLUMN IF NOT EXISTS payment_qr_url text,
  ADD COLUMN IF NOT EXISTS upi_id text;

INSERT INTO public.bb_plans (name, price, duration_months, features, sort_order)
SELECT '1 Year', 1600, 12, '["Unlimited GST invoices","Parties, stock & credit tracking","Purchase & expense records","Reports & backups","Email support"]'::jsonb, 1
WHERE NOT EXISTS (SELECT 1 FROM public.bb_plans WHERE name = '1 Year');
INSERT INTO public.bb_plans (name, price, duration_months, features, sort_order)
SELECT '2 Years', 3000, 24, '["Everything in 1 Year plan","Save ₹200 vs yearly","Priority support","Free bill template updates"]'::jsonb, 2
WHERE NOT EXISTS (SELECT 1 FROM public.bb_plans WHERE name = '2 Years');
