CREATE TABLE public.bb_users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  business_name TEXT NOT NULL,
  pin TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT ALL ON public.bb_users TO service_role;
ALTER TABLE public.bb_users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service role only" ON public.bb_users FOR ALL TO service_role USING (true) WITH CHECK (true);

CREATE TABLE public.bb_admin_config (
  id INTEGER PRIMARY KEY DEFAULT 1,
  admin_password TEXT NOT NULL DEFAULT 'delhi5932',
  next_user_num INTEGER NOT NULL DEFAULT 2
);

GRANT ALL ON public.bb_admin_config TO service_role;
ALTER TABLE public.bb_admin_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service role only" ON public.bb_admin_config FOR ALL TO service_role USING (true) WITH CHECK (true);

INSERT INTO public.bb_admin_config (id, admin_password, next_user_num) VALUES (1, 'delhi5932', 2);

INSERT INTO public.bb_users (id, name, business_name, pin, is_active)
VALUES ('BB001', 'Demo User', 'Shuvidha Telecom Mobile and Electronics', '1234', true);