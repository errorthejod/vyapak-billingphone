-- ONE-TIME INSTALL/REPAIR SCRIPT FOR VYAPAK BILLING SUPABASE MODE
-- Safe to re-run; it does not drop existing account or billing data.

-- Vyapak Billing: idempotent database repair for login/signup/admin account creation.
-- Safe to run in Supabase SQL Editor on an existing project; does not delete user data.

-- Base users/config tables
CREATE TABLE IF NOT EXISTS public.bb_users (
  id text PRIMARY KEY,
  name text NOT NULL,
  business_name text NOT NULL,
  pin text NOT NULL DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS email text NOT NULL DEFAULT '';
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS mobile text;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS password_hash text;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS is_trial boolean NOT NULL DEFAULT false;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS trial_start timestamptz;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS trial_end timestamptz;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS trial_used boolean NOT NULL DEFAULT false;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS plan_id uuid;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS plan_name text;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS plan_price numeric;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS plan_start timestamptz;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS plan_expiry timestamptz;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS account_type text NOT NULL DEFAULT 'business';
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS ca_status text;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS ca_firm text;
ALTER TABLE public.bb_users ADD COLUMN IF NOT EXISTS ca_registration_no text;

CREATE TABLE IF NOT EXISTS public.bb_admin_config (
  id integer PRIMARY KEY DEFAULT 1,
  admin_password text NOT NULL DEFAULT 'delhi5932',
  next_user_num integer NOT NULL DEFAULT 2
);
ALTER TABLE public.bb_admin_config ADD COLUMN IF NOT EXISTS admin_password text NOT NULL DEFAULT 'delhi5932';
ALTER TABLE public.bb_admin_config ADD COLUMN IF NOT EXISTS next_user_num integer NOT NULL DEFAULT 2;
ALTER TABLE public.bb_admin_config ADD COLUMN IF NOT EXISTS payment_qr_url text;
ALTER TABLE public.bb_admin_config ADD COLUMN IF NOT EXISTS upi_id text;
ALTER TABLE public.bb_admin_config ADD COLUMN IF NOT EXISTS bill_templates jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.bb_admin_config ADD COLUMN IF NOT EXISTS bill_templates_initialized boolean NOT NULL DEFAULT false;
ALTER TABLE public.bb_admin_config ADD COLUMN IF NOT EXISTS next_ca_num integer NOT NULL DEFAULT 1;
INSERT INTO public.bb_admin_config (id, admin_password, next_user_num) VALUES (1, 'delhi5932', 2)
ON CONFLICT (id) DO NOTHING;

-- Supporting tables and timestamp trigger function
CREATE OR REPLACE FUNCTION public.bb_touch_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TABLE IF NOT EXISTS public.bb_user_settings (
  user_id text PRIMARY KEY,
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bb_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price numeric NOT NULL DEFAULT 0,
  duration_months integer NOT NULL DEFAULT 12,
  features jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bb_payment_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  user_name text NOT NULL DEFAULT '',
  user_email text NOT NULL DEFAULT '',
  plan_id uuid,
  plan_name text NOT NULL DEFAULT '',
  amount numeric NOT NULL DEFAULT 0,
  duration_months integer NOT NULL DEFAULT 12,
  utr text NOT NULL DEFAULT '',
  proof_path text,
  proof_name text,
  status text NOT NULL DEFAULT 'pending',
  admin_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bb_ca_access_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ca_id text NOT NULL REFERENCES public.bb_users(id) ON DELETE CASCADE,
  business_id text NOT NULL REFERENCES public.bb_users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','revoked')),
  permissions jsonb NOT NULL DEFAULT '["sales","purchases","expenses","gst_reports","invoice_history","financial_reports"]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (ca_id, business_id)
);

CREATE TABLE IF NOT EXISTS public.bb_user_ledger (
  user_id text PRIMARY KEY REFERENCES public.bb_users(id) ON DELETE CASCADE,
  ledger jsonb NOT NULL DEFAULT '{"parties":[],"items":[],"invoices":[],"deletedInvoices":[]}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bb_ca_access_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid,
  ca_id text NOT NULL REFERENCES public.bb_users(id) ON DELETE CASCADE,
  business_id text NOT NULL REFERENCES public.bb_users(id) ON DELETE CASCADE,
  actor_id text NOT NULL REFERENCES public.bb_users(id) ON DELETE CASCADE,
  action text NOT NULL CHECK (action IN ('requested','approved','rejected','revoked','viewed_data')),
  created_at timestamptz NOT NULL DEFAULT now(),
  details jsonb NOT NULL DEFAULT '{}'::jsonb
);

-- Ensure all API service-role operations can access the tables under RLS.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['bb_users','bb_admin_config','bb_user_settings','bb_plans','bb_payment_requests','bb_ca_access_requests','bb_user_ledger','bb_ca_access_audit'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('GRANT ALL ON TABLE public.%I TO service_role', t);
  END LOOP;
END $$;

-- Idempotently recreate service-role-only policies where missing.
DROP POLICY IF EXISTS "Service role only" ON public.bb_users;
CREATE POLICY "Service role only" ON public.bb_users FOR ALL TO service_role USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Service role only" ON public.bb_admin_config;
CREATE POLICY "Service role only" ON public.bb_admin_config FOR ALL TO service_role USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Service role only" ON public.bb_user_settings;
CREATE POLICY "Service role only" ON public.bb_user_settings FOR ALL TO service_role USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Service role only" ON public.bb_plans;
CREATE POLICY "Service role only" ON public.bb_plans FOR ALL TO service_role USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Service role only" ON public.bb_payment_requests;
CREATE POLICY "Service role only" ON public.bb_payment_requests FOR ALL TO service_role USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Service role only" ON public.bb_ca_access_requests;
CREATE POLICY "Service role only" ON public.bb_ca_access_requests FOR ALL TO service_role USING (true) WITH CHECK (true);

-- Update triggers are safe to rerun.
DROP TRIGGER IF EXISTS bb_user_settings_updated_at ON public.bb_user_settings;
CREATE TRIGGER bb_user_settings_updated_at BEFORE UPDATE ON public.bb_user_settings FOR EACH ROW EXECUTE FUNCTION public.bb_touch_updated_at();
DROP TRIGGER IF EXISTS bb_plans_updated_at ON public.bb_plans;
CREATE TRIGGER bb_plans_updated_at BEFORE UPDATE ON public.bb_plans FOR EACH ROW EXECUTE FUNCTION public.bb_touch_updated_at();
DROP TRIGGER IF EXISTS bb_payment_requests_updated_at ON public.bb_payment_requests;
CREATE TRIGGER bb_payment_requests_updated_at BEFORE UPDATE ON public.bb_payment_requests FOR EACH ROW EXECUTE FUNCTION public.bb_touch_updated_at();
DROP TRIGGER IF EXISTS bb_ca_access_requests_updated_at ON public.bb_ca_access_requests;
CREATE TRIGGER bb_ca_access_requests_updated_at BEFORE UPDATE ON public.bb_ca_access_requests FOR EACH ROW EXECUTE FUNCTION public.bb_touch_updated_at();

-- Useful indexes; skip unique index creation if historical duplicate contact data already exists.
CREATE INDEX IF NOT EXISTS bb_users_account_type_idx ON public.bb_users(account_type);
CREATE INDEX IF NOT EXISTS bb_payment_requests_user_idx ON public.bb_payment_requests(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS bb_ca_access_business_idx ON public.bb_ca_access_requests(business_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS bb_ca_access_ca_idx ON public.bb_ca_access_requests(ca_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS bb_ca_audit_business_idx ON public.bb_ca_access_audit(business_id, created_at DESC);
CREATE INDEX IF NOT EXISTS bb_ca_audit_ca_idx ON public.bb_ca_access_audit(ca_id, created_at DESC);
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.bb_users WHERE email IS NOT NULL AND email <> '' GROUP BY lower(email) HAVING count(*) > 1) THEN
    CREATE UNIQUE INDEX IF NOT EXISTS bb_users_email_unique ON public.bb_users (lower(email)) WHERE email IS NOT NULL AND email <> '';
  ELSE
    RAISE NOTICE 'Skipped unique email index because duplicate historical emails exist; resolve duplicates to enforce uniqueness at database level.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.bb_users WHERE mobile IS NOT NULL AND mobile <> '' GROUP BY mobile HAVING count(*) > 1) THEN
    CREATE UNIQUE INDEX IF NOT EXISTS bb_users_mobile_unique ON public.bb_users (mobile) WHERE mobile IS NOT NULL AND mobile <> '';
  ELSE
    RAISE NOTICE 'Skipped unique mobile index because duplicate historical mobiles exist; resolve duplicates to enforce uniqueness at database level.';
  END IF;
END $$;

-- Seed standard plans only if they are not already present.
INSERT INTO public.bb_plans (name, price, duration_months, features, sort_order)
SELECT '1 Year', 1600, 12, '["Unlimited GST invoices","Parties, stock & credit tracking","Purchase & expense records","Reports & backups","Email support"]'::jsonb, 1
WHERE NOT EXISTS (SELECT 1 FROM public.bb_plans WHERE name = '1 Year');
INSERT INTO public.bb_plans (name, price, duration_months, features, sort_order)
SELECT '2 Years', 3000, 24, '["Everything in 1 Year plan","Save ₹200 vs yearly","Priority support","Free bill template updates"]'::jsonb, 2
WHERE NOT EXISTS (SELECT 1 FROM public.bb_plans WHERE name = '2 Years');

-- Ensure ID counter is ahead of existing business IDs; do not overwrite existing accounts.
UPDATE public.bb_admin_config
SET next_user_num = GREATEST(
  COALESCE(next_user_num, 2),
  COALESCE((SELECT MAX((substring(id from 3))::integer) + 1 FROM public.bb_users WHERE id ~ '^BB[0-9]+$'), 2)
)
WHERE id = 1;

-- Add a demo account only when it doesn't already exist (no destructive overwrite).
INSERT INTO public.bb_users (id, name, business_name, pin, is_active, email)
VALUES ('BB001', 'Demo User', 'Shuvidha Telecom Mobile and Electronics', '1234', true, '')
ON CONFLICT (id) DO NOTHING;

NOTIFY pgrst, 'reload schema';
