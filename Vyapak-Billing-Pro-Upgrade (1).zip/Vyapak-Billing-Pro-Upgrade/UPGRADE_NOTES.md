# Vyapak Billing Pro — Upgrade Notes

## Included in this source upgrade

### Dashboard and user experience

- Reworked the home dashboard into responsive KPI cards with Today, This Week, This Month, This Year, and Custom Range filters.
- Added selected-range sales/purchase totals, today's sales, monthly sales, pending invoice amounts, customer/supplier/product counts, and a trading-difference metric.
- Added sales/purchase trend charts, top-selling products, recent transactions, and low-stock alerts.
- Added a persistent dark/light theme control in the application sidebar.
- Preserved the existing sale and purchase dialogs and existing route/navigation structure.

### Authentication and API security

- Admin credentials are now checked by the server; the configuration API no longer returns the admin password.
- Admin login issues a signed session that expires after four hours and is held in session storage, not the persisted Zustand store.
- Admin-only account, plan, payment-review, template-management, and CA-account operations now require the signed admin session.
- User-list responses no longer include stored PINs. A newly created account's password is returned to the authenticated admin once, at creation time.
- New passwords are PBKDF2-SHA256 hashed. Legacy plaintext PINs are upgraded after a successful login.
- Admin password reset and account password reset flows were adjusted to match the new session/hash behavior.
- Removed a duplicate QR image read in the admin panel.

## Existing functionality retained

The upgrade extends the current codebase; it does not replace the application or add destructive database migrations. Existing modules and data models remain in place. The dashboard's “Sales less purchases” figure is deliberately labelled as a trading difference, not net profit, because a complete net-profit figure also requires expense and stock-valuation inputs.

## Validation performed

- TypeScript: `tsc --noEmit` passed.
- ESLint: passed on all changed TypeScript/TSX files.
- Production build: not completed in this Linux validation environment. The uploaded archive contains Windows-installed `node_modules`; the Linux Rolldown native binding was missing, and fetching it timed out. Reinstall dependencies on the target OS (`npm install`/`npm ci`) before running `npm run build`.

## Deployment checklist

1. Preserve the existing `.env`, database, and payment-proof storage.
2. Set a unique `ADMIN_PASSWORD` and a random `APP_SESSION_SECRET` (at least 32 characters).
3. Rotate any previously exposed Supabase Secret/service-role key.
4. Ensure the Supabase schema is already current or apply the idempotent project SQL after taking a backup.
5. Reinstall dependencies on the target OS and run the production build before deployment.
6. Smoke-test admin login, regular user login, account creation, password reset, sale creation, purchase creation, and invoice printing/PDF on the deployed instance.
